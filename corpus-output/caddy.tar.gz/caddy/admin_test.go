package caddy;import("encoding/json";"reflect";"sync";"testing");var testCfg=[]byte(`{
			"apps": {
				"http": {
					"servers": {
						"myserver": {
							"listen": ["tcp/localhost:8080-8084"],
							"read_timeout": "30s"
						},
						"yourserver": {
							"listen": ["127.0.0.1:5000"],
							"read_header_timeout": "15s"
						}
					}
				}
			}
		}
		`);func TestUnsyncedConfigAccess(t *testing.T){for i,tc:=range []struct{method string;path string;payload string;expect string;shouldErr bool}{{method:"POST",path:"",payload:`{"foo": "bar", "list": ["a", "b", "c"]}`,expect:`{"foo": "bar", "list": ["a", "b", "c"]}`},{method:"POST",path:"/foo",payload:`"jet"`,expect:`{"foo": "jet", "list": ["a", "b", "c"]}`},{method:"POST",path:"/bar",payload:`{"aa": "bb", "qq": "zz"}`,expect:`{"foo": "jet", "bar": {"aa": "bb", "qq": "zz"}, "list": ["a", "b", "c"]}`},{method:"DELETE",path:"/bar/qq",expect:`{"foo": "jet", "bar": {"aa": "bb"}, "list": ["a", "b", "c"]}`},{method:"POST",path:"/list",payload:`"e"`,expect:`{"foo": "jet", "bar": {"aa": "bb"}, "list": ["a", "b", "c", "e"]}`},{method:"PUT",path:"/list/3",payload:`"d"`,expect:`{"foo": "jet", "bar": {"aa": "bb"}, "list": ["a", "b", "c", "d", "e"]}`},{method:"DELETE",path:"/list/3",expect:`{"foo": "jet", "bar": {"aa": "bb"}, "list": ["a", "b", "c", "e"]}`},{method:"PATCH",path:"/list/3",payload:`"d"`,expect:`{"foo": "jet", "bar": {"aa": "bb"}, "list": ["a", "b", "c", "d"]}`},{method:"POST",path:"/list/...",payload:`["e", "f", "g"]`,expect:`{"foo": "jet", "bar": {"aa": "bb"}, "list": ["a", "b", "c", "d", "e", "f", "g"]}`}}{err:=unsyncedConfigAccess(tc.method,rawConfigKey+tc.path,[]byte(tc.payload),nil);if tc.shouldErr&&err==nil{t.Fatalf("Test %d: Expected error return value, but got: %v",i,err)};if !tc.shouldErr&&err!=nil{t.Fatalf("Test %d: Should not have had error return value, but got: %v",i,err)};var expectedDecoded interface{};err=json.Unmarshal([]byte(tc.expect),&expectedDecoded);if err!=nil{t.Fatalf("Test %d: Unmarshaling expected config: %v",i,err)};if !reflect.DeepEqual(rawCfg[rawConfigKey],expectedDecoded){t.Fatalf("Test %d:\nExpected:\n\t%#v\nActual:\n\t%#v",i,expectedDecoded,rawCfg[rawConfigKey])}}};func TestLoadConcurrent(t *testing.T){var wg sync.WaitGroup;for i:=0;i<100;i++{wg.Add(1);go func(){_=Load(testCfg,true);wg.Done()}()};wg.Wait()};func BenchmarkLoad(b *testing.B){for i:=0;i<b.N;i++{Load(testCfg,true)}}