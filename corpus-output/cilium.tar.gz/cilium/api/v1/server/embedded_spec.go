package server;import("encoding/json");var(SwaggerJSON json.RawMessage;FlatSwaggerJSON json.RawMessage);func init(){SwaggerJSON=json.RawMessage([]byte(`{
  "consumes": [
    "application/json"
  ],
  "produces": [
    "application/json"
  ],
  "swagger": "2.0",
  "info": {
    "description": "Cilium",
    "title": "Cilium API",
    "version": "v1beta"
  },
  "basePath": "/v1",
  "paths": {
    "/cluster/nodes": {
      "get": {
        "tags": [
          "daemon"
        ],
        "summary": "Get nodes information stored in the cilium-agent",
        "parameters": [
          {
            "type": "integer",
            "description": "Client UUID should be used when the client wants to request\na diff of nodes added and / or removed since the last time\nthat client has made a request.\n",
            "name": "client-id",
            "in": "header"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/ClusterNodeStatus"
            }
          }
        }
      }
    },
    "/config": {
      "get": {
        "description": "Returns the configuration of the Cilium daemon.\n",
        "tags": [
          "daemon"
        ],
        "summary": "Get configuration of Cilium daemon",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/DaemonConfiguration"
            }
          }
        }
      },
      "patch": {
        "description": "Updates the daemon configuration by applying the provided\nConfigurationMap and regenerates \u0026 recompiles all required datapath\ncomponents.\n",
        "tags": [
          "daemon"
        ],
        "summary": "Modify daemon configuration",
        "parameters": [
          {
            "name": "configuration",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/DaemonConfigurationSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Bad configuration parameters",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          },
          "500": {
            "description": "Recompilation failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/debuginfo": {
      "get": {
        "tags": [
          "daemon"
        ],
        "summary": "Retrieve information about the agent and evironment for debugging",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/DebugInfo"
            }
          },
          "500": {
            "description": "DebugInfo get failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/endpoint": {
      "get": {
        "description": "Retrieves a list of endpoints that have metadata matching the provided parameters, or all endpoints if no parameters provided.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieves a list of endpoints that have metadata matching the provided parameters.",
        "parameters": [
          {
            "$ref": "#/parameters/labels"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Endpoint"
              }
            }
          },
          "404": {
            "description": "Endpoints with provided parameters not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      }
    },
    "/endpoint/{id}": {
      "get": {
        "description": "Returns endpoint information\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Get endpoint by endpoint ID",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Endpoint"
            }
          },
          "400": {
            "description": "Invalid endpoint ID format for specified type",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      },
      "put": {
        "description": "Creates a new endpoint\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Create endpoint",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          },
          {
            "$ref": "#/parameters/endpoint-change-request"
          }
        ],
        "responses": {
          "201": {
            "description": "Created"
          },
          "400": {
            "description": "Invalid endpoint in request",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "409": {
            "description": "Endpoint already exists",
            "x-go-name": "Exists"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          },
          "500": {
            "description": "Endpoint creation failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failed"
          }
        }
      },
      "delete": {
        "description": "Deletes the endpoint specified by the ID. Deletion is imminent and\natomic, if the deletion request is valid and the endpoint exists,\ndeletion will occur even if errors are encountered in the process. If\nerrors have been encountered, the code 202 will be returned, otherwise\n200 on success.\n\nAll resources associated with the endpoint will be freed and the\nworkload represented by the endpoint will be disconnected.It will no\nlonger be able to initiate or receive communications of any sort.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Delete endpoint",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "206": {
            "description": "Deleted with a number of errors encountered",
            "schema": {
              "type": "integer"
            },
            "x-go-name": "Errors"
          },
          "400": {
            "description": "Invalid endpoint ID format for specified type. Details in error\nmessage\n",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      },
      "patch": {
        "description": "Applies the endpoint change request to an existing endpoint\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Modify existing endpoint",
        "deprecated": true,
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          },
          {
            "$ref": "#/parameters/endpoint-change-request"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid modify endpoint request",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint does not exist"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          },
          "500": {
            "description": "Endpoint update failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failed"
          }
        }
      }
    },
    "/endpoint/{id}/config": {
      "get": {
        "description": "Retrieves the configuration of the specified endpoint.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieve endpoint configuration",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/EndpointConfigurationStatus"
            }
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      },
      "patch": {
        "description": "Update the configuration of an existing endpoint and regenerates \u0026\nrecompiles the corresponding programs automatically.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Modify mutable endpoint configuration",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          },
          {
            "name": "endpoint-configuration",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/EndpointConfigurationSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid configuration request",
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          },
          "500": {
            "description": "Update failed. Details in message.",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failed"
          }
        }
      }
    },
    "/endpoint/{id}/healthz": {
      "get": {
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieves the status logs associated with this endpoint.",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/EndpointHealth"
            }
          },
          "400": {
            "description": "Invalid identity provided",
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      }
    },
    "/endpoint/{id}/labels": {
      "get": {
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieves the list of labels associated with an endpoint.",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/LabelConfiguration"
            }
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      },
      "patch": {
        "description": "Sets labels associated with an endpoint. These can be user provided or\nderived from the orchestration system.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Set label configuration of endpoint",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          },
          {
            "name": "configuration",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/LabelConfigurationSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          },
          "500": {
            "description": "Error while updating labels",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "UpdateFailed"
          }
        }
      }
    },
    "/endpoint/{id}/log": {
      "get": {
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieves the status logs associated with this endpoint.",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/EndpointStatusLog"
            }
          },
          "400": {
            "description": "Invalid identity provided",
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      }
    },
    "/fqdn/cache": {
      "get": {
        "description": "Retrieves the list of DNS lookups intercepted from endpoints,\noptionally filtered by endpoint id, DNS name, or CIDR IP range.\n",
        "tags": [
          "policy"
        ],
        "summary": "Retrieves the list of DNS lookups intercepted from all endpoints.",
        "parameters": [
          {
            "$ref": "#/parameters/matchpattern"
          },
          {
            "$ref": "#/parameters/cidr"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/DNSLookup"
              }
            }
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          },
          "404": {
            "description": "No DNS data with provided parameters found"
          }
        }
      },
      "delete": {
        "description": "Deletes matching DNS lookups from the cache, optionally restricted by\nDNS name. The removed IP data will no longer be used in generated\npolicies.\n",
        "tags": [
          "policy"
        ],
        "summary": "Deletes matching DNS lookups from the policy-generation cache.",
        "parameters": [
          {
            "$ref": "#/parameters/matchpattern"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          }
        }
      }
    },
    "/fqdn/cache/{id}": {
      "get": {
        "description": "Retrieves the list of DNS lookups intercepted from endpoints,\noptionally filtered by endpoint id, DNS name, or CIDR IP range.\n",
        "tags": [
          "policy"
        ],
        "summary": "Retrieves the list of DNS lookups intercepted from an endpoint.",
        "parameters": [
          {
            "$ref": "#/parameters/endpoint-id"
          },
          {
            "$ref": "#/parameters/matchpattern"
          },
          {
            "$ref": "#/parameters/cidr"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/DNSLookup"
              }
            }
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          },
          "404": {
            "description": "No DNS data with provided parameters found"
          }
        }
      }
    },
    "/fqdn/names": {
      "get": {
        "description": "Retrieves the list of DNS-related fields (names to poll, selectors and\ntheir corresponding regexes).\n",
        "tags": [
          "policy"
        ],
        "summary": "List internal DNS selector representations",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/NameManager"
            }
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          }
        }
      }
    },
    "/healthz": {
      "get": {
        "description": "Returns health and status information of the Cilium daemon and related\ncomponents such as the local container runtime, connected datastore,\nKubernetes integration and Hubble.\n",
        "tags": [
          "daemon"
        ],
        "summary": "Get health of Cilium daemon",
        "parameters": [
          {
            "type": "boolean",
            "description": "Brief will return a brief representation of the Cilium status.\n",
            "name": "brief",
            "in": "header"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/StatusResponse"
            }
          }
        }
      }
    },
    "/identity": {
      "get": {
        "description": "Retrieves a list of identities that have metadata matching the provided parameters, or all identities if no parameters are provided.\n",
        "tags": [
          "policy"
        ],
        "summary": "Retrieves a list of identities that have metadata matching the provided parameters.",
        "parameters": [
          {
            "$ref": "#/parameters/labels"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Identity"
              }
            }
          },
          "404": {
            "description": "Identities with provided parameters not found"
          },
          "520": {
            "description": "Identity storage unreachable. Likely a network problem.",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Unreachable"
          },
          "521": {
            "description": "Invalid identity format in storage",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidStorageFormat"
          }
        }
      }
    },
    "/identity/endpoints": {
      "get": {
        "tags": [
          "policy"
        ],
        "summary": "Retrieve identities which are being used by local endpoints",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/IdentityEndpoints"
              }
            }
          },
          "404": {
            "description": "Set of identities which are being used by local endpoints could not be found."
          }
        }
      }
    },
    "/identity/{id}": {
      "get": {
        "tags": [
          "policy"
        ],
        "summary": "Retrieve identity",
        "parameters": [
          {
            "$ref": "#/parameters/identity-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Identity"
            }
          },
          "400": {
            "description": "Invalid identity provided"
          },
          "404": {
            "description": "Identity not found"
          },
          "520": {
            "description": "Identity storage unreachable. Likely a network problem.",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Unreachable"
          },
          "521": {
            "description": "Invalid identity format in storage",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidStorageFormat"
          }
        }
      }
    },
    "/ip": {
      "get": {
        "description": "Retrieves a list of IPs with known associated information such as\ntheir identities, host addresses, Kubernetes pod names, etc.\nThe list can optionally filtered by a CIDR IP range.\n",
        "tags": [
          "policy"
        ],
        "summary": "Lists information about known IP addresses",
        "parameters": [
          {
            "$ref": "#/parameters/cidr"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/IPListEntry"
              }
            }
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          },
          "404": {
            "description": "No IP cache entries with provided parameters found"
          }
        }
      }
    },
    "/ipam": {
      "post": {
        "tags": [
          "ipam"
        ],
        "summary": "Allocate an IP address",
        "parameters": [
          {
            "$ref": "#/parameters/ipam-family"
          },
          {
            "$ref": "#/parameters/ipam-owner"
          },
          {
            "$ref": "#/parameters/ipam-expiration"
          }
        ],
        "responses": {
          "201": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/IPAMResponse"
            }
          },
          "502": {
            "description": "Allocation failure",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/ipam/{ip}": {
      "post": {
        "tags": [
          "ipam"
        ],
        "summary": "Allocate an IP address",
        "parameters": [
          {
            "$ref": "#/parameters/ipam-ip"
          },
          {
            "$ref": "#/parameters/ipam-owner"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid IP address",
            "x-go-name": "Invalid"
          },
          "409": {
            "description": "IP already allocated",
            "x-go-name": "Exists"
          },
          "500": {
            "description": "IP allocation failure. Details in message.",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          },
          "501": {
            "description": "Allocation for address family disabled",
            "x-go-name": "Disabled"
          }
        }
      },
      "delete": {
        "tags": [
          "ipam"
        ],
        "summary": "Release an allocated IP address",
        "parameters": [
          {
            "$ref": "#/parameters/ipam-release-arg"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid IP address",
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "IP address not found"
          },
          "500": {
            "description": "Address release failure",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          },
          "501": {
            "description": "Allocation for address family disabled",
            "x-go-name": "Disabled"
          }
        }
      }
    },
    "/lrp": {
      "get": {
        "tags": [
          "service"
        ],
        "summary": "Retrieve list of all local redirect policies",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/LRPSpec"
              }
            }
          }
        }
      }
    },
    "/map": {
      "get": {
        "tags": [
          "daemon"
        ],
        "summary": "List all open maps",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/BPFMapList"
            }
          }
        }
      }
    },
    "/map/{name}": {
      "get": {
        "tags": [
          "daemon"
        ],
        "summary": "Retrieve contents of BPF map",
        "parameters": [
          {
            "$ref": "#/parameters/map-name"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/BPFMap"
            }
          },
          "404": {
            "description": "Map not found"
          }
        }
      }
    },
    "/metrics/": {
      "get": {
        "tags": [
          "metrics"
        ],
        "summary": "Retrieve cilium metrics",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Metric"
              }
            }
          },
          "500": {
            "description": "Metrics cannot be retrieved"
          }
        }
      }
    },
    "/policy": {
      "get": {
        "description": "Returns the entire policy tree with all children.\n",
        "tags": [
          "policy"
        ],
        "summary": "Retrieve entire policy tree",
        "parameters": [
          {
            "name": "labels",
            "in": "body",
            "schema": {
              "$ref": "#/definitions/Labels"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Policy"
            }
          },
          "404": {
            "description": "No policy rules found"
          }
        }
      },
      "put": {
        "tags": [
          "policy"
        ],
        "summary": "Create or update a policy (sub)tree",
        "parameters": [
          {
            "$ref": "#/parameters/policy-rules"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Policy"
            }
          },
          "400": {
            "description": "Invalid policy",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidPolicy"
          },
          "460": {
            "description": "Invalid path",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidPath"
          },
          "500": {
            "description": "Policy import failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "delete": {
        "tags": [
          "policy"
        ],
        "summary": "Delete a policy (sub)tree",
        "parameters": [
          {
            "name": "labels",
            "in": "body",
            "schema": {
              "$ref": "#/definitions/Labels"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Policy"
            }
          },
          "400": {
            "description": "Invalid request",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Policy not found"
          },
          "500": {
            "description": "Error while deleting policy",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/policy/resolve": {
      "get": {
        "tags": [
          "policy"
        ],
        "summary": "Resolve policy for an identity context",
        "parameters": [
          {
            "$ref": "#/parameters/trace-selector"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/PolicyTraceResult"
            }
          }
        }
      }
    },
    "/policy/selectors": {
      "get": {
        "tags": [
          "policy"
        ],
        "summary": "See what selectors match which identities",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/SelectorCache"
            }
          }
        }
      }
    },
    "/prefilter": {
      "get": {
        "tags": [
          "prefilter"
        ],
        "summary": "Retrieve list of CIDRs",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Prefilter"
            }
          },
          "500": {
            "description": "Prefilter get failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "delete": {
        "tags": [
          "prefilter"
        ],
        "summary": "Delete list of CIDRs",
        "parameters": [
          {
            "$ref": "#/parameters/prefilter-spec"
          }
        ],
        "responses": {
          "200": {
            "description": "Deleted",
            "schema": {
              "$ref": "#/definitions/Prefilter"
            }
          },
          "461": {
            "description": "Invalid CIDR prefix",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidCIDR"
          },
          "500": {
            "description": "Prefilter delete failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "patch": {
        "tags": [
          "prefilter"
        ],
        "summary": "Update list of CIDRs",
        "parameters": [
          {
            "$ref": "#/parameters/prefilter-spec"
          }
        ],
        "responses": {
          "200": {
            "description": "Updated",
            "schema": {
              "$ref": "#/definitions/Prefilter"
            }
          },
          "461": {
            "description": "Invalid CIDR prefix",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidCIDR"
          },
          "500": {
            "description": "Prefilter update failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/recorder": {
      "get": {
        "tags": [
          "recorder"
        ],
        "summary": "Retrieve list of all recorders",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Recorder"
              }
            }
          }
        }
      }
    },
    "/recorder/masks": {
      "get": {
        "tags": [
          "recorder"
        ],
        "summary": "Retrieve list of all recorder masks",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/RecorderMask"
              }
            }
          }
        }
      }
    },
    "/recorder/{id}": {
      "get": {
        "tags": [
          "recorder"
        ],
        "summary": "Retrieve configuration of a recorder",
        "parameters": [
          {
            "$ref": "#/parameters/recorder-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Recorder"
            }
          },
          "404": {
            "description": "Recorder not found"
          }
        }
      },
      "put": {
        "tags": [
          "recorder"
        ],
        "summary": "Create or update recorder",
        "parameters": [
          {
            "$ref": "#/parameters/recorder-id"
          },
          {
            "$ref": "#/parameters/recorder-config"
          }
        ],
        "responses": {
          "200": {
            "description": "Updated"
          },
          "201": {
            "description": "Created"
          },
          "500": {
            "description": "Error while creating recorder",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "delete": {
        "tags": [
          "recorder"
        ],
        "summary": "Delete a recorder",
        "parameters": [
          {
            "$ref": "#/parameters/recorder-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "404": {
            "description": "Recorder not found"
          },
          "500": {
            "description": "Recorder deletion failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/service": {
      "get": {
        "tags": [
          "service"
        ],
        "summary": "Retrieve list of all services",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Service"
              }
            }
          }
        }
      }
    },
    "/service/{id}": {
      "get": {
        "tags": [
          "service"
        ],
        "summary": "Retrieve configuration of a service",
        "parameters": [
          {
            "$ref": "#/parameters/service-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Service"
            }
          },
          "404": {
            "description": "Service not found"
          }
        }
      },
      "put": {
        "tags": [
          "service"
        ],
        "summary": "Create or update service",
        "parameters": [
          {
            "$ref": "#/parameters/service-id"
          },
          {
            "$ref": "#/parameters/service-config"
          }
        ],
        "responses": {
          "200": {
            "description": "Updated"
          },
          "201": {
            "description": "Created"
          },
          "460": {
            "description": "Invalid frontend in service configuration",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidFrontend"
          },
          "461": {
            "description": "Invalid backend in service configuration",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidBackend"
          },
          "500": {
            "description": "Error while creating service",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "delete": {
        "tags": [
          "service"
        ],
        "summary": "Delete a service",
        "parameters": [
          {
            "$ref": "#/parameters/service-id"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "404": {
            "description": "Service not found"
          },
          "500": {
            "description": "Service deletion failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    }
  },
  "definitions": {
    "Address": {
      "description": "IP address",
      "type": "string"
    },
    "AddressPair": {
      "description": "Addressing information of an endpoint",
      "type": "object",
      "properties": {
        "ipv4": {
          "description": "IPv4 address",
          "type": "string"
        },
        "ipv4-expiration-uuid": {
          "description": "UUID of IPv4 expiration timer",
          "type": "string"
        },
        "ipv6": {
          "description": "IPv6 address",
          "type": "string"
        },
        "ipv6-expiration-uuid": {
          "description": "UUID of IPv6 expiration timer",
          "type": "string"
        }
      }
    },
    "AllocationMap": {
      "description": "Map of allocated IPs\n",
      "type": "object",
      "additionalProperties": {
        "type": "string"
      }
    },
    "BPFMap": {
      "description": "BPF map definition and content",
      "type": "object",
      "properties": {
        "cache": {
          "description": "Contents of cache",
          "type": "array",
          "items": {
            "$ref": "#/definitions/BPFMapEntry"
          }
        },
        "path": {
          "description": "Path to BPF map",
          "type": "string"
        }
      }
    },
    "BPFMapEntry": {
      "description": "BPF map cache entry",
      "type": "object",
      "properties": {
        "desired-action": {
          "description": "Desired action to be performed",
          "type": "string",
          "enum": [
            "ok",
            "insert",
            "delete"
          ]
        },
        "key": {
          "description": "Key of map entry",
          "type": "string"
        },
        "last-error": {
          "description": "Last error seen while performing desired action",
          "type": "string"
        },
        "value": {
          "description": "Value of map entry",
          "type": "string"
        }
      }
    },
    "BPFMapList": {
      "description": "List of BPF Maps",
      "type": "object",
      "properties": {
        "maps": {
          "description": "Array of open BPF map lists",
          "type": "array",
          "items": {
            "$ref": "#/definitions/BPFMap"
          }
        }
      }
    },
    "BPFMapProperties": {
      "description": "BPF map properties",
      "type": "object",
      "properties": {
        "name": {
          "description": "Name of the BPF map",
          "type": "string"
        },
        "size": {
          "description": "Size of the BPF map",
          "type": "integer"
        }
      }
    },
    "BPFMapStatus": {
      "description": "BPF map status\n\n+k8s:deepcopy-gen=true\n",
      "type": "object",
      "properties": {
        "dynamic-size-ratio": {
          "description": "Ratio of total system memory to use for dynamic sizing of BPF maps",
          "type": "number"
        },
        "maps": {
          "description": "BPF maps",
          "type": "array",
          "items": {
            "$ref": "#/definitions/BPFMapProperties"
          }
        }
      }
    },
    "BackendAddress": {
      "description": "Service backend address",
      "type": "object",
      "required": [
        "ip"
      ],
      "properties": {
        "ip": {
          "description": "Layer 3 address",
          "type": "string"
        },
        "nodeName": {
          "description": "Optional name of the node on which this backend runs",
          "type": "string"
        },
        "port": {
          "description": "Layer 4 port number",
          "type": "integer",
          "format": "uint16"
        }
      }
    },
    "BandwidthManager": {
      "description": "Status of bandwidth manager\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "devices": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "enabled": {
          "description": "Is bandwidth manager enabled",
          "type": "boolean"
        }
      }
    },
    "CIDRList": {
      "description": "List of CIDRs",
      "type": "object",
      "properties": {
        "list": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "revision": {
          "type": "integer"
        }
      }
    },
    "CIDRPolicy": {
      "description": "CIDR endpoint policy\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "egress": {
          "description": "List of CIDR egress rules",
          "type": "array",
          "items": {
            "$ref": "#/definitions/PolicyRule"
          }
        },
        "ingress": {
          "description": "List of CIDR ingress rules",
          "type": "array",
          "items": {
            "$ref": "#/definitions/PolicyRule"
          }
        }
      }
    },
    "ClockSource": {
      "description": "Status of BPF clock source\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "hertz": {
          "description": "Kernel Hz",
          "type": "integer"
        },
        "mode": {
          "description": "Datapath clock source",
          "type": "string",
          "enum": [
            "ktime",
            "jiffies"
          ]
        }
      }
    },
    "ClusterMeshStatus": {
      "description": "Status of ClusterMesh\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "clusters": {
          "description": "List of remote clusters",
          "type": "array",
          "items": {
            "$ref": "#/definitions/RemoteCluster"
          }
        },
        "num-global-services": {
          "description": "Number of global services",
          "type": "integer"
        }
      }
    },
    "ClusterNodeStatus": {
      "description": "Status of cluster",
      "properties": {
        "client-id": {
          "description": "ID that should be used by the client to receive a diff from the previous request",
          "type": "integer"
        },
        "nodes-added": {
          "description": "List of known nodes",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeElement"
          }
        },
        "nodes-removed": {
          "description": "List of known nodes",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeElement"
          }
        },
        "self": {
          "description": "Name of local node (if available)",
          "type": "string"
        }
      }
    },
    "ClusterNodesResponse": {
      "properties": {
        "nodes": {
          "description": "List of known nodes",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeElement"
          }
        },
        "self": {
          "description": "Name of local node (if available)",
          "type": "string"
        }
      }
    },
    "ClusterStatus": {
      "description": "Status of cluster\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "ciliumHealth": {
          "description": "Status of local cilium-health daemon",
          "$ref": "#/definitions/Status"
        },
        "nodes": {
          "description": "List of known nodes",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeElement"
          }
        },
        "self": {
          "description": "Name of local node (if available)",
          "type": "string"
        }
      }
    },
    "ConfigurationMap": {
      "description": "Map of configuration key/value pairs.\n",
      "type": "object",
      "additionalProperties": {
        "type": "string"
      }
    },
    "ControllerStatus": {
      "description": "Status of a controller\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "configuration": {
          "description": "Configuration of controller\n\n+deepequal-gen=true\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "error-retry": {
              "description": "Retry on error",
              "type": "boolean"
            },
            "error-retry-base": {
              "description": "Base error retry back-off time",
              "type": "string",
              "format": "duration"
            },
            "interval": {
              "description": "Regular synchronization interval",
              "type": "string",
              "format": "duration"
            }
          }
        },
        "name": {
          "description": "Name of controller",
          "type": "string"
        },
        "status": {
          "description": "Current status of controller\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "consecutive-failure-count": {
              "description": "Number of consecutive errors since last success",
              "type": "integer"
            },
            "failure-count": {
              "description": "Total number of failed runs",
              "type": "integer"
            },
            "last-failure-msg": {
              "description": "Error message of last failed run",
              "type": "string"
            },
            "last-failure-timestamp": {
              "description": "Timestamp of last error",
              "type": "string",
              "format": "date-time"
            },
            "last-success-timestamp": {
              "description": "Timestamp of last success",
              "type": "string",
              "format": "date-time"
            },
            "success-count": {
              "description": "Total number of successful runs",
              "type": "integer"
            }
          }
        },
        "uuid": {
          "description": "UUID of controller",
          "type": "string",
          "format": "uuid"
        }
      }
    },
    "ControllerStatuses": {
      "description": "Collection of controller statuses",
      "type": "array",
      "items": {
        "$ref": "#/definitions/ControllerStatus"
      }
    },
    "DNSLookup": {
      "description": "An IP -\u003e DNS mapping, with metadata",
      "type": "object",
      "properties": {
        "endpoint-id": {
          "description": "The endpoint that made this lookup, or 0 for the agent itself.",
          "type": "integer"
        },
        "expiration-time": {
          "description": "The absolute time when this data will expire in this cache",
          "type": "string",
          "format": "date-time"
        },
        "fqdn": {
          "description": "DNS name",
          "type": "string"
        },
        "ips": {
          "description": "IP addresses returned in this lookup",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "lookup-time": {
          "description": "The absolute time when this data was recieved",
          "type": "string",
          "format": "date-time"
        },
        "source": {
          "description": "The reason this FQDN IP association exists. Either a DNS lookup or an ongoing connection to an IP that was created by a DNS lookup.",
          "type": "string"
        },
        "ttl": {
          "description": "The TTL in the DNS response",
          "type": "integer"
        }
      }
    },
    "DaemonConfiguration": {
      "description": "Response to a daemon configuration request.\n",
      "type": "object",
      "properties": {
        "spec": {
          "description": "Changeable configuration",
          "$ref": "#/definitions/DaemonConfigurationSpec"
        },
        "status": {
          "description": "Current daemon configuration related status.Contains the addressing\ninformation, k8s, node monitor and immutable and mutable\nconfiguration settings.\n",
          "$ref": "#/definitions/DaemonConfigurationStatus"
        }
      }
    },
    "DaemonConfigurationSpec": {
      "description": "The controllable configuration of the daemon.",
      "type": "object",
      "properties": {
        "options": {
          "description": "Changeable configuration",
          "$ref": "#/definitions/ConfigurationMap"
        },
        "policy-enforcement": {
          "description": "The policy-enforcement mode",
          "type": "string",
          "enum": [
            "default",
            "always",
            "never"
          ]
        }
      }
    },
    "DaemonConfigurationStatus": {
      "description": "Response to a daemon configuration request. Contains the addressing\ninformation, k8s, node monitor and immutable and mutable configuration\nsettings.\n",
      "type": "object",
      "properties": {
        "addressing": {
          "$ref": "#/definitions/NodeAddressing"
        },
        "daemonConfigurationMap": {
          "description": "Config map which contains all the active daemon configurations",
          "additionalProperties": {
            "type": "object"
          }
        },
        "datapathMode": {
          "$ref": "#/definitions/DatapathMode"
        },
        "deviceMTU": {
          "description": "MTU on workload facing devices",
          "type": "integer"
        },
        "egress-multi-home-ip-rule-compat": {
          "description": "Configured compatibility mode for --egress-multi-home-ip-rule-compat",
          "type": "boolean"
        },
        "immutable": {
          "description": "Immutable configuration (read-only)",
          "$ref": "#/definitions/ConfigurationMap"
        },
        "ipam-mode": {
          "description": "Configured IPAM mode",
          "type": "string"
        },
        "ipvlanConfiguration": {
          "$ref": "#/definitions/IpvlanConfiguration"
        },
        "k8s-configuration": {
          "type": "string"
        },
        "k8s-endpoint": {
          "type": "string"
        },
        "kvstoreConfiguration": {
          "$ref": "#/definitions/KVstoreConfiguration"
        },
        "masquerade": {
          "type": "boolean"
        },
        "masqueradeProtocols": {
          "description": "Status of masquerading feature",
          "type": "object",
          "properties": {
            "ipv4": {
              "description": "Status of masquerading for IPv4 traffic",
              "type": "boolean"
            },
            "ipv6": {
              "description": "Status of masquerading for IPv6 traffic",
              "type": "boolean"
            }
          }
        },
        "nodeMonitor": {
          "description": "Status of the node monitor",
          "$ref": "#/definitions/MonitorStatus"
        },
        "realized": {
          "description": "Currently applied configuration",
          "$ref": "#/definitions/DaemonConfigurationSpec"
        },
        "routeMTU": {
          "description": "MTU for network facing routes",
          "type": "integer"
        }
      }
    },
    "DatapathMode": {
      "description": "Datapath mode",
      "type": "string",
      "enum": [
        "veth",
        "ipvlan"
      ]
    },
    "DebugInfo": {
      "description": "groups some debugging related information on the agent",
      "type": "object",
      "properties": {
        "cilium-memory-map": {
          "type": "string"
        },
        "cilium-nodemonitor-memory-map": {
          "type": "string"
        },
        "cilium-status": {
          "$ref": "#/definitions/StatusResponse"
        },
        "cilium-version": {
          "type": "string"
        },
        "encryption": {
          "type": "object",
          "properties": {
            "wireguard": {
              "description": "Status of the Wireguard agent",
              "$ref": "#/definitions/WireguardStatus"
            }
          }
        },
        "endpoint-list": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/Endpoint"
          }
        },
        "environment-variables": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "kernel-version": {
          "type": "string"
        },
        "policy": {
          "$ref": "#/definitions/Policy"
        },
        "service-list": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/Service"
          }
        },
        "subsystem": {
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        }
      }
    },
    "EncryptionStatus": {
      "description": "Status of transparent encryption\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "mode": {
          "type": "string",
          "enum": [
            "Disabled",
            "IPsec",
            "Wireguard"
          ]
        },
        "msg": {
          "description": "Human readable status/error/warning message",
          "type": "string"
        },
        "wireguard": {
          "description": "Status of the Wireguard agent",
          "$ref": "#/definitions/WireguardStatus"
        }
      }
    },
    "Endpoint": {
      "description": "An endpoint is a namespaced network interface to which cilium applies policies",
      "type": "object",
      "properties": {
        "id": {
          "description": "The cilium-agent-local ID of the endpoint",
          "type": "integer"
        },
        "spec": {
          "description": "The desired configuration state of the endpoint",
          "$ref": "#/definitions/EndpointConfigurationSpec"
        },
        "status": {
          "description": "The desired and realized configuration state of the endpoint",
          "$ref": "#/definitions/EndpointStatus"
        }
      }
    },
    "EndpointChangeRequest": {
      "description": "Structure which contains the mutable elements of an Endpoint.\n",
      "type": "object",
      "required": [
        "state"
      ],
      "properties": {
        "addressing": {
          "$ref": "#/definitions/AddressPair"
        },
        "container-id": {
          "description": "ID assigned by container runtime",
          "type": "string"
        },
        "container-name": {
          "description": "Name assigned to container",
          "type": "string"
        },
        "datapath-configuration": {
          "$ref": "#/definitions/EndpointDatapathConfiguration"
        },
        "datapath-map-id": {
          "description": "ID of datapath tail call map",
          "type": "integer"
        },
        "docker-endpoint-id": {
          "description": "Docker endpoint ID",
          "type": "string"
        },
        "docker-network-id": {
          "description": "Docker network ID",
          "type": "string"
        },
        "host-mac": {
          "description": "MAC address",
          "type": "string"
        },
        "id": {
          "description": "Local endpoint ID",
          "type": "integer"
        },
        "interface-index": {
          "description": "Index of network device",
          "type": "integer"
        },
        "interface-name": {
          "description": "Name of network device",
          "type": "string"
        },
        "k8s-namespace": {
          "description": "Kubernetes namespace name",
          "type": "string"
        },
        "k8s-pod-name": {
          "description": "Kubernetes pod name",
          "type": "string"
        },
        "labels": {
          "description": "Labels describing the identity",
          "$ref": "#/definitions/Labels"
        },
        "mac": {
          "description": "MAC address",
          "type": "string"
        },
        "pid": {
          "description": "Process ID of the workload belonging to this endpoint",
          "type": "integer"
        },
        "policy-enabled": {
          "description": "Whether policy enforcement is enabled or not",
          "type": "boolean"
        },
        "state": {
          "description": "Current state of endpoint",
          "$ref": "#/definitions/EndpointState"
        },
        "sync-build-endpoint": {
          "description": "Whether to build an endpoint synchronously\n",
          "type": "boolean"
        }
      }
    },
    "EndpointConfigurationSpec": {
      "description": "An endpoint's configuration",
      "type": "object",
      "properties": {
        "label-configuration": {
          "description": "the endpoint's labels",
          "$ref": "#/definitions/LabelConfigurationSpec"
        },
        "options": {
          "description": "Changeable configuration",
          "$ref": "#/definitions/ConfigurationMap"
        }
      }
    },
    "EndpointConfigurationStatus": {
      "description": "An endpoint's configuration",
      "type": "object",
      "properties": {
        "error": {
          "description": "Most recent error, if applicable",
          "$ref": "#/definitions/Error"
        },
        "immutable": {
          "description": "Immutable configuration (read-only)",
          "$ref": "#/definitions/ConfigurationMap"
        },
        "realized": {
          "description": "currently applied changeable configuration",
          "$ref": "#/definitions/EndpointConfigurationSpec"
        }
      }
    },
    "EndpointDatapathConfiguration": {
      "description": "Datapath configuration to be used for the endpoint",
      "type": "object",
      "properties": {
        "disable-sip-verification": {
          "description": "Disable source IP verification for the endpoint.\n",
          "type": "boolean"
        },
        "external-ipam": {
          "description": "Indicates that IPAM is done external to Cilium. This will prevent the IP from being released and re-allocation of the IP address is skipped on restore.\n",
          "type": "boolean"
        },
        "install-endpoint-route": {
          "description": "Installs a route in the Linux routing table pointing to the device of the endpoint's interface.\n",
          "type": "boolean"
        },
        "require-arp-passthrough": {
          "description": "Enable ARP passthrough mode",
          "type": "boolean"
        },
        "require-egress-prog": {
          "description": "Endpoint requires a host-facing egress program to be attached to implement ingress policy and reverse NAT.\n",
          "type": "boolean"
        },
        "require-routing": {
          "description": "Endpoint requires BPF routing to be enabled, when disabled, routing is delegated to Linux routing.\n",
          "type": "boolean",
          "default": true
        }
      }
    },
    "EndpointHealth": {
      "description": "Health of the endpoint\n\n+deepequal-gen=true",
      "type": "object",
      "properties": {
        "bpf": {
          "$ref": "#/definitions/EndpointHealthStatus"
        },
        "connected": {
          "description": "Is this endpoint reachable",
          "type": "boolean"
        },
        "overallHealth": {
          "$ref": "#/definitions/EndpointHealthStatus"
        },
        "policy": {
          "$ref": "#/definitions/EndpointHealthStatus"
        }
      }
    },
    "EndpointHealthStatus": {
      "description": "A common set of statuses for endpoint health * `+"`"+``+"`"+`OK`+"`"+``+"`"+` = All components operational * `+"`"+``+"`"+`Bootstrap`+"`"+``+"`"+` = This component is being created * `+"`"+``+"`"+`Pending`+"`"+``+"`"+` = A change is being processed to be applied * `+"`"+``+"`"+`Warning`+"`"+``+"`"+` = This component is not applying up-to-date policies (but is still applying the previous version) * `+"`"+``+"`"+`Failure`+"`"+``+"`"+` = An error has occurred and no policy is being applied * `+"`"+``+"`"+`Disabled`+"`"+``+"`"+` = This endpoint is disabled and will not handle traffic\n",
      "type": "string",
      "enum": [
        "OK",
        "Bootstrap",
        "Pending",
        "Warning",
        "Failure",
        "Disabled"
      ]
    },
    "EndpointIdentifiers": {
      "description": "Unique identifiers for this endpoint from outside cilium\n\n+deepequal-gen=true",
      "type": "object",
      "properties": {
        "container-id": {
          "description": "ID assigned by container runtime",
          "type": "string"
        },
        "container-name": {
          "description": "Name assigned to container",
          "type": "string"
        },
        "docker-endpoint-id": {
          "description": "Docker endpoint ID",
          "type": "string"
        },
        "docker-network-id": {
          "description": "Docker network ID",
          "type": "string"
        },
        "k8s-namespace": {
          "description": "K8s namespace for this endpoint",
          "type": "string"
        },
        "k8s-pod-name": {
          "description": "K8s pod name for this endpoint",
          "type": "string"
        },
        "pod-name": {
          "description": "K8s pod for this endpoint(Deprecated, use K8sPodName and K8sNamespace instead)",
          "type": "string"
        }
      }
    },
    "EndpointNetworking": {
      "description": "Unique identifiers for this endpoint from outside cilium",
      "type": "object",
      "properties": {
        "addressing": {
          "description": "IP4/6 addresses assigned to this Endpoint",
          "type": "array",
          "items": {
            "$ref": "#/definitions/AddressPair"
          }
        },
        "host-addressing": {
          "$ref": "#/definitions/NodeAddressing"
        },
        "host-mac": {
          "description": "MAC address",
          "type": "string"
        },
        "interface-index": {
          "description": "Index of network device",
          "type": "integer"
        },
        "interface-name": {
          "description": "Name of network device",
          "type": "string"
        },
        "mac": {
          "description": "MAC address",
          "type": "string"
        }
      }
    },
    "EndpointPolicy": {
      "description": "Policy information of an endpoint\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "allowed-egress-identities": {
          "description": "List of identities to which this endpoint is allowed to communicate\n",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "allowed-ingress-identities": {
          "description": "List of identities allowed to communicate to this endpoint\n",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "build": {
          "description": "Build number of calculated policy in use",
          "type": "integer"
        },
        "cidr-policy": {
          "$ref": "#/definitions/CIDRPolicy"
        },
        "denied-egress-identities": {
          "description": "List of identities to which this endpoint is not allowed to communicate\n",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "denied-ingress-identities": {
          "description": "List of identities not allowed to communicate to this endpoint\n",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "id": {
          "description": "Own identity of endpoint",
          "type": "integer"
        },
        "l4": {
          "$ref": "#/definitions/L4Policy"
        },
        "policy-enabled": {
          "description": "Whether policy enforcement is enabled (ingress, egress, both or none)",
          "$ref": "#/definitions/EndpointPolicyEnabled"
        },
        "policy-revision": {
          "description": "The agent-local policy revision",
          "type": "integer"
        }
      }
    },
    "EndpointPolicyEnabled": {
      "description": "Whether policy enforcement is enabled (ingress, egress, both or none)",
      "type": "string",
      "enum": [
        "none",
        "ingress",
        "egress",
        "both",
        "audit-ingress",
        "audit-egress",
        "audit-both"
      ]
    },
    "EndpointPolicyStatus": {
      "description": "Policy information of an endpoint",
      "type": "object",
      "properties": {
        "proxy-policy-revision": {
          "description": "The policy revision currently enforced in the proxy for this endpoint",
          "type": "integer"
        },
        "proxy-statistics": {
          "description": "Statistics of the proxy redirects configured for this endpoint",
          "type": "array",
          "items": {
            "$ref": "#/definitions/ProxyStatistics"
          }
        },
        "realized": {
          "description": "The policy in the datapath for this endpoint",
          "$ref": "#/definitions/EndpointPolicy"
        },
        "spec": {
          "description": "The policy that should apply to this endpoint",
          "$ref": "#/definitions/EndpointPolicy"
        }
      }
    },
    "EndpointState": {
      "description": "State of endpoint",
      "type": "string",
      "enum": [
        "waiting-for-identity",
        "not-ready",
        "waiting-to-regenerate",
        "regenerating",
        "restoring",
        "ready",
        "disconnecting",
        "disconnected",
        "invalid"
      ]
    },
    "EndpointStatus": {
      "description": "The current state and configuration of the endpoint, its policy \u0026 datapath, and subcomponents",
      "type": "object",
      "required": [
        "state"
      ],
      "properties": {
        "controllers": {
          "description": "Status of internal controllers attached to this endpoint",
          "$ref": "#/definitions/ControllerStatuses"
        },
        "external-identifiers": {
          "description": "Unique identifiers for this endpoint from outside cilium",
          "$ref": "#/definitions/EndpointIdentifiers"
        },
        "health": {
          "description": "Summary overall endpoint \u0026 subcomponent health",
          "$ref": "#/definitions/EndpointHealth"
        },
        "identity": {
          "description": "The security identity for this endpoint",
          "$ref": "#/definitions/Identity"
        },
        "labels": {
          "description": "Labels applied to this endpoint",
          "$ref": "#/definitions/LabelConfigurationStatus"
        },
        "log": {
          "description": "Most recent status log. See endpoint/{id}/log for the complete log.",
          "$ref": "#/definitions/EndpointStatusLog"
        },
        "namedPorts": {
          "description": "List of named ports that can be used in Network Policy",
          "$ref": "#/definitions/NamedPorts"
        },
        "networking": {
          "description": "Networking properties of the endpoint",
          "$ref": "#/definitions/EndpointNetworking"
        },
        "policy": {
          "description": "The policy applied to this endpoint from the policy repository",
          "$ref": "#/definitions/EndpointPolicyStatus"
        },
        "realized": {
          "description": "The configuration in effect on this endpoint",
          "$ref": "#/definitions/EndpointConfigurationSpec"
        },
        "state": {
          "description": "Current state of endpoint",
          "$ref": "#/definitions/EndpointState"
        }
      }
    },
    "EndpointStatusChange": {
      "description": "Indication of a change of status\n\n+deepequal-gen=true",
      "type": "object",
      "properties": {
        "code": {
          "description": "Code indicate type of status change",
          "type": "string",
          "enum": [
            "ok",
            "failed"
          ]
        },
        "message": {
          "description": "Status message",
          "type": "string"
        },
        "state": {
          "$ref": "#/definitions/EndpointState"
        },
        "timestamp": {
          "description": "Timestamp when status change occurred",
          "type": "string"
        }
      }
    },
    "EndpointStatusLog": {
      "description": "Status log of endpoint",
      "type": "array",
      "items": {
        "$ref": "#/definitions/EndpointStatusChange"
      }
    },
    "Error": {
      "type": "string"
    },
    "FrontendAddress": {
      "description": "Layer 4 address. The protocol is currently ignored, all services will\nbehave as if protocol any is specified. To restrict to a particular\nprotocol, use policy.\n",
      "type": "object",
      "properties": {
        "ip": {
          "description": "Layer 3 address",
          "type": "string"
        },
        "port": {
          "description": "Layer 4 port number",
          "type": "integer",
          "format": "uint16"
        },
        "protocol": {
          "description": "Layer 4 protocol",
          "type": "string",
          "enum": [
            "tcp",
            "udp",
            "any"
          ]
        },
        "scope": {
          "description": "Load balancing scope for frontend address",
          "type": "string",
          "enum": [
            "external",
            "internal"
          ]
        }
      }
    },
    "FrontendMapping": {
      "description": "Mapping of frontend to backend pods of an LRP",
      "type": "object",
      "properties": {
        "backends": {
          "description": "Pod backends of an LRP",
          "type": "array",
          "items": {
            "$ref": "#/definitions/LRPBackend"
          }
        },
        "frontend-address": {
          "$ref": "#/definitions/FrontendAddress"
        }
      }
    },
    "HostFirewall": {
      "description": "Status of the host firewall\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "devices": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "mode": {
          "type": "string",
          "enum": [
            "Disabled",
            "Enabled"
          ]
        }
      }
    },
    "HostRouting": {
      "description": "Status of host routing\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "mode": {
          "description": "Datapath routing mode",
          "type": "string",
          "enum": [
            "BPF",
            "Legacy"
          ]
        }
      }
    },
    "HubbleStatus": {
      "description": "Status of the Hubble server\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "metrics": {
          "description": "Status of the Hubble metrics server",
          "type": "object",
          "properties": {
            "state": {
              "description": "State of the Hubble metrics",
              "type": "string",
              "enum": [
                "Ok",
                "Warning",
                "Failure",
                "Disabled"
              ]
            }
          }
        },
        "msg": {
          "description": "Human readable status/error/warning message",
          "type": "string"
        },
        "observer": {
          "description": "Status of the Hubble observer\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "current-flows": {
              "description": "Current number of flows this Hubble observer stores",
              "type": "integer"
            },
            "max-flows": {
              "description": "Maximum number of flows this Hubble observer is able to store",
              "type": "integer"
            },
            "seen-flows": {
              "description": "Total number of flows this Hubble observer has seen",
              "type": "integer"
            },
            "uptime": {
              "description": "Uptime of this Hubble observer instance",
              "type": "string",
              "format": "duration"
            }
          }
        },
        "state": {
          "description": "State the component is in",
          "type": "string",
          "enum": [
            "Ok",
            "Warning",
            "Failure",
            "Disabled"
          ]
        }
      }
    },
    "IPAMAddressResponse": {
      "description": "IPAM configuration of an individual address family",
      "type": "object",
      "properties": {
        "cidrs": {
          "description": "List of CIDRs out of which IPs are allocated",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "expiration-uuid": {
          "description": "The UUID for the expiration timer. Set when expiration has been\nenabled while allocating.\n",
          "type": "string"
        },
        "gateway": {
          "description": "IP of gateway",
          "type": "string"
        },
        "interface-number": {
          "description": "InterfaceNumber is a field for generically identifying an interface. This is only useful in ENI mode.\n",
          "type": "string"
        },
        "ip": {
          "description": "Allocated IP for endpoint",
          "type": "string"
        },
        "master-mac": {
          "description": "MAC of master interface if address is a slave/secondary of a master interface",
          "type": "string"
        }
      }
    },
    "IPAMResponse": {
      "description": "IPAM configuration of an endpoint",
      "type": "object",
      "required": [
        "address",
        "host-addressing"
      ],
      "properties": {
        "address": {
          "$ref": "#/definitions/AddressPair"
        },
        "host-addressing": {
          "$ref": "#/definitions/NodeAddressing"
        },
        "ipv4": {
          "$ref": "#/definitions/IPAMAddressResponse"
        },
        "ipv6": {
          "$ref": "#/definitions/IPAMAddressResponse"
        }
      }
    },
    "IPAMStatus": {
      "description": "Status of IP address management\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "allocations": {
          "$ref": "#/definitions/AllocationMap"
        },
        "ipv4": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "ipv6": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "status": {
          "type": "string"
        }
      }
    },
    "IPListEntry": {
      "description": "IP entry with metadata",
      "type": "object",
      "required": [
        "cidr",
        "identity"
      ],
      "properties": {
        "cidr": {
          "description": "Key of the entry in the form of a CIDR range",
          "type": "string"
        },
        "encryptKey": {
          "description": "The context ID for the encryption session",
          "type": "integer"
        },
        "hostIP": {
          "description": "IP address of the host",
          "type": "string"
        },
        "identity": {
          "description": "Numerical identity assigned to the IP",
          "type": "integer"
        },
        "metadata": {
          "$ref": "#/definitions/IPListEntryMetadata"
        }
      }
    },
    "IPListEntryMetadata": {
      "description": "Additional metadata assigned to an IP list entry",
      "type": "object",
      "properties": {
        "name": {
          "description": "Name assigned to the IP (e.g. Kubernetes pod name)",
          "type": "string"
        },
        "namespace": {
          "description": "Namespace of the IP (e.g. Kubernetes namespace)",
          "type": "string"
        },
        "source": {
          "description": "Source of the IP entry and its metadata",
          "type": "string",
          "example": "k8s"
        }
      }
    },
    "Identity": {
      "description": "Security identity",
      "type": "object",
      "properties": {
        "id": {
          "description": "Unique identifier",
          "type": "integer"
        },
        "labels": {
          "description": "Labels describing the identity",
          "$ref": "#/definitions/Labels"
        },
        "labelsSHA256": {
          "description": "SHA256 of labels",
          "type": "string"
        }
      }
    },
    "IdentityEndpoints": {
      "description": "Security identities owned by endpoints on the local node",
      "type": "object",
      "properties": {
        "identity": {
          "description": "Security identity",
          "$ref": "#/definitions/Identity"
        },
        "refCount": {
          "description": "number of endpoints consuming this identity locally (should always be \u003e 0)",
          "type": "integer"
        }
      }
    },
    "IpvlanConfiguration": {
      "description": "Setup for datapath when operating in ipvlan mode.",
      "type": "object",
      "properties": {
        "masterDeviceIndex": {
          "description": "Workload facing ipvlan master device ifindex.",
          "type": "integer"
        },
        "operationMode": {
          "description": "Mode in which ipvlan setup operates.",
          "type": "string",
          "enum": [
            "L3",
            "L3S"
          ]
        }
      }
    },
    "K8sStatus": {
      "description": "Status of Kubernetes integration\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "k8s-api-versions": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "msg": {
          "description": "Human readable status/error/warning message",
          "type": "string"
        },
        "state": {
          "description": "State the component is in",
          "type": "string",
          "enum": [
            "Ok",
            "Warning",
            "Failure",
            "Disabled"
          ]
        }
      }
    },
    "KVstoreConfiguration": {
      "description": "Configuration used for the kvstore",
      "properties": {
        "options": {
          "description": "Configuration options",
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        },
        "type": {
          "description": "Type of kvstore",
          "type": "string"
        }
      }
    },
    "KubeProxyReplacement": {
      "description": "Status of kube-proxy replacement\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "deviceList": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "array",
          "items": {
            "description": "\n\n+k8s:deepcopy-gen=true",
            "type": "object",
            "properties": {
              "ip": {
                "description": "\n\n+k8s:deepcopy-gen=true",
                "type": "array",
                "items": {
                  "type": "string"
                }
              },
              "name": {
                "type": "string"
              }
            }
          }
        },
        "devices": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "directRoutingDevice": {
          "type": "string"
        },
        "features": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "externalIPs": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                }
              }
            },
            "gracefulTermination": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                }
              }
            },
            "hostPort": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                }
              }
            },
            "hostReachableServices": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                },
                "protocols": {
                  "type": "array",
                  "items": {
                    "type": "string"
                  }
                }
              }
            },
            "nodePort": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "acceleration": {
                  "type": "string",
                  "enum": [
                    "None",
                    "Native",
                    "Generic"
                  ]
                },
                "algorithm": {
                  "type": "string",
                  "enum": [
                    "Random",
                    "Maglev"
                  ]
                },
                "enabled": {
                  "type": "boolean"
                },
                "lutSize": {
                  "type": "integer"
                },
                "mode": {
                  "type": "string",
                  "enum": [
                    "SNAT",
                    "DSR",
                    "Hybrid"
                  ]
                },
                "portMax": {
                  "type": "integer"
                },
                "portMin": {
                  "type": "integer"
                }
              }
            },
            "sessionAffinity": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                }
              }
            }
          }
        },
        "mode": {
          "type": "string",
          "enum": [
            "Disabled",
            "Strict",
            "Probe",
            "Partial"
          ]
        }
      }
    },
    "L4Policy": {
      "description": "L4 endpoint policy\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "egress": {
          "description": "List of L4 egress rules",
          "type": "array",
          "items": {
            "$ref": "#/definitions/PolicyRule"
          }
        },
        "ingress": {
          "description": "List of L4 ingress rules",
          "type": "array",
          "items": {
            "$ref": "#/definitions/PolicyRule"
          }
        }
      }
    },
    "LRPBackend": {
      "description": "Pod backend of an LRP",
      "type": "object",
      "properties": {
        "backend-address": {
          "$ref": "#/definitions/BackendAddress"
        },
        "pod-id": {
          "description": "Namespace and name of the backend pod",
          "type": "string"
        }
      }
    },
    "LRPSpec": {
      "description": "Configuration of an LRP",
      "type": "object",
      "properties": {
        "frontend-mappings": {
          "description": "mapping of frontends to pod backends",
          "type": "array",
          "items": {
            "$ref": "#/definitions/FrontendMapping"
          }
        },
        "frontend-type": {
          "description": "LRP frontend type",
          "type": "string"
        },
        "lrp-type": {
          "description": "LRP config type",
          "type": "string"
        },
        "name": {
          "description": "LRP service name",
          "type": "string"
        },
        "namespace": {
          "description": "LRP service namespace",
          "type": "string"
        },
        "service-id": {
          "description": "matching k8s service namespace and name",
          "type": "string"
        },
        "uid": {
          "description": "Unique identification",
          "type": "string"
        }
      }
    },
    "LabelConfiguration": {
      "description": "Label configuration of an endpoint",
      "type": "object",
      "properties": {
        "spec": {
          "description": "The user provided desired configuration",
          "$ref": "#/definitions/LabelConfigurationSpec"
        },
        "status": {
          "description": "The current configuration",
          "$ref": "#/definitions/LabelConfigurationStatus"
        }
      }
    },
    "LabelConfigurationSpec": {
      "description": "User desired Label configuration of an endpoint",
      "type": "object",
      "properties": {
        "user": {
          "description": "Custom labels in addition to orchestration system labels.",
          "$ref": "#/definitions/Labels"
        }
      }
    },
    "LabelConfigurationStatus": {
      "description": "Labels and label configuration of an endpoint",
      "type": "object",
      "properties": {
        "derived": {
          "description": "All labels derived from the orchestration system",
          "$ref": "#/definitions/Labels"
        },
        "disabled": {
          "description": "Labels derived from orchestration system which have been disabled.",
          "$ref": "#/definitions/Labels"
        },
        "realized": {
          "description": "The current configuration",
          "$ref": "#/definitions/LabelConfigurationSpec"
        },
        "security-relevant": {
          "description": "Labels derived from orchestration system that are used in computing a security identity",
          "$ref": "#/definitions/Labels"
        }
      }
    },
    "Labels": {
      "description": "Set of labels",
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "Masquerading": {
      "description": "Status of masquerading\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "enabled": {
          "type": "boolean"
        },
        "enabledProtocols": {
          "description": "Is masquerading enabled",
          "type": "object",
          "properties": {
            "ipv4": {
              "description": "Is masquerading enabled for IPv4 traffic",
              "type": "boolean"
            },
            "ipv6": {
              "description": "Is masquerading enabled for IPv6 traffic",
              "type": "boolean"
            }
          }
        },
        "ip-masq-agent": {
          "description": "Is BPF ip-masq-agent enabled",
          "type": "boolean"
        },
        "mode": {
          "type": "string",
          "enum": [
            "BPF",
            "iptables"
          ]
        },
        "snat-exclusion-cidr": {
          "description": "This field is obsolete, please use snat-exclusion-cidr-v4 or snat-exclusion-cidr-v6.",
          "type": "string"
        },
        "snat-exclusion-cidr-v4": {
          "description": "SnatExclusionCIDRv4 exempts SNAT from being performed on any packet sent to\nan IPv4 address that belongs to this CIDR.",
          "type": "string"
        },
        "snat-exclusion-cidr-v6": {
          "description": "SnatExclusionCIDRv6 exempts SNAT from being performed on any packet sent to\nan IPv6 address that belongs to this CIDR.\nFor IPv6 we only do masquerading in iptables mode.",
          "type": "string"
        }
      }
    },
    "MessageForwardingStatistics": {
      "description": "Statistics of a message forwarding entity",
      "type": "object",
      "properties": {
        "denied": {
          "description": "Number of messages denied",
          "type": "integer"
        },
        "error": {
          "description": "Number of errors while parsing messages",
          "type": "integer"
        },
        "forwarded": {
          "description": "Number of messages forwarded",
          "type": "integer"
        },
        "received": {
          "description": "Number of messages received",
          "type": "integer"
        }
      }
    },
    "Metric": {
      "description": "Metric information",
      "type": "object",
      "properties": {
        "labels": {
          "description": "Labels of the metric",
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        },
        "name": {
          "description": "Name of the metric",
          "type": "string"
        },
        "value": {
          "description": "Value of the metric",
          "type": "number"
        }
      }
    },
    "MonitorStatus": {
      "description": "Status of the node monitor",
      "properties": {
        "cpus": {
          "description": "Number of CPUs to listen on for events.",
          "type": "integer"
        },
        "lost": {
          "description": "Number of samples lost by perf.",
          "type": "integer"
        },
        "npages": {
          "description": "Number of pages used for the perf ring buffer.",
          "type": "integer"
        },
        "pagesize": {
          "description": "Pages size used for the perf ring buffer.",
          "type": "integer"
        },
        "unknown": {
          "description": "Number of unknown samples.",
          "type": "integer"
        }
      }
    },
    "NameManager": {
      "description": "Internal state about DNS names in relation to policy subsystem",
      "type": "object",
      "properties": {
        "DNSPollNames": {
          "description": "Names to poll for DNS Poller",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "FQDNPolicySelectors": {
          "description": "Mapping of FQDNSelectors to corresponding regular expressions",
          "type": "array",
          "items": {
            "$ref": "#/definitions/SelectorEntry"
          }
        }
      }
    },
    "NamedPorts": {
      "description": "List of named Layer 4 port and protocol pairs which will be used in Network\nPolicy specs.\n\n+deepequal-gen=true\n+k8s:deepcopy-gen=true",
      "type": "array",
      "items": {
        "$ref": "#/definitions/Port"
      }
    },
    "NodeAddressing": {
      "description": "Addressing information of a node for all address families\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "ipv4": {
          "$ref": "#/definitions/NodeAddressingElement"
        },
        "ipv6": {
          "$ref": "#/definitions/NodeAddressingElement"
        }
      }
    },
    "NodeAddressingElement": {
      "description": "Addressing information",
      "type": "object",
      "properties": {
        "address-type": {
          "description": "Node address type, one of HostName, ExternalIP or InternalIP",
          "type": "string"
        },
        "alloc-range": {
          "description": "Address pool to be used for local endpoints",
          "type": "string"
        },
        "enabled": {
          "description": "True if address family is enabled",
          "type": "boolean"
        },
        "ip": {
          "description": "IP address of node",
          "type": "string"
        }
      }
    },
    "NodeElement": {
      "description": "Known node in the cluster\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "health-endpoint-address": {
          "description": "Address used for probing cluster connectivity",
          "$ref": "#/definitions/NodeAddressing"
        },
        "name": {
          "description": "Name of the node including the cluster association. This is typically\n\u003cclustername\u003e/\u003chostname\u003e.\n",
          "type": "string"
        },
        "primary-address": {
          "description": "Primary address used for intra-cluster communication",
          "$ref": "#/definitions/NodeAddressing"
        },
        "secondary-addresses": {
          "description": "Alternative addresses assigned to the node",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeAddressingElement"
          }
        }
      }
    },
    "Policy": {
      "description": "Policy definition",
      "type": "object",
      "properties": {
        "policy": {
          "description": "Policy definition as JSON.",
          "type": "string"
        },
        "revision": {
          "description": "Revision number of the policy. Incremented each time the policy is\nchanged in the agent's repository\n",
          "type": "integer"
        }
      }
    },
    "PolicyRule": {
      "description": "A policy rule including the rule labels it derives from\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "derived-from-rules": {
          "description": "The policy rule labels identifying the policy rules this rule derives from",
          "type": "array",
          "items": {
            "type": "array",
            "items": {
              "type": "string"
            }
          }
        },
        "rule": {
          "description": "The policy rule as json",
          "type": "string"
        }
      }
    },
    "PolicyTraceResult": {
      "description": "Response to a policy resolution process",
      "type": "object",
      "properties": {
        "log": {
          "type": "string"
        },
        "verdict": {
          "type": "string"
        }
      }
    },
    "Port": {
      "description": "Layer 4 port / protocol pair\n\n+deepequal-gen=true",
      "type": "object",
      "properties": {
        "name": {
          "description": "Optional layer 4 port name",
          "type": "string"
        },
        "port": {
          "description": "Layer 4 port number",
          "type": "integer",
          "format": "uint16"
        },
        "protocol": {
          "description": "Layer 4 protocol",
          "type": "string",
          "enum": [
            "TCP",
            "UDP",
            "ICMP",
            "ICMPV6",
            "ANY"
          ]
        }
      }
    },
    "Prefilter": {
      "description": "Collection of endpoints to be served",
      "type": "object",
      "properties": {
        "spec": {
          "$ref": "#/definitions/PrefilterSpec"
        },
        "status": {
          "$ref": "#/definitions/PrefilterStatus"
        }
      }
    },
    "PrefilterSpec": {
      "description": "CIDR ranges implemented in the Prefilter",
      "type": "object",
      "properties": {
        "deny": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "revision": {
          "type": "integer"
        }
      }
    },
    "PrefilterStatus": {
      "description": "CIDR ranges implemented in the Prefilter",
      "type": "object",
      "properties": {
        "realized": {
          "$ref": "#/definitions/PrefilterSpec"
        }
      }
    },
    "ProxyRedirect": {
      "description": "Configured proxy redirection state",
      "type": "object",
      "properties": {
        "name": {
          "description": "Name of the proxy redirect",
          "type": "string"
        },
        "proxy": {
          "description": "Name of the proxy this redirect points to",
          "type": "string"
        },
        "proxy-port": {
          "description": "Host port that this redirect points to",
          "type": "integer"
        }
      }
    },
    "ProxyStatistics": {
      "description": "Statistics of a set of proxy redirects for an endpoint\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "allocated-proxy-port": {
          "description": "The port the proxy is listening on",
          "type": "integer"
        },
        "location": {
          "description": "Location of where the redirect is installed",
          "type": "string",
          "enum": [
            "ingress",
            "egress"
          ]
        },
        "port": {
          "description": "The port subject to the redirect",
          "type": "integer"
        },
        "protocol": {
          "description": "Name of the L7 protocol",
          "type": "string"
        },
        "statistics": {
          "description": "Statistics of this set of proxy redirect",
          "$ref": "#/definitions/RequestResponseStatistics"
        }
      }
    },
    "ProxyStatus": {
      "description": "Status of proxy\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "ip": {
          "description": "IP address that the proxy listens on",
          "type": "string"
        },
        "port-range": {
          "description": "Port range used for proxying",
          "type": "string"
        },
        "redirects": {
          "description": "Detailed description of configured redirects",
          "type": "array",
          "items": {
            "$ref": "#/definitions/ProxyRedirect"
          }
        },
        "total-ports": {
          "description": "Total number of listening proxy ports",
          "type": "integer"
        },
        "total-redirects": {
          "description": "Total number of ports configured to redirect to proxies",
          "type": "integer"
        }
      }
    },
    "Recorder": {
      "description": "Collection of wildcard filters for pcap recorder",
      "type": "object",
      "properties": {
        "spec": {
          "$ref": "#/definitions/RecorderSpec"
        },
        "status": {
          "$ref": "#/definitions/RecorderStatus"
        }
      }
    },
    "RecorderFilter": {
      "description": "n-tuple filter to match traffic to be recorded",
      "type": "object",
      "properties": {
        "dst-port": {
          "description": "Layer 4 destination port, zero (or in future range)",
          "type": "string"
        },
        "dst-prefix": {
          "description": "Layer 3 destination CIDR",
          "type": "string"
        },
        "protocol": {
          "description": "Layer 4 protocol",
          "type": "string",
          "enum": [
            "TCP",
            "UDP",
            "ANY"
          ]
        },
        "src-port": {
          "description": "Layer 4 source port, zero (or in future range)",
          "type": "string"
        },
        "src-prefix": {
          "description": "Layer 3 source CIDR",
          "type": "string"
        }
      }
    },
    "RecorderMask": {
      "description": "Individual mask for pcap recorder",
      "type": "object",
      "properties": {
        "status": {
          "$ref": "#/definitions/RecorderMaskStatus"
        }
      }
    },
    "RecorderMaskSpec": {
      "description": "Configuration of a recorder mask",
      "type": "object",
      "properties": {
        "dst-port-mask": {
          "description": "Layer 4 destination port mask",
          "type": "string"
        },
        "dst-prefix-mask": {
          "description": "Layer 3 destination IP mask",
          "type": "string"
        },
        "priority": {
          "description": "Priority of this mask",
          "type": "integer"
        },
        "protocol-mask": {
          "description": "Layer 4 protocol mask",
          "type": "string"
        },
        "src-port-mask": {
          "description": "Layer 4 source port mask",
          "type": "string"
        },
        "src-prefix-mask": {
          "description": "Layer 3 source IP mask",
          "type": "string"
        },
        "users": {
          "description": "Number of users of this mask",
          "type": "integer"
        }
      }
    },
    "RecorderMaskStatus": {
      "description": "Configuration of a recorder mask",
      "type": "object",
      "properties": {
        "realized": {
          "$ref": "#/definitions/RecorderMaskSpec"
        }
      }
    },
    "RecorderSpec": {
      "description": "Configuration of a recorder",
      "type": "object",
      "required": [
        "id",
        "filters"
      ],
      "properties": {
        "capture-length": {
          "description": "Maximum packet length or zero for full packet length",
          "type": "integer"
        },
        "filters": {
          "description": "List of wildcard filters for given recorder",
          "type": "array",
          "items": {
            "$ref": "#/definitions/RecorderFilter"
          }
        },
        "id": {
          "description": "Unique identification",
          "type": "integer"
        }
      }
    },
    "RecorderStatus": {
      "description": "Configuration of a recorder",
      "type": "object",
      "properties": {
        "realized": {
          "$ref": "#/definitions/RecorderSpec"
        }
      }
    },
    "RemoteCluster": {
      "description": "Status of remote cluster\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "last-failure": {
          "description": "Time of last failure that occurred while attempting to reach the cluster",
          "type": "string",
          "format": "date-time"
        },
        "name": {
          "description": "Name of the cluster",
          "type": "string"
        },
        "num-failures": {
          "description": "Number of failures reaching the cluster",
          "type": "integer"
        },
        "num-identities": {
          "description": "Number of identities in the cluster",
          "type": "integer"
        },
        "num-nodes": {
          "description": "Number of nodes in the cluster",
          "type": "integer"
        },
        "num-shared-services": {
          "description": "Number of services in the cluster",
          "type": "integer"
        },
        "ready": {
          "description": "Indicates readiness of the remote cluser",
          "type": "boolean"
        },
        "status": {
          "description": "Status of the control plane",
          "type": "string"
        }
      }
    },
    "RequestResponseStatistics": {
      "description": "Statistics of a proxy redirect\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "requests": {
          "$ref": "#/definitions/MessageForwardingStatistics"
        },
        "responses": {
          "$ref": "#/definitions/MessageForwardingStatistics"
        }
      }
    },
    "SelectorCache": {
      "description": "cache of which identities match selectors in the policy repository",
      "type": "array",
      "items": {
        "$ref": "#/definitions/SelectorIdentityMapping"
      }
    },
    "SelectorEntry": {
      "description": "Mapping of FQDNSelector to corresponding regular expression",
      "type": "object",
      "properties": {
        "regexString": {
          "description": "String representation of regular expression form of FQDNSelector",
          "type": "string"
        },
        "selectorString": {
          "description": "FQDNSelector in string representation",
          "type": "string"
        }
      }
    },
    "SelectorIdentityMapping": {
      "description": "mapping of selector to identities which match it",
      "type": "object",
      "properties": {
        "identities": {
          "description": "identities mapping to this selector",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "selector": {
          "description": "string form of selector",
          "type": "string"
        },
        "users": {
          "description": "number of users of this selector in the cache",
          "type": "integer"
        }
      }
    },
    "Service": {
      "description": "Collection of endpoints to be served",
      "type": "object",
      "properties": {
        "spec": {
          "$ref": "#/definitions/ServiceSpec"
        },
        "status": {
          "$ref": "#/definitions/ServiceStatus"
        }
      }
    },
    "ServiceSpec": {
      "description": "Configuration of a service",
      "type": "object",
      "required": [
        "frontend-address"
      ],
      "properties": {
        "backend-addresses": {
          "description": "List of backend addresses",
          "type": "array",
          "items": {
            "$ref": "#/definitions/BackendAddress"
          }
        },
        "flags": {
          "description": "Optional service configuration flags",
          "type": "object",
          "properties": {
            "healthCheckNodePort": {
              "description": "Service health check node port",
              "type": "integer",
              "format": "uint16"
            },
            "name": {
              "description": "Service name  (e.g. Kubernetes service name)",
              "type": "string"
            },
            "namespace": {
              "description": "Service namespace  (e.g. Kubernetes namespace)",
              "type": "string"
            },
            "trafficPolicy": {
              "description": "Service traffic policy",
              "type": "string",
              "enum": [
                "Cluster",
                "Local"
              ]
            },
            "type": {
              "description": "Service type",
              "type": "string",
              "enum": [
                "ClusterIP",
                "NodePort",
                "ExternalIPs",
                "HostPort",
                "LoadBalancer",
                "LocalRedirect"
              ]
            }
          }
        },
        "frontend-address": {
          "description": "Frontend address",
          "$ref": "#/definitions/FrontendAddress"
        },
        "id": {
          "description": "Unique identification",
          "type": "integer"
        }
      }
    },
    "ServiceStatus": {
      "description": "Configuration of a service",
      "type": "object",
      "properties": {
        "realized": {
          "$ref": "#/definitions/ServiceSpec"
        }
      }
    },
    "Status": {
      "description": "Status of an individual component",
      "type": "object",
      "properties": {
        "msg": {
          "description": "Human readable status/error/warning message",
          "type": "string"
        },
        "state": {
          "description": "State the component is in",
          "type": "string",
          "enum": [
            "Ok",
            "Warning",
            "Failure",
            "Disabled"
          ]
        }
      }
    },
    "StatusResponse": {
      "description": "Health and status information of daemon\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "bandwidth-manager": {
          "description": "Status of bandwidth manager",
          "$ref": "#/definitions/BandwidthManager"
        },
        "bpf-maps": {
          "description": "Status of BPF maps",
          "$ref": "#/definitions/BPFMapStatus"
        },
        "cilium": {
          "description": "Status of Cilium daemon",
          "$ref": "#/definitions/Status"
        },
        "client-id": {
          "description": "When supported by the API, this client ID should be used by the\nclient when making another request to the server.\nSee for example \"/cluster/nodes\".\n",
          "type": "integer"
        },
        "clock-source": {
          "description": "Status of clock source",
          "$ref": "#/definitions/ClockSource"
        },
        "cluster": {
          "description": "Status of cluster",
          "$ref": "#/definitions/ClusterStatus"
        },
        "cluster-mesh": {
          "description": "Status of ClusterMesh",
          "$ref": "#/definitions/ClusterMeshStatus"
        },
        "container-runtime": {
          "description": "Status of local container runtime",
          "$ref": "#/definitions/Status"
        },
        "controllers": {
          "description": "Status of all endpoint controllers",
          "$ref": "#/definitions/ControllerStatuses"
        },
        "encryption": {
          "description": "Status of transparent encryption",
          "$ref": "#/definitions/EncryptionStatus"
        },
        "host-firewall": {
          "description": "Status of the host firewall",
          "$ref": "#/definitions/HostFirewall"
        },
        "host-routing": {
          "description": "Status of host routing",
          "$ref": "#/definitions/HostRouting"
        },
        "hubble": {
          "description": "Status of Hubble server",
          "$ref": "#/definitions/HubbleStatus"
        },
        "ipam": {
          "description": "Status of IP address management",
          "$ref": "#/definitions/IPAMStatus"
        },
        "kube-proxy-replacement": {
          "description": "Status of kube-proxy replacement",
          "$ref": "#/definitions/KubeProxyReplacement"
        },
        "kubernetes": {
          "description": "Status of Kubernetes integration",
          "$ref": "#/definitions/K8sStatus"
        },
        "kvstore": {
          "description": "Status of key/value datastore",
          "$ref": "#/definitions/Status"
        },
        "masquerading": {
          "description": "Status of masquerading",
          "$ref": "#/definitions/Masquerading"
        },
        "nodeMonitor": {
          "description": "Status of the node monitor",
          "$ref": "#/definitions/MonitorStatus"
        },
        "proxy": {
          "description": "Status of proxy",
          "$ref": "#/definitions/ProxyStatus"
        },
        "stale": {
          "description": "List of stale information in the status",
          "type": "object",
          "additionalProperties": {
            "description": "Timestamp when the probe was started",
            "type": "string",
            "format": "date-time"
          }
        }
      }
    },
    "TraceFrom": {
      "type": "object",
      "properties": {
        "labels": {
          "$ref": "#/definitions/Labels"
        }
      }
    },
    "TraceSelector": {
      "description": "Context describing a pair of source and destination identity",
      "type": "object",
      "properties": {
        "from": {
          "$ref": "#/definitions/TraceFrom"
        },
        "to": {
          "$ref": "#/definitions/TraceTo"
        },
        "verbose": {
          "description": "Enable verbose tracing.\n",
          "type": "boolean"
        }
      }
    },
    "TraceTo": {
      "type": "object",
      "properties": {
        "dports": {
          "description": "List of Layer 4 port and protocol pairs which will be used in communication\nfrom the source identity to the destination identity.\n",
          "type": "array",
          "items": {
            "$ref": "#/definitions/Port"
          }
        },
        "labels": {
          "$ref": "#/definitions/Labels"
        }
      }
    },
    "WireguardInterface": {
      "description": "Status of a Wireguard interface\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "listen-port": {
          "description": "Port on which the Wireguard endpoint is exposed",
          "type": "integer"
        },
        "name": {
          "description": "Name of the interface",
          "type": "string"
        },
        "peer-count": {
          "description": "Number of peers configured on this interface",
          "type": "integer"
        },
        "peers": {
          "description": "Optional list of wireguard peers",
          "type": "array",
          "items": {
            "$ref": "#/definitions/WireguardPeer"
          }
        },
        "public-key": {
          "description": "Public key of this interface",
          "type": "string"
        }
      }
    },
    "WireguardPeer": {
      "description": "Status of a Wireguard peer\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "allowed-ips": {
          "description": "List of IPs which may be routed through this peer",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "endpoint": {
          "description": "Endpoint on which we are connected to this peer",
          "type": "string"
        },
        "last-handshake-time": {
          "description": "Timestamp of the last handshake with this peer",
          "type": "string",
          "format": "date-time"
        },
        "public-key": {
          "description": "Public key of this peer",
          "type": "string"
        },
        "transfer-rx": {
          "description": "Number of received bytes",
          "type": "integer"
        },
        "transfer-tx": {
          "description": "Number of sent bytes",
          "type": "integer"
        }
      }
    },
    "WireguardStatus": {
      "description": "Status of the Wireguard agent\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "interfaces": {
          "description": "Wireguard interfaces managed by this Cilium instance",
          "type": "array",
          "items": {
            "$ref": "#/definitions/WireguardInterface"
          }
        }
      }
    }
  },
  "parameters": {
    "cidr": {
      "type": "string",
      "description": "A CIDR range of IPs",
      "name": "cidr",
      "in": "query"
    },
    "endpoint-change-request": {
      "name": "endpoint",
      "in": "body",
      "required": true,
      "schema": {
        "$ref": "#/definitions/EndpointChangeRequest"
      }
    },
    "endpoint-id": {
      "type": "string",
      "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
      "name": "id",
      "in": "path",
      "required": true
    },
    "identity-id": {
      "type": "string",
      "description": "Cluster wide unique identifier of a security identity.\n",
      "name": "id",
      "in": "path",
      "required": true
    },
    "ipam-expiration": {
      "type": "boolean",
      "name": "expiration",
      "in": "header"
    },
    "ipam-family": {
      "enum": [
        "ipv4",
        "ipv6"
      ],
      "type": "string",
      "name": "family",
      "in": "query"
    },
    "ipam-ip": {
      "type": "string",
      "description": "IP address",
      "name": "ip",
      "in": "path",
      "required": true
    },
    "ipam-owner": {
      "type": "string",
      "name": "owner",
      "in": "query"
    },
    "ipam-release-arg": {
      "type": "string",
      "description": "IP address or owner name",
      "name": "ip",
      "in": "path",
      "required": true
    },
    "labels": {
      "description": "List of labels\n",
      "name": "labels",
      "in": "body",
      "schema": {
        "$ref": "#/definitions/Labels"
      }
    },
    "map-name": {
      "type": "string",
      "description": "Name of map",
      "name": "name",
      "in": "path",
      "required": true
    },
    "matchpattern": {
      "type": "string",
      "description": "A toFQDNs compatible matchPattern expression",
      "name": "matchpattern",
      "in": "query"
    },
    "pod-name": {
      "type": "string",
      "description": "K8s pod name\n",
      "name": "pod",
      "in": "path",
      "required": true
    },
    "policy-rules": {
      "description": "Policy rules",
      "name": "policy",
      "in": "body",
      "required": true,
      "schema": {
        "type": "string"
      }
    },
    "prefilter-spec": {
      "description": "List of CIDR ranges for filter table",
      "name": "prefilter-spec",
      "in": "body",
      "required": true,
      "schema": {
        "$ref": "#/definitions/PrefilterSpec"
      }
    },
    "recorder-config": {
      "description": "Recorder configuration",
      "name": "config",
      "in": "body",
      "required": true,
      "schema": {
        "$ref": "#/definitions/RecorderSpec"
      }
    },
    "recorder-id": {
      "type": "integer",
      "description": "ID of recorder",
      "name": "id",
      "in": "path",
      "required": true
    },
    "service-address": {
      "description": "Service address configuration",
      "name": "address",
      "in": "body",
      "schema": {
        "$ref": "#/definitions/FrontendAddress"
      }
    },
    "service-config": {
      "description": "Service configuration",
      "name": "config",
      "in": "body",
      "required": true,
      "schema": {
        "$ref": "#/definitions/ServiceSpec"
      }
    },
    "service-id": {
      "type": "integer",
      "description": "ID of service",
      "name": "id",
      "in": "path",
      "required": true
    },
    "trace-selector": {
      "description": "Context to provide policy evaluation on",
      "name": "trace-selector",
      "in": "body",
      "schema": {
        "$ref": "#/definitions/TraceSelector"
      }
    }
  },
  "x-schemes": [
    "unix"
  ]
}`));FlatSwaggerJSON=json.RawMessage([]byte(`{
  "consumes": [
    "application/json"
  ],
  "produces": [
    "application/json"
  ],
  "swagger": "2.0",
  "info": {
    "description": "Cilium",
    "title": "Cilium API",
    "version": "v1beta"
  },
  "basePath": "/v1",
  "paths": {
    "/cluster/nodes": {
      "get": {
        "tags": [
          "daemon"
        ],
        "summary": "Get nodes information stored in the cilium-agent",
        "parameters": [
          {
            "type": "integer",
            "description": "Client UUID should be used when the client wants to request\na diff of nodes added and / or removed since the last time\nthat client has made a request.\n",
            "name": "client-id",
            "in": "header"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/ClusterNodeStatus"
            }
          }
        }
      }
    },
    "/config": {
      "get": {
        "description": "Returns the configuration of the Cilium daemon.\n",
        "tags": [
          "daemon"
        ],
        "summary": "Get configuration of Cilium daemon",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/DaemonConfiguration"
            }
          }
        }
      },
      "patch": {
        "description": "Updates the daemon configuration by applying the provided\nConfigurationMap and regenerates \u0026 recompiles all required datapath\ncomponents.\n",
        "tags": [
          "daemon"
        ],
        "summary": "Modify daemon configuration",
        "parameters": [
          {
            "name": "configuration",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/DaemonConfigurationSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Bad configuration parameters",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          },
          "500": {
            "description": "Recompilation failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/debuginfo": {
      "get": {
        "tags": [
          "daemon"
        ],
        "summary": "Retrieve information about the agent and evironment for debugging",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/DebugInfo"
            }
          },
          "500": {
            "description": "DebugInfo get failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/endpoint": {
      "get": {
        "description": "Retrieves a list of endpoints that have metadata matching the provided parameters, or all endpoints if no parameters provided.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieves a list of endpoints that have metadata matching the provided parameters.",
        "parameters": [
          {
            "description": "List of labels\n",
            "name": "labels",
            "in": "body",
            "schema": {
              "$ref": "#/definitions/Labels"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Endpoint"
              }
            }
          },
          "404": {
            "description": "Endpoints with provided parameters not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      }
    },
    "/endpoint/{id}": {
      "get": {
        "description": "Returns endpoint information\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Get endpoint by endpoint ID",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Endpoint"
            }
          },
          "400": {
            "description": "Invalid endpoint ID format for specified type",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      },
      "put": {
        "description": "Creates a new endpoint\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Create endpoint",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          },
          {
            "name": "endpoint",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/EndpointChangeRequest"
            }
          }
        ],
        "responses": {
          "201": {
            "description": "Created"
          },
          "400": {
            "description": "Invalid endpoint in request",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "409": {
            "description": "Endpoint already exists",
            "x-go-name": "Exists"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          },
          "500": {
            "description": "Endpoint creation failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failed"
          }
        }
      },
      "delete": {
        "description": "Deletes the endpoint specified by the ID. Deletion is imminent and\natomic, if the deletion request is valid and the endpoint exists,\ndeletion will occur even if errors are encountered in the process. If\nerrors have been encountered, the code 202 will be returned, otherwise\n200 on success.\n\nAll resources associated with the endpoint will be freed and the\nworkload represented by the endpoint will be disconnected.It will no\nlonger be able to initiate or receive communications of any sort.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Delete endpoint",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "206": {
            "description": "Deleted with a number of errors encountered",
            "schema": {
              "type": "integer"
            },
            "x-go-name": "Errors"
          },
          "400": {
            "description": "Invalid endpoint ID format for specified type. Details in error\nmessage\n",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      },
      "patch": {
        "description": "Applies the endpoint change request to an existing endpoint\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Modify existing endpoint",
        "deprecated": true,
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          },
          {
            "name": "endpoint",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/EndpointChangeRequest"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid modify endpoint request",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint does not exist"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          },
          "500": {
            "description": "Endpoint update failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failed"
          }
        }
      }
    },
    "/endpoint/{id}/config": {
      "get": {
        "description": "Retrieves the configuration of the specified endpoint.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieve endpoint configuration",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/EndpointConfigurationStatus"
            }
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      },
      "patch": {
        "description": "Update the configuration of an existing endpoint and regenerates \u0026\nrecompiles the corresponding programs automatically.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Modify mutable endpoint configuration",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          },
          {
            "name": "endpoint-configuration",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/EndpointConfigurationSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid configuration request",
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          },
          "500": {
            "description": "Update failed. Details in message.",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failed"
          }
        }
      }
    },
    "/endpoint/{id}/healthz": {
      "get": {
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieves the status logs associated with this endpoint.",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/EndpointHealth"
            }
          },
          "400": {
            "description": "Invalid identity provided",
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      }
    },
    "/endpoint/{id}/labels": {
      "get": {
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieves the list of labels associated with an endpoint.",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/LabelConfiguration"
            }
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      },
      "patch": {
        "description": "Sets labels associated with an endpoint. These can be user provided or\nderived from the orchestration system.\n",
        "tags": [
          "endpoint"
        ],
        "summary": "Set label configuration of endpoint",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          },
          {
            "name": "configuration",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/LabelConfigurationSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          },
          "500": {
            "description": "Error while updating labels",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "UpdateFailed"
          }
        }
      }
    },
    "/endpoint/{id}/log": {
      "get": {
        "tags": [
          "endpoint"
        ],
        "summary": "Retrieves the status logs associated with this endpoint.",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/EndpointStatusLog"
            }
          },
          "400": {
            "description": "Invalid identity provided",
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Endpoint not found"
          },
          "429": {
            "description": "Rate-limiting too many requests in the given time frame"
          }
        }
      }
    },
    "/fqdn/cache": {
      "get": {
        "description": "Retrieves the list of DNS lookups intercepted from endpoints,\noptionally filtered by endpoint id, DNS name, or CIDR IP range.\n",
        "tags": [
          "policy"
        ],
        "summary": "Retrieves the list of DNS lookups intercepted from all endpoints.",
        "parameters": [
          {
            "type": "string",
            "description": "A toFQDNs compatible matchPattern expression",
            "name": "matchpattern",
            "in": "query"
          },
          {
            "type": "string",
            "description": "A CIDR range of IPs",
            "name": "cidr",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/DNSLookup"
              }
            }
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          },
          "404": {
            "description": "No DNS data with provided parameters found"
          }
        }
      },
      "delete": {
        "description": "Deletes matching DNS lookups from the cache, optionally restricted by\nDNS name. The removed IP data will no longer be used in generated\npolicies.\n",
        "tags": [
          "policy"
        ],
        "summary": "Deletes matching DNS lookups from the policy-generation cache.",
        "parameters": [
          {
            "type": "string",
            "description": "A toFQDNs compatible matchPattern expression",
            "name": "matchpattern",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          }
        }
      }
    },
    "/fqdn/cache/{id}": {
      "get": {
        "description": "Retrieves the list of DNS lookups intercepted from endpoints,\noptionally filtered by endpoint id, DNS name, or CIDR IP range.\n",
        "tags": [
          "policy"
        ],
        "summary": "Retrieves the list of DNS lookups intercepted from an endpoint.",
        "parameters": [
          {
            "type": "string",
            "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
            "name": "id",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "description": "A toFQDNs compatible matchPattern expression",
            "name": "matchpattern",
            "in": "query"
          },
          {
            "type": "string",
            "description": "A CIDR range of IPs",
            "name": "cidr",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/DNSLookup"
              }
            }
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          },
          "404": {
            "description": "No DNS data with provided parameters found"
          }
        }
      }
    },
    "/fqdn/names": {
      "get": {
        "description": "Retrieves the list of DNS-related fields (names to poll, selectors and\ntheir corresponding regexes).\n",
        "tags": [
          "policy"
        ],
        "summary": "List internal DNS selector representations",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/NameManager"
            }
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          }
        }
      }
    },
    "/healthz": {
      "get": {
        "description": "Returns health and status information of the Cilium daemon and related\ncomponents such as the local container runtime, connected datastore,\nKubernetes integration and Hubble.\n",
        "tags": [
          "daemon"
        ],
        "summary": "Get health of Cilium daemon",
        "parameters": [
          {
            "type": "boolean",
            "description": "Brief will return a brief representation of the Cilium status.\n",
            "name": "brief",
            "in": "header"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/StatusResponse"
            }
          }
        }
      }
    },
    "/identity": {
      "get": {
        "description": "Retrieves a list of identities that have metadata matching the provided parameters, or all identities if no parameters are provided.\n",
        "tags": [
          "policy"
        ],
        "summary": "Retrieves a list of identities that have metadata matching the provided parameters.",
        "parameters": [
          {
            "description": "List of labels\n",
            "name": "labels",
            "in": "body",
            "schema": {
              "$ref": "#/definitions/Labels"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Identity"
              }
            }
          },
          "404": {
            "description": "Identities with provided parameters not found"
          },
          "520": {
            "description": "Identity storage unreachable. Likely a network problem.",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Unreachable"
          },
          "521": {
            "description": "Invalid identity format in storage",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidStorageFormat"
          }
        }
      }
    },
    "/identity/endpoints": {
      "get": {
        "tags": [
          "policy"
        ],
        "summary": "Retrieve identities which are being used by local endpoints",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/IdentityEndpoints"
              }
            }
          },
          "404": {
            "description": "Set of identities which are being used by local endpoints could not be found."
          }
        }
      }
    },
    "/identity/{id}": {
      "get": {
        "tags": [
          "policy"
        ],
        "summary": "Retrieve identity",
        "parameters": [
          {
            "type": "string",
            "description": "Cluster wide unique identifier of a security identity.\n",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Identity"
            }
          },
          "400": {
            "description": "Invalid identity provided"
          },
          "404": {
            "description": "Identity not found"
          },
          "520": {
            "description": "Identity storage unreachable. Likely a network problem.",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Unreachable"
          },
          "521": {
            "description": "Invalid identity format in storage",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidStorageFormat"
          }
        }
      }
    },
    "/ip": {
      "get": {
        "description": "Retrieves a list of IPs with known associated information such as\ntheir identities, host addresses, Kubernetes pod names, etc.\nThe list can optionally filtered by a CIDR IP range.\n",
        "tags": [
          "policy"
        ],
        "summary": "Lists information about known IP addresses",
        "parameters": [
          {
            "type": "string",
            "description": "A CIDR range of IPs",
            "name": "cidr",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/IPListEntry"
              }
            }
          },
          "400": {
            "description": "Invalid request (error parsing parameters)",
            "schema": {
              "$ref": "#/definitions/Error"
            }
          },
          "404": {
            "description": "No IP cache entries with provided parameters found"
          }
        }
      }
    },
    "/ipam": {
      "post": {
        "tags": [
          "ipam"
        ],
        "summary": "Allocate an IP address",
        "parameters": [
          {
            "enum": [
              "ipv4",
              "ipv6"
            ],
            "type": "string",
            "name": "family",
            "in": "query"
          },
          {
            "type": "string",
            "name": "owner",
            "in": "query"
          },
          {
            "type": "boolean",
            "name": "expiration",
            "in": "header"
          }
        ],
        "responses": {
          "201": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/IPAMResponse"
            }
          },
          "502": {
            "description": "Allocation failure",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/ipam/{ip}": {
      "post": {
        "tags": [
          "ipam"
        ],
        "summary": "Allocate an IP address",
        "parameters": [
          {
            "type": "string",
            "description": "IP address",
            "name": "ip",
            "in": "path",
            "required": true
          },
          {
            "type": "string",
            "name": "owner",
            "in": "query"
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid IP address",
            "x-go-name": "Invalid"
          },
          "409": {
            "description": "IP already allocated",
            "x-go-name": "Exists"
          },
          "500": {
            "description": "IP allocation failure. Details in message.",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          },
          "501": {
            "description": "Allocation for address family disabled",
            "x-go-name": "Disabled"
          }
        }
      },
      "delete": {
        "tags": [
          "ipam"
        ],
        "summary": "Release an allocated IP address",
        "parameters": [
          {
            "type": "string",
            "description": "IP address or owner name",
            "name": "ip",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "400": {
            "description": "Invalid IP address",
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "IP address not found"
          },
          "500": {
            "description": "Address release failure",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          },
          "501": {
            "description": "Allocation for address family disabled",
            "x-go-name": "Disabled"
          }
        }
      }
    },
    "/lrp": {
      "get": {
        "tags": [
          "service"
        ],
        "summary": "Retrieve list of all local redirect policies",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/LRPSpec"
              }
            }
          }
        }
      }
    },
    "/map": {
      "get": {
        "tags": [
          "daemon"
        ],
        "summary": "List all open maps",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/BPFMapList"
            }
          }
        }
      }
    },
    "/map/{name}": {
      "get": {
        "tags": [
          "daemon"
        ],
        "summary": "Retrieve contents of BPF map",
        "parameters": [
          {
            "type": "string",
            "description": "Name of map",
            "name": "name",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/BPFMap"
            }
          },
          "404": {
            "description": "Map not found"
          }
        }
      }
    },
    "/metrics/": {
      "get": {
        "tags": [
          "metrics"
        ],
        "summary": "Retrieve cilium metrics",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Metric"
              }
            }
          },
          "500": {
            "description": "Metrics cannot be retrieved"
          }
        }
      }
    },
    "/policy": {
      "get": {
        "description": "Returns the entire policy tree with all children.\n",
        "tags": [
          "policy"
        ],
        "summary": "Retrieve entire policy tree",
        "parameters": [
          {
            "name": "labels",
            "in": "body",
            "schema": {
              "$ref": "#/definitions/Labels"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Policy"
            }
          },
          "404": {
            "description": "No policy rules found"
          }
        }
      },
      "put": {
        "tags": [
          "policy"
        ],
        "summary": "Create or update a policy (sub)tree",
        "parameters": [
          {
            "description": "Policy rules",
            "name": "policy",
            "in": "body",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Policy"
            }
          },
          "400": {
            "description": "Invalid policy",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidPolicy"
          },
          "460": {
            "description": "Invalid path",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidPath"
          },
          "500": {
            "description": "Policy import failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "delete": {
        "tags": [
          "policy"
        ],
        "summary": "Delete a policy (sub)tree",
        "parameters": [
          {
            "name": "labels",
            "in": "body",
            "schema": {
              "$ref": "#/definitions/Labels"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Policy"
            }
          },
          "400": {
            "description": "Invalid request",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Invalid"
          },
          "404": {
            "description": "Policy not found"
          },
          "500": {
            "description": "Error while deleting policy",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/policy/resolve": {
      "get": {
        "tags": [
          "policy"
        ],
        "summary": "Resolve policy for an identity context",
        "parameters": [
          {
            "description": "Context to provide policy evaluation on",
            "name": "trace-selector",
            "in": "body",
            "schema": {
              "$ref": "#/definitions/TraceSelector"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/PolicyTraceResult"
            }
          }
        }
      }
    },
    "/policy/selectors": {
      "get": {
        "tags": [
          "policy"
        ],
        "summary": "See what selectors match which identities",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/SelectorCache"
            }
          }
        }
      }
    },
    "/prefilter": {
      "get": {
        "tags": [
          "prefilter"
        ],
        "summary": "Retrieve list of CIDRs",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Prefilter"
            }
          },
          "500": {
            "description": "Prefilter get failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "delete": {
        "tags": [
          "prefilter"
        ],
        "summary": "Delete list of CIDRs",
        "parameters": [
          {
            "description": "List of CIDR ranges for filter table",
            "name": "prefilter-spec",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/PrefilterSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Deleted",
            "schema": {
              "$ref": "#/definitions/Prefilter"
            }
          },
          "461": {
            "description": "Invalid CIDR prefix",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidCIDR"
          },
          "500": {
            "description": "Prefilter delete failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "patch": {
        "tags": [
          "prefilter"
        ],
        "summary": "Update list of CIDRs",
        "parameters": [
          {
            "description": "List of CIDR ranges for filter table",
            "name": "prefilter-spec",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/PrefilterSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Updated",
            "schema": {
              "$ref": "#/definitions/Prefilter"
            }
          },
          "461": {
            "description": "Invalid CIDR prefix",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidCIDR"
          },
          "500": {
            "description": "Prefilter update failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/recorder": {
      "get": {
        "tags": [
          "recorder"
        ],
        "summary": "Retrieve list of all recorders",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Recorder"
              }
            }
          }
        }
      }
    },
    "/recorder/masks": {
      "get": {
        "tags": [
          "recorder"
        ],
        "summary": "Retrieve list of all recorder masks",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/RecorderMask"
              }
            }
          }
        }
      }
    },
    "/recorder/{id}": {
      "get": {
        "tags": [
          "recorder"
        ],
        "summary": "Retrieve configuration of a recorder",
        "parameters": [
          {
            "type": "integer",
            "description": "ID of recorder",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Recorder"
            }
          },
          "404": {
            "description": "Recorder not found"
          }
        }
      },
      "put": {
        "tags": [
          "recorder"
        ],
        "summary": "Create or update recorder",
        "parameters": [
          {
            "type": "integer",
            "description": "ID of recorder",
            "name": "id",
            "in": "path",
            "required": true
          },
          {
            "description": "Recorder configuration",
            "name": "config",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/RecorderSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Updated"
          },
          "201": {
            "description": "Created"
          },
          "500": {
            "description": "Error while creating recorder",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "delete": {
        "tags": [
          "recorder"
        ],
        "summary": "Delete a recorder",
        "parameters": [
          {
            "type": "integer",
            "description": "ID of recorder",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "404": {
            "description": "Recorder not found"
          },
          "500": {
            "description": "Recorder deletion failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    },
    "/service": {
      "get": {
        "tags": [
          "service"
        ],
        "summary": "Retrieve list of all services",
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/Service"
              }
            }
          }
        }
      }
    },
    "/service/{id}": {
      "get": {
        "tags": [
          "service"
        ],
        "summary": "Retrieve configuration of a service",
        "parameters": [
          {
            "type": "integer",
            "description": "ID of service",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "$ref": "#/definitions/Service"
            }
          },
          "404": {
            "description": "Service not found"
          }
        }
      },
      "put": {
        "tags": [
          "service"
        ],
        "summary": "Create or update service",
        "parameters": [
          {
            "type": "integer",
            "description": "ID of service",
            "name": "id",
            "in": "path",
            "required": true
          },
          {
            "description": "Service configuration",
            "name": "config",
            "in": "body",
            "required": true,
            "schema": {
              "$ref": "#/definitions/ServiceSpec"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Updated"
          },
          "201": {
            "description": "Created"
          },
          "460": {
            "description": "Invalid frontend in service configuration",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidFrontend"
          },
          "461": {
            "description": "Invalid backend in service configuration",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "InvalidBackend"
          },
          "500": {
            "description": "Error while creating service",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      },
      "delete": {
        "tags": [
          "service"
        ],
        "summary": "Delete a service",
        "parameters": [
          {
            "type": "integer",
            "description": "ID of service",
            "name": "id",
            "in": "path",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Success"
          },
          "404": {
            "description": "Service not found"
          },
          "500": {
            "description": "Service deletion failed",
            "schema": {
              "$ref": "#/definitions/Error"
            },
            "x-go-name": "Failure"
          }
        }
      }
    }
  },
  "definitions": {
    "Address": {
      "description": "IP address",
      "type": "string"
    },
    "AddressPair": {
      "description": "Addressing information of an endpoint",
      "type": "object",
      "properties": {
        "ipv4": {
          "description": "IPv4 address",
          "type": "string"
        },
        "ipv4-expiration-uuid": {
          "description": "UUID of IPv4 expiration timer",
          "type": "string"
        },
        "ipv6": {
          "description": "IPv6 address",
          "type": "string"
        },
        "ipv6-expiration-uuid": {
          "description": "UUID of IPv6 expiration timer",
          "type": "string"
        }
      }
    },
    "AllocationMap": {
      "description": "Map of allocated IPs\n",
      "type": "object",
      "additionalProperties": {
        "type": "string"
      }
    },
    "BPFMap": {
      "description": "BPF map definition and content",
      "type": "object",
      "properties": {
        "cache": {
          "description": "Contents of cache",
          "type": "array",
          "items": {
            "$ref": "#/definitions/BPFMapEntry"
          }
        },
        "path": {
          "description": "Path to BPF map",
          "type": "string"
        }
      }
    },
    "BPFMapEntry": {
      "description": "BPF map cache entry",
      "type": "object",
      "properties": {
        "desired-action": {
          "description": "Desired action to be performed",
          "type": "string",
          "enum": [
            "ok",
            "insert",
            "delete"
          ]
        },
        "key": {
          "description": "Key of map entry",
          "type": "string"
        },
        "last-error": {
          "description": "Last error seen while performing desired action",
          "type": "string"
        },
        "value": {
          "description": "Value of map entry",
          "type": "string"
        }
      }
    },
    "BPFMapList": {
      "description": "List of BPF Maps",
      "type": "object",
      "properties": {
        "maps": {
          "description": "Array of open BPF map lists",
          "type": "array",
          "items": {
            "$ref": "#/definitions/BPFMap"
          }
        }
      }
    },
    "BPFMapProperties": {
      "description": "BPF map properties",
      "type": "object",
      "properties": {
        "name": {
          "description": "Name of the BPF map",
          "type": "string"
        },
        "size": {
          "description": "Size of the BPF map",
          "type": "integer"
        }
      }
    },
    "BPFMapStatus": {
      "description": "BPF map status\n\n+k8s:deepcopy-gen=true\n",
      "type": "object",
      "properties": {
        "dynamic-size-ratio": {
          "description": "Ratio of total system memory to use for dynamic sizing of BPF maps",
          "type": "number"
        },
        "maps": {
          "description": "BPF maps",
          "type": "array",
          "items": {
            "$ref": "#/definitions/BPFMapProperties"
          }
        }
      }
    },
    "BackendAddress": {
      "description": "Service backend address",
      "type": "object",
      "required": [
        "ip"
      ],
      "properties": {
        "ip": {
          "description": "Layer 3 address",
          "type": "string"
        },
        "nodeName": {
          "description": "Optional name of the node on which this backend runs",
          "type": "string"
        },
        "port": {
          "description": "Layer 4 port number",
          "type": "integer",
          "format": "uint16"
        }
      }
    },
    "BandwidthManager": {
      "description": "Status of bandwidth manager\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "devices": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "enabled": {
          "description": "Is bandwidth manager enabled",
          "type": "boolean"
        }
      }
    },
    "CIDRList": {
      "description": "List of CIDRs",
      "type": "object",
      "properties": {
        "list": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "revision": {
          "type": "integer"
        }
      }
    },
    "CIDRPolicy": {
      "description": "CIDR endpoint policy\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "egress": {
          "description": "List of CIDR egress rules",
          "type": "array",
          "items": {
            "$ref": "#/definitions/PolicyRule"
          }
        },
        "ingress": {
          "description": "List of CIDR ingress rules",
          "type": "array",
          "items": {
            "$ref": "#/definitions/PolicyRule"
          }
        }
      }
    },
    "ClockSource": {
      "description": "Status of BPF clock source\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "hertz": {
          "description": "Kernel Hz",
          "type": "integer"
        },
        "mode": {
          "description": "Datapath clock source",
          "type": "string",
          "enum": [
            "ktime",
            "jiffies"
          ]
        }
      }
    },
    "ClusterMeshStatus": {
      "description": "Status of ClusterMesh\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "clusters": {
          "description": "List of remote clusters",
          "type": "array",
          "items": {
            "$ref": "#/definitions/RemoteCluster"
          }
        },
        "num-global-services": {
          "description": "Number of global services",
          "type": "integer"
        }
      }
    },
    "ClusterNodeStatus": {
      "description": "Status of cluster",
      "properties": {
        "client-id": {
          "description": "ID that should be used by the client to receive a diff from the previous request",
          "type": "integer"
        },
        "nodes-added": {
          "description": "List of known nodes",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeElement"
          }
        },
        "nodes-removed": {
          "description": "List of known nodes",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeElement"
          }
        },
        "self": {
          "description": "Name of local node (if available)",
          "type": "string"
        }
      }
    },
    "ClusterNodesResponse": {
      "properties": {
        "nodes": {
          "description": "List of known nodes",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeElement"
          }
        },
        "self": {
          "description": "Name of local node (if available)",
          "type": "string"
        }
      }
    },
    "ClusterStatus": {
      "description": "Status of cluster\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "ciliumHealth": {
          "description": "Status of local cilium-health daemon",
          "$ref": "#/definitions/Status"
        },
        "nodes": {
          "description": "List of known nodes",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeElement"
          }
        },
        "self": {
          "description": "Name of local node (if available)",
          "type": "string"
        }
      }
    },
    "ConfigurationMap": {
      "description": "Map of configuration key/value pairs.\n",
      "type": "object",
      "additionalProperties": {
        "type": "string"
      }
    },
    "ControllerStatus": {
      "description": "Status of a controller\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "configuration": {
          "description": "Configuration of controller\n\n+deepequal-gen=true\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "error-retry": {
              "description": "Retry on error",
              "type": "boolean"
            },
            "error-retry-base": {
              "description": "Base error retry back-off time",
              "type": "string",
              "format": "duration"
            },
            "interval": {
              "description": "Regular synchronization interval",
              "type": "string",
              "format": "duration"
            }
          }
        },
        "name": {
          "description": "Name of controller",
          "type": "string"
        },
        "status": {
          "description": "Current status of controller\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "consecutive-failure-count": {
              "description": "Number of consecutive errors since last success",
              "type": "integer"
            },
            "failure-count": {
              "description": "Total number of failed runs",
              "type": "integer"
            },
            "last-failure-msg": {
              "description": "Error message of last failed run",
              "type": "string"
            },
            "last-failure-timestamp": {
              "description": "Timestamp of last error",
              "type": "string",
              "format": "date-time"
            },
            "last-success-timestamp": {
              "description": "Timestamp of last success",
              "type": "string",
              "format": "date-time"
            },
            "success-count": {
              "description": "Total number of successful runs",
              "type": "integer"
            }
          }
        },
        "uuid": {
          "description": "UUID of controller",
          "type": "string",
          "format": "uuid"
        }
      }
    },
    "ControllerStatusConfiguration": {
      "description": "Configuration of controller\n\n+deepequal-gen=true\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "error-retry": {
          "description": "Retry on error",
          "type": "boolean"
        },
        "error-retry-base": {
          "description": "Base error retry back-off time",
          "type": "string",
          "format": "duration"
        },
        "interval": {
          "description": "Regular synchronization interval",
          "type": "string",
          "format": "duration"
        }
      }
    },
    "ControllerStatusStatus": {
      "description": "Current status of controller\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "consecutive-failure-count": {
          "description": "Number of consecutive errors since last success",
          "type": "integer"
        },
        "failure-count": {
          "description": "Total number of failed runs",
          "type": "integer"
        },
        "last-failure-msg": {
          "description": "Error message of last failed run",
          "type": "string"
        },
        "last-failure-timestamp": {
          "description": "Timestamp of last error",
          "type": "string",
          "format": "date-time"
        },
        "last-success-timestamp": {
          "description": "Timestamp of last success",
          "type": "string",
          "format": "date-time"
        },
        "success-count": {
          "description": "Total number of successful runs",
          "type": "integer"
        }
      }
    },
    "ControllerStatuses": {
      "description": "Collection of controller statuses",
      "type": "array",
      "items": {
        "$ref": "#/definitions/ControllerStatus"
      }
    },
    "DNSLookup": {
      "description": "An IP -\u003e DNS mapping, with metadata",
      "type": "object",
      "properties": {
        "endpoint-id": {
          "description": "The endpoint that made this lookup, or 0 for the agent itself.",
          "type": "integer"
        },
        "expiration-time": {
          "description": "The absolute time when this data will expire in this cache",
          "type": "string",
          "format": "date-time"
        },
        "fqdn": {
          "description": "DNS name",
          "type": "string"
        },
        "ips": {
          "description": "IP addresses returned in this lookup",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "lookup-time": {
          "description": "The absolute time when this data was recieved",
          "type": "string",
          "format": "date-time"
        },
        "source": {
          "description": "The reason this FQDN IP association exists. Either a DNS lookup or an ongoing connection to an IP that was created by a DNS lookup.",
          "type": "string"
        },
        "ttl": {
          "description": "The TTL in the DNS response",
          "type": "integer"
        }
      }
    },
    "DaemonConfiguration": {
      "description": "Response to a daemon configuration request.\n",
      "type": "object",
      "properties": {
        "spec": {
          "description": "Changeable configuration",
          "$ref": "#/definitions/DaemonConfigurationSpec"
        },
        "status": {
          "description": "Current daemon configuration related status.Contains the addressing\ninformation, k8s, node monitor and immutable and mutable\nconfiguration settings.\n",
          "$ref": "#/definitions/DaemonConfigurationStatus"
        }
      }
    },
    "DaemonConfigurationSpec": {
      "description": "The controllable configuration of the daemon.",
      "type": "object",
      "properties": {
        "options": {
          "description": "Changeable configuration",
          "$ref": "#/definitions/ConfigurationMap"
        },
        "policy-enforcement": {
          "description": "The policy-enforcement mode",
          "type": "string",
          "enum": [
            "default",
            "always",
            "never"
          ]
        }
      }
    },
    "DaemonConfigurationStatus": {
      "description": "Response to a daemon configuration request. Contains the addressing\ninformation, k8s, node monitor and immutable and mutable configuration\nsettings.\n",
      "type": "object",
      "properties": {
        "addressing": {
          "$ref": "#/definitions/NodeAddressing"
        },
        "daemonConfigurationMap": {
          "description": "Config map which contains all the active daemon configurations",
          "additionalProperties": {
            "type": "object"
          }
        },
        "datapathMode": {
          "$ref": "#/definitions/DatapathMode"
        },
        "deviceMTU": {
          "description": "MTU on workload facing devices",
          "type": "integer"
        },
        "egress-multi-home-ip-rule-compat": {
          "description": "Configured compatibility mode for --egress-multi-home-ip-rule-compat",
          "type": "boolean"
        },
        "immutable": {
          "description": "Immutable configuration (read-only)",
          "$ref": "#/definitions/ConfigurationMap"
        },
        "ipam-mode": {
          "description": "Configured IPAM mode",
          "type": "string"
        },
        "ipvlanConfiguration": {
          "$ref": "#/definitions/IpvlanConfiguration"
        },
        "k8s-configuration": {
          "type": "string"
        },
        "k8s-endpoint": {
          "type": "string"
        },
        "kvstoreConfiguration": {
          "$ref": "#/definitions/KVstoreConfiguration"
        },
        "masquerade": {
          "type": "boolean"
        },
        "masqueradeProtocols": {
          "description": "Status of masquerading feature",
          "type": "object",
          "properties": {
            "ipv4": {
              "description": "Status of masquerading for IPv4 traffic",
              "type": "boolean"
            },
            "ipv6": {
              "description": "Status of masquerading for IPv6 traffic",
              "type": "boolean"
            }
          }
        },
        "nodeMonitor": {
          "description": "Status of the node monitor",
          "$ref": "#/definitions/MonitorStatus"
        },
        "realized": {
          "description": "Currently applied configuration",
          "$ref": "#/definitions/DaemonConfigurationSpec"
        },
        "routeMTU": {
          "description": "MTU for network facing routes",
          "type": "integer"
        }
      }
    },
    "DaemonConfigurationStatusMasqueradeProtocols": {
      "description": "Status of masquerading feature",
      "type": "object",
      "properties": {
        "ipv4": {
          "description": "Status of masquerading for IPv4 traffic",
          "type": "boolean"
        },
        "ipv6": {
          "description": "Status of masquerading for IPv6 traffic",
          "type": "boolean"
        }
      }
    },
    "DatapathMode": {
      "description": "Datapath mode",
      "type": "string",
      "enum": [
        "veth",
        "ipvlan"
      ]
    },
    "DebugInfo": {
      "description": "groups some debugging related information on the agent",
      "type": "object",
      "properties": {
        "cilium-memory-map": {
          "type": "string"
        },
        "cilium-nodemonitor-memory-map": {
          "type": "string"
        },
        "cilium-status": {
          "$ref": "#/definitions/StatusResponse"
        },
        "cilium-version": {
          "type": "string"
        },
        "encryption": {
          "type": "object",
          "properties": {
            "wireguard": {
              "description": "Status of the Wireguard agent",
              "$ref": "#/definitions/WireguardStatus"
            }
          }
        },
        "endpoint-list": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/Endpoint"
          }
        },
        "environment-variables": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "kernel-version": {
          "type": "string"
        },
        "policy": {
          "$ref": "#/definitions/Policy"
        },
        "service-list": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/Service"
          }
        },
        "subsystem": {
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        }
      }
    },
    "DebugInfoEncryption": {
      "type": "object",
      "properties": {
        "wireguard": {
          "description": "Status of the Wireguard agent",
          "$ref": "#/definitions/WireguardStatus"
        }
      }
    },
    "EncryptionStatus": {
      "description": "Status of transparent encryption\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "mode": {
          "type": "string",
          "enum": [
            "Disabled",
            "IPsec",
            "Wireguard"
          ]
        },
        "msg": {
          "description": "Human readable status/error/warning message",
          "type": "string"
        },
        "wireguard": {
          "description": "Status of the Wireguard agent",
          "$ref": "#/definitions/WireguardStatus"
        }
      }
    },
    "Endpoint": {
      "description": "An endpoint is a namespaced network interface to which cilium applies policies",
      "type": "object",
      "properties": {
        "id": {
          "description": "The cilium-agent-local ID of the endpoint",
          "type": "integer"
        },
        "spec": {
          "description": "The desired configuration state of the endpoint",
          "$ref": "#/definitions/EndpointConfigurationSpec"
        },
        "status": {
          "description": "The desired and realized configuration state of the endpoint",
          "$ref": "#/definitions/EndpointStatus"
        }
      }
    },
    "EndpointChangeRequest": {
      "description": "Structure which contains the mutable elements of an Endpoint.\n",
      "type": "object",
      "required": [
        "state"
      ],
      "properties": {
        "addressing": {
          "$ref": "#/definitions/AddressPair"
        },
        "container-id": {
          "description": "ID assigned by container runtime",
          "type": "string"
        },
        "container-name": {
          "description": "Name assigned to container",
          "type": "string"
        },
        "datapath-configuration": {
          "$ref": "#/definitions/EndpointDatapathConfiguration"
        },
        "datapath-map-id": {
          "description": "ID of datapath tail call map",
          "type": "integer"
        },
        "docker-endpoint-id": {
          "description": "Docker endpoint ID",
          "type": "string"
        },
        "docker-network-id": {
          "description": "Docker network ID",
          "type": "string"
        },
        "host-mac": {
          "description": "MAC address",
          "type": "string"
        },
        "id": {
          "description": "Local endpoint ID",
          "type": "integer"
        },
        "interface-index": {
          "description": "Index of network device",
          "type": "integer"
        },
        "interface-name": {
          "description": "Name of network device",
          "type": "string"
        },
        "k8s-namespace": {
          "description": "Kubernetes namespace name",
          "type": "string"
        },
        "k8s-pod-name": {
          "description": "Kubernetes pod name",
          "type": "string"
        },
        "labels": {
          "description": "Labels describing the identity",
          "$ref": "#/definitions/Labels"
        },
        "mac": {
          "description": "MAC address",
          "type": "string"
        },
        "pid": {
          "description": "Process ID of the workload belonging to this endpoint",
          "type": "integer"
        },
        "policy-enabled": {
          "description": "Whether policy enforcement is enabled or not",
          "type": "boolean"
        },
        "state": {
          "description": "Current state of endpoint",
          "$ref": "#/definitions/EndpointState"
        },
        "sync-build-endpoint": {
          "description": "Whether to build an endpoint synchronously\n",
          "type": "boolean"
        }
      }
    },
    "EndpointConfigurationSpec": {
      "description": "An endpoint's configuration",
      "type": "object",
      "properties": {
        "label-configuration": {
          "description": "the endpoint's labels",
          "$ref": "#/definitions/LabelConfigurationSpec"
        },
        "options": {
          "description": "Changeable configuration",
          "$ref": "#/definitions/ConfigurationMap"
        }
      }
    },
    "EndpointConfigurationStatus": {
      "description": "An endpoint's configuration",
      "type": "object",
      "properties": {
        "error": {
          "description": "Most recent error, if applicable",
          "$ref": "#/definitions/Error"
        },
        "immutable": {
          "description": "Immutable configuration (read-only)",
          "$ref": "#/definitions/ConfigurationMap"
        },
        "realized": {
          "description": "currently applied changeable configuration",
          "$ref": "#/definitions/EndpointConfigurationSpec"
        }
      }
    },
    "EndpointDatapathConfiguration": {
      "description": "Datapath configuration to be used for the endpoint",
      "type": "object",
      "properties": {
        "disable-sip-verification": {
          "description": "Disable source IP verification for the endpoint.\n",
          "type": "boolean"
        },
        "external-ipam": {
          "description": "Indicates that IPAM is done external to Cilium. This will prevent the IP from being released and re-allocation of the IP address is skipped on restore.\n",
          "type": "boolean"
        },
        "install-endpoint-route": {
          "description": "Installs a route in the Linux routing table pointing to the device of the endpoint's interface.\n",
          "type": "boolean"
        },
        "require-arp-passthrough": {
          "description": "Enable ARP passthrough mode",
          "type": "boolean"
        },
        "require-egress-prog": {
          "description": "Endpoint requires a host-facing egress program to be attached to implement ingress policy and reverse NAT.\n",
          "type": "boolean"
        },
        "require-routing": {
          "description": "Endpoint requires BPF routing to be enabled, when disabled, routing is delegated to Linux routing.\n",
          "type": "boolean",
          "default": true
        }
      }
    },
    "EndpointHealth": {
      "description": "Health of the endpoint\n\n+deepequal-gen=true",
      "type": "object",
      "properties": {
        "bpf": {
          "$ref": "#/definitions/EndpointHealthStatus"
        },
        "connected": {
          "description": "Is this endpoint reachable",
          "type": "boolean"
        },
        "overallHealth": {
          "$ref": "#/definitions/EndpointHealthStatus"
        },
        "policy": {
          "$ref": "#/definitions/EndpointHealthStatus"
        }
      }
    },
    "EndpointHealthStatus": {
      "description": "A common set of statuses for endpoint health * `+"`"+``+"`"+`OK`+"`"+``+"`"+` = All components operational * `+"`"+``+"`"+`Bootstrap`+"`"+``+"`"+` = This component is being created * `+"`"+``+"`"+`Pending`+"`"+``+"`"+` = A change is being processed to be applied * `+"`"+``+"`"+`Warning`+"`"+``+"`"+` = This component is not applying up-to-date policies (but is still applying the previous version) * `+"`"+``+"`"+`Failure`+"`"+``+"`"+` = An error has occurred and no policy is being applied * `+"`"+``+"`"+`Disabled`+"`"+``+"`"+` = This endpoint is disabled and will not handle traffic\n",
      "type": "string",
      "enum": [
        "OK",
        "Bootstrap",
        "Pending",
        "Warning",
        "Failure",
        "Disabled"
      ]
    },
    "EndpointIdentifiers": {
      "description": "Unique identifiers for this endpoint from outside cilium\n\n+deepequal-gen=true",
      "type": "object",
      "properties": {
        "container-id": {
          "description": "ID assigned by container runtime",
          "type": "string"
        },
        "container-name": {
          "description": "Name assigned to container",
          "type": "string"
        },
        "docker-endpoint-id": {
          "description": "Docker endpoint ID",
          "type": "string"
        },
        "docker-network-id": {
          "description": "Docker network ID",
          "type": "string"
        },
        "k8s-namespace": {
          "description": "K8s namespace for this endpoint",
          "type": "string"
        },
        "k8s-pod-name": {
          "description": "K8s pod name for this endpoint",
          "type": "string"
        },
        "pod-name": {
          "description": "K8s pod for this endpoint(Deprecated, use K8sPodName and K8sNamespace instead)",
          "type": "string"
        }
      }
    },
    "EndpointNetworking": {
      "description": "Unique identifiers for this endpoint from outside cilium",
      "type": "object",
      "properties": {
        "addressing": {
          "description": "IP4/6 addresses assigned to this Endpoint",
          "type": "array",
          "items": {
            "$ref": "#/definitions/AddressPair"
          }
        },
        "host-addressing": {
          "$ref": "#/definitions/NodeAddressing"
        },
        "host-mac": {
          "description": "MAC address",
          "type": "string"
        },
        "interface-index": {
          "description": "Index of network device",
          "type": "integer"
        },
        "interface-name": {
          "description": "Name of network device",
          "type": "string"
        },
        "mac": {
          "description": "MAC address",
          "type": "string"
        }
      }
    },
    "EndpointPolicy": {
      "description": "Policy information of an endpoint\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "allowed-egress-identities": {
          "description": "List of identities to which this endpoint is allowed to communicate\n",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "allowed-ingress-identities": {
          "description": "List of identities allowed to communicate to this endpoint\n",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "build": {
          "description": "Build number of calculated policy in use",
          "type": "integer"
        },
        "cidr-policy": {
          "$ref": "#/definitions/CIDRPolicy"
        },
        "denied-egress-identities": {
          "description": "List of identities to which this endpoint is not allowed to communicate\n",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "denied-ingress-identities": {
          "description": "List of identities not allowed to communicate to this endpoint\n",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "id": {
          "description": "Own identity of endpoint",
          "type": "integer"
        },
        "l4": {
          "$ref": "#/definitions/L4Policy"
        },
        "policy-enabled": {
          "description": "Whether policy enforcement is enabled (ingress, egress, both or none)",
          "$ref": "#/definitions/EndpointPolicyEnabled"
        },
        "policy-revision": {
          "description": "The agent-local policy revision",
          "type": "integer"
        }
      }
    },
    "EndpointPolicyEnabled": {
      "description": "Whether policy enforcement is enabled (ingress, egress, both or none)",
      "type": "string",
      "enum": [
        "none",
        "ingress",
        "egress",
        "both",
        "audit-ingress",
        "audit-egress",
        "audit-both"
      ]
    },
    "EndpointPolicyStatus": {
      "description": "Policy information of an endpoint",
      "type": "object",
      "properties": {
        "proxy-policy-revision": {
          "description": "The policy revision currently enforced in the proxy for this endpoint",
          "type": "integer"
        },
        "proxy-statistics": {
          "description": "Statistics of the proxy redirects configured for this endpoint",
          "type": "array",
          "items": {
            "$ref": "#/definitions/ProxyStatistics"
          }
        },
        "realized": {
          "description": "The policy in the datapath for this endpoint",
          "$ref": "#/definitions/EndpointPolicy"
        },
        "spec": {
          "description": "The policy that should apply to this endpoint",
          "$ref": "#/definitions/EndpointPolicy"
        }
      }
    },
    "EndpointState": {
      "description": "State of endpoint",
      "type": "string",
      "enum": [
        "waiting-for-identity",
        "not-ready",
        "waiting-to-regenerate",
        "regenerating",
        "restoring",
        "ready",
        "disconnecting",
        "disconnected",
        "invalid"
      ]
    },
    "EndpointStatus": {
      "description": "The current state and configuration of the endpoint, its policy \u0026 datapath, and subcomponents",
      "type": "object",
      "required": [
        "state"
      ],
      "properties": {
        "controllers": {
          "description": "Status of internal controllers attached to this endpoint",
          "$ref": "#/definitions/ControllerStatuses"
        },
        "external-identifiers": {
          "description": "Unique identifiers for this endpoint from outside cilium",
          "$ref": "#/definitions/EndpointIdentifiers"
        },
        "health": {
          "description": "Summary overall endpoint \u0026 subcomponent health",
          "$ref": "#/definitions/EndpointHealth"
        },
        "identity": {
          "description": "The security identity for this endpoint",
          "$ref": "#/definitions/Identity"
        },
        "labels": {
          "description": "Labels applied to this endpoint",
          "$ref": "#/definitions/LabelConfigurationStatus"
        },
        "log": {
          "description": "Most recent status log. See endpoint/{id}/log for the complete log.",
          "$ref": "#/definitions/EndpointStatusLog"
        },
        "namedPorts": {
          "description": "List of named ports that can be used in Network Policy",
          "$ref": "#/definitions/NamedPorts"
        },
        "networking": {
          "description": "Networking properties of the endpoint",
          "$ref": "#/definitions/EndpointNetworking"
        },
        "policy": {
          "description": "The policy applied to this endpoint from the policy repository",
          "$ref": "#/definitions/EndpointPolicyStatus"
        },
        "realized": {
          "description": "The configuration in effect on this endpoint",
          "$ref": "#/definitions/EndpointConfigurationSpec"
        },
        "state": {
          "description": "Current state of endpoint",
          "$ref": "#/definitions/EndpointState"
        }
      }
    },
    "EndpointStatusChange": {
      "description": "Indication of a change of status\n\n+deepequal-gen=true",
      "type": "object",
      "properties": {
        "code": {
          "description": "Code indicate type of status change",
          "type": "string",
          "enum": [
            "ok",
            "failed"
          ]
        },
        "message": {
          "description": "Status message",
          "type": "string"
        },
        "state": {
          "$ref": "#/definitions/EndpointState"
        },
        "timestamp": {
          "description": "Timestamp when status change occurred",
          "type": "string"
        }
      }
    },
    "EndpointStatusLog": {
      "description": "Status log of endpoint",
      "type": "array",
      "items": {
        "$ref": "#/definitions/EndpointStatusChange"
      }
    },
    "Error": {
      "type": "string"
    },
    "FrontendAddress": {
      "description": "Layer 4 address. The protocol is currently ignored, all services will\nbehave as if protocol any is specified. To restrict to a particular\nprotocol, use policy.\n",
      "type": "object",
      "properties": {
        "ip": {
          "description": "Layer 3 address",
          "type": "string"
        },
        "port": {
          "description": "Layer 4 port number",
          "type": "integer",
          "format": "uint16"
        },
        "protocol": {
          "description": "Layer 4 protocol",
          "type": "string",
          "enum": [
            "tcp",
            "udp",
            "any"
          ]
        },
        "scope": {
          "description": "Load balancing scope for frontend address",
          "type": "string",
          "enum": [
            "external",
            "internal"
          ]
        }
      }
    },
    "FrontendMapping": {
      "description": "Mapping of frontend to backend pods of an LRP",
      "type": "object",
      "properties": {
        "backends": {
          "description": "Pod backends of an LRP",
          "type": "array",
          "items": {
            "$ref": "#/definitions/LRPBackend"
          }
        },
        "frontend-address": {
          "$ref": "#/definitions/FrontendAddress"
        }
      }
    },
    "HostFirewall": {
      "description": "Status of the host firewall\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "devices": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "mode": {
          "type": "string",
          "enum": [
            "Disabled",
            "Enabled"
          ]
        }
      }
    },
    "HostRouting": {
      "description": "Status of host routing\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "mode": {
          "description": "Datapath routing mode",
          "type": "string",
          "enum": [
            "BPF",
            "Legacy"
          ]
        }
      }
    },
    "HubbleStatus": {
      "description": "Status of the Hubble server\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "metrics": {
          "description": "Status of the Hubble metrics server",
          "type": "object",
          "properties": {
            "state": {
              "description": "State of the Hubble metrics",
              "type": "string",
              "enum": [
                "Ok",
                "Warning",
                "Failure",
                "Disabled"
              ]
            }
          }
        },
        "msg": {
          "description": "Human readable status/error/warning message",
          "type": "string"
        },
        "observer": {
          "description": "Status of the Hubble observer\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "current-flows": {
              "description": "Current number of flows this Hubble observer stores",
              "type": "integer"
            },
            "max-flows": {
              "description": "Maximum number of flows this Hubble observer is able to store",
              "type": "integer"
            },
            "seen-flows": {
              "description": "Total number of flows this Hubble observer has seen",
              "type": "integer"
            },
            "uptime": {
              "description": "Uptime of this Hubble observer instance",
              "type": "string",
              "format": "duration"
            }
          }
        },
        "state": {
          "description": "State the component is in",
          "type": "string",
          "enum": [
            "Ok",
            "Warning",
            "Failure",
            "Disabled"
          ]
        }
      }
    },
    "HubbleStatusMetrics": {
      "description": "Status of the Hubble metrics server",
      "type": "object",
      "properties": {
        "state": {
          "description": "State of the Hubble metrics",
          "type": "string",
          "enum": [
            "Ok",
            "Warning",
            "Failure",
            "Disabled"
          ]
        }
      }
    },
    "HubbleStatusObserver": {
      "description": "Status of the Hubble observer\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "current-flows": {
          "description": "Current number of flows this Hubble observer stores",
          "type": "integer"
        },
        "max-flows": {
          "description": "Maximum number of flows this Hubble observer is able to store",
          "type": "integer"
        },
        "seen-flows": {
          "description": "Total number of flows this Hubble observer has seen",
          "type": "integer"
        },
        "uptime": {
          "description": "Uptime of this Hubble observer instance",
          "type": "string",
          "format": "duration"
        }
      }
    },
    "IPAMAddressResponse": {
      "description": "IPAM configuration of an individual address family",
      "type": "object",
      "properties": {
        "cidrs": {
          "description": "List of CIDRs out of which IPs are allocated",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "expiration-uuid": {
          "description": "The UUID for the expiration timer. Set when expiration has been\nenabled while allocating.\n",
          "type": "string"
        },
        "gateway": {
          "description": "IP of gateway",
          "type": "string"
        },
        "interface-number": {
          "description": "InterfaceNumber is a field for generically identifying an interface. This is only useful in ENI mode.\n",
          "type": "string"
        },
        "ip": {
          "description": "Allocated IP for endpoint",
          "type": "string"
        },
        "master-mac": {
          "description": "MAC of master interface if address is a slave/secondary of a master interface",
          "type": "string"
        }
      }
    },
    "IPAMResponse": {
      "description": "IPAM configuration of an endpoint",
      "type": "object",
      "required": [
        "address",
        "host-addressing"
      ],
      "properties": {
        "address": {
          "$ref": "#/definitions/AddressPair"
        },
        "host-addressing": {
          "$ref": "#/definitions/NodeAddressing"
        },
        "ipv4": {
          "$ref": "#/definitions/IPAMAddressResponse"
        },
        "ipv6": {
          "$ref": "#/definitions/IPAMAddressResponse"
        }
      }
    },
    "IPAMStatus": {
      "description": "Status of IP address management\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "allocations": {
          "$ref": "#/definitions/AllocationMap"
        },
        "ipv4": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "ipv6": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "status": {
          "type": "string"
        }
      }
    },
    "IPListEntry": {
      "description": "IP entry with metadata",
      "type": "object",
      "required": [
        "cidr",
        "identity"
      ],
      "properties": {
        "cidr": {
          "description": "Key of the entry in the form of a CIDR range",
          "type": "string"
        },
        "encryptKey": {
          "description": "The context ID for the encryption session",
          "type": "integer"
        },
        "hostIP": {
          "description": "IP address of the host",
          "type": "string"
        },
        "identity": {
          "description": "Numerical identity assigned to the IP",
          "type": "integer"
        },
        "metadata": {
          "$ref": "#/definitions/IPListEntryMetadata"
        }
      }
    },
    "IPListEntryMetadata": {
      "description": "Additional metadata assigned to an IP list entry",
      "type": "object",
      "properties": {
        "name": {
          "description": "Name assigned to the IP (e.g. Kubernetes pod name)",
          "type": "string"
        },
        "namespace": {
          "description": "Namespace of the IP (e.g. Kubernetes namespace)",
          "type": "string"
        },
        "source": {
          "description": "Source of the IP entry and its metadata",
          "type": "string",
          "example": "k8s"
        }
      }
    },
    "Identity": {
      "description": "Security identity",
      "type": "object",
      "properties": {
        "id": {
          "description": "Unique identifier",
          "type": "integer"
        },
        "labels": {
          "description": "Labels describing the identity",
          "$ref": "#/definitions/Labels"
        },
        "labelsSHA256": {
          "description": "SHA256 of labels",
          "type": "string"
        }
      }
    },
    "IdentityEndpoints": {
      "description": "Security identities owned by endpoints on the local node",
      "type": "object",
      "properties": {
        "identity": {
          "description": "Security identity",
          "$ref": "#/definitions/Identity"
        },
        "refCount": {
          "description": "number of endpoints consuming this identity locally (should always be \u003e 0)",
          "type": "integer"
        }
      }
    },
    "IpvlanConfiguration": {
      "description": "Setup for datapath when operating in ipvlan mode.",
      "type": "object",
      "properties": {
        "masterDeviceIndex": {
          "description": "Workload facing ipvlan master device ifindex.",
          "type": "integer"
        },
        "operationMode": {
          "description": "Mode in which ipvlan setup operates.",
          "type": "string",
          "enum": [
            "L3",
            "L3S"
          ]
        }
      }
    },
    "K8sStatus": {
      "description": "Status of Kubernetes integration\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "k8s-api-versions": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "msg": {
          "description": "Human readable status/error/warning message",
          "type": "string"
        },
        "state": {
          "description": "State the component is in",
          "type": "string",
          "enum": [
            "Ok",
            "Warning",
            "Failure",
            "Disabled"
          ]
        }
      }
    },
    "KVstoreConfiguration": {
      "description": "Configuration used for the kvstore",
      "properties": {
        "options": {
          "description": "Configuration options",
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        },
        "type": {
          "description": "Type of kvstore",
          "type": "string"
        }
      }
    },
    "KubeProxyReplacement": {
      "description": "Status of kube-proxy replacement\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "deviceList": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "array",
          "items": {
            "$ref": "#/definitions/KubeProxyReplacementDeviceListItems0"
          }
        },
        "devices": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "directRoutingDevice": {
          "type": "string"
        },
        "features": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "externalIPs": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                }
              }
            },
            "gracefulTermination": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                }
              }
            },
            "hostPort": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                }
              }
            },
            "hostReachableServices": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                },
                "protocols": {
                  "type": "array",
                  "items": {
                    "type": "string"
                  }
                }
              }
            },
            "nodePort": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "acceleration": {
                  "type": "string",
                  "enum": [
                    "None",
                    "Native",
                    "Generic"
                  ]
                },
                "algorithm": {
                  "type": "string",
                  "enum": [
                    "Random",
                    "Maglev"
                  ]
                },
                "enabled": {
                  "type": "boolean"
                },
                "lutSize": {
                  "type": "integer"
                },
                "mode": {
                  "type": "string",
                  "enum": [
                    "SNAT",
                    "DSR",
                    "Hybrid"
                  ]
                },
                "portMax": {
                  "type": "integer"
                },
                "portMin": {
                  "type": "integer"
                }
              }
            },
            "sessionAffinity": {
              "description": "\n\n+k8s:deepcopy-gen=true",
              "type": "object",
              "properties": {
                "enabled": {
                  "type": "boolean"
                }
              }
            }
          }
        },
        "mode": {
          "type": "string",
          "enum": [
            "Disabled",
            "Strict",
            "Probe",
            "Partial"
          ]
        }
      }
    },
    "KubeProxyReplacementDeviceListItems0": {
      "description": "\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "ip": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "name": {
          "type": "string"
        }
      }
    },
    "KubeProxyReplacementFeatures": {
      "description": "\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "externalIPs": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "enabled": {
              "type": "boolean"
            }
          }
        },
        "gracefulTermination": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "enabled": {
              "type": "boolean"
            }
          }
        },
        "hostPort": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "enabled": {
              "type": "boolean"
            }
          }
        },
        "hostReachableServices": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "enabled": {
              "type": "boolean"
            },
            "protocols": {
              "type": "array",
              "items": {
                "type": "string"
              }
            }
          }
        },
        "nodePort": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "acceleration": {
              "type": "string",
              "enum": [
                "None",
                "Native",
                "Generic"
              ]
            },
            "algorithm": {
              "type": "string",
              "enum": [
                "Random",
                "Maglev"
              ]
            },
            "enabled": {
              "type": "boolean"
            },
            "lutSize": {
              "type": "integer"
            },
            "mode": {
              "type": "string",
              "enum": [
                "SNAT",
                "DSR",
                "Hybrid"
              ]
            },
            "portMax": {
              "type": "integer"
            },
            "portMin": {
              "type": "integer"
            }
          }
        },
        "sessionAffinity": {
          "description": "\n\n+k8s:deepcopy-gen=true",
          "type": "object",
          "properties": {
            "enabled": {
              "type": "boolean"
            }
          }
        }
      }
    },
    "KubeProxyReplacementFeaturesExternalIPs": {
      "description": "\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "enabled": {
          "type": "boolean"
        }
      }
    },
    "KubeProxyReplacementFeaturesGracefulTermination": {
      "description": "\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "enabled": {
          "type": "boolean"
        }
      }
    },
    "KubeProxyReplacementFeaturesHostPort": {
      "description": "\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "enabled": {
          "type": "boolean"
        }
      }
    },
    "KubeProxyReplacementFeaturesHostReachableServices": {
      "description": "\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "enabled": {
          "type": "boolean"
        },
        "protocols": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "KubeProxyReplacementFeaturesNodePort": {
      "description": "\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "acceleration": {
          "type": "string",
          "enum": [
            "None",
            "Native",
            "Generic"
          ]
        },
        "algorithm": {
          "type": "string",
          "enum": [
            "Random",
            "Maglev"
          ]
        },
        "enabled": {
          "type": "boolean"
        },
        "lutSize": {
          "type": "integer"
        },
        "mode": {
          "type": "string",
          "enum": [
            "SNAT",
            "DSR",
            "Hybrid"
          ]
        },
        "portMax": {
          "type": "integer"
        },
        "portMin": {
          "type": "integer"
        }
      }
    },
    "KubeProxyReplacementFeaturesSessionAffinity": {
      "description": "\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "enabled": {
          "type": "boolean"
        }
      }
    },
    "L4Policy": {
      "description": "L4 endpoint policy\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "egress": {
          "description": "List of L4 egress rules",
          "type": "array",
          "items": {
            "$ref": "#/definitions/PolicyRule"
          }
        },
        "ingress": {
          "description": "List of L4 ingress rules",
          "type": "array",
          "items": {
            "$ref": "#/definitions/PolicyRule"
          }
        }
      }
    },
    "LRPBackend": {
      "description": "Pod backend of an LRP",
      "type": "object",
      "properties": {
        "backend-address": {
          "$ref": "#/definitions/BackendAddress"
        },
        "pod-id": {
          "description": "Namespace and name of the backend pod",
          "type": "string"
        }
      }
    },
    "LRPSpec": {
      "description": "Configuration of an LRP",
      "type": "object",
      "properties": {
        "frontend-mappings": {
          "description": "mapping of frontends to pod backends",
          "type": "array",
          "items": {
            "$ref": "#/definitions/FrontendMapping"
          }
        },
        "frontend-type": {
          "description": "LRP frontend type",
          "type": "string"
        },
        "lrp-type": {
          "description": "LRP config type",
          "type": "string"
        },
        "name": {
          "description": "LRP service name",
          "type": "string"
        },
        "namespace": {
          "description": "LRP service namespace",
          "type": "string"
        },
        "service-id": {
          "description": "matching k8s service namespace and name",
          "type": "string"
        },
        "uid": {
          "description": "Unique identification",
          "type": "string"
        }
      }
    },
    "LabelConfiguration": {
      "description": "Label configuration of an endpoint",
      "type": "object",
      "properties": {
        "spec": {
          "description": "The user provided desired configuration",
          "$ref": "#/definitions/LabelConfigurationSpec"
        },
        "status": {
          "description": "The current configuration",
          "$ref": "#/definitions/LabelConfigurationStatus"
        }
      }
    },
    "LabelConfigurationSpec": {
      "description": "User desired Label configuration of an endpoint",
      "type": "object",
      "properties": {
        "user": {
          "description": "Custom labels in addition to orchestration system labels.",
          "$ref": "#/definitions/Labels"
        }
      }
    },
    "LabelConfigurationStatus": {
      "description": "Labels and label configuration of an endpoint",
      "type": "object",
      "properties": {
        "derived": {
          "description": "All labels derived from the orchestration system",
          "$ref": "#/definitions/Labels"
        },
        "disabled": {
          "description": "Labels derived from orchestration system which have been disabled.",
          "$ref": "#/definitions/Labels"
        },
        "realized": {
          "description": "The current configuration",
          "$ref": "#/definitions/LabelConfigurationSpec"
        },
        "security-relevant": {
          "description": "Labels derived from orchestration system that are used in computing a security identity",
          "$ref": "#/definitions/Labels"
        }
      }
    },
    "Labels": {
      "description": "Set of labels",
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "Masquerading": {
      "description": "Status of masquerading\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "enabled": {
          "type": "boolean"
        },
        "enabledProtocols": {
          "description": "Is masquerading enabled",
          "type": "object",
          "properties": {
            "ipv4": {
              "description": "Is masquerading enabled for IPv4 traffic",
              "type": "boolean"
            },
            "ipv6": {
              "description": "Is masquerading enabled for IPv6 traffic",
              "type": "boolean"
            }
          }
        },
        "ip-masq-agent": {
          "description": "Is BPF ip-masq-agent enabled",
          "type": "boolean"
        },
        "mode": {
          "type": "string",
          "enum": [
            "BPF",
            "iptables"
          ]
        },
        "snat-exclusion-cidr": {
          "description": "This field is obsolete, please use snat-exclusion-cidr-v4 or snat-exclusion-cidr-v6.",
          "type": "string"
        },
        "snat-exclusion-cidr-v4": {
          "description": "SnatExclusionCIDRv4 exempts SNAT from being performed on any packet sent to\nan IPv4 address that belongs to this CIDR.",
          "type": "string"
        },
        "snat-exclusion-cidr-v6": {
          "description": "SnatExclusionCIDRv6 exempts SNAT from being performed on any packet sent to\nan IPv6 address that belongs to this CIDR.\nFor IPv6 we only do masquerading in iptables mode.",
          "type": "string"
        }
      }
    },
    "MasqueradingEnabledProtocols": {
      "description": "Is masquerading enabled",
      "type": "object",
      "properties": {
        "ipv4": {
          "description": "Is masquerading enabled for IPv4 traffic",
          "type": "boolean"
        },
        "ipv6": {
          "description": "Is masquerading enabled for IPv6 traffic",
          "type": "boolean"
        }
      }
    },
    "MessageForwardingStatistics": {
      "description": "Statistics of a message forwarding entity",
      "type": "object",
      "properties": {
        "denied": {
          "description": "Number of messages denied",
          "type": "integer"
        },
        "error": {
          "description": "Number of errors while parsing messages",
          "type": "integer"
        },
        "forwarded": {
          "description": "Number of messages forwarded",
          "type": "integer"
        },
        "received": {
          "description": "Number of messages received",
          "type": "integer"
        }
      }
    },
    "Metric": {
      "description": "Metric information",
      "type": "object",
      "properties": {
        "labels": {
          "description": "Labels of the metric",
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        },
        "name": {
          "description": "Name of the metric",
          "type": "string"
        },
        "value": {
          "description": "Value of the metric",
          "type": "number"
        }
      }
    },
    "MonitorStatus": {
      "description": "Status of the node monitor",
      "properties": {
        "cpus": {
          "description": "Number of CPUs to listen on for events.",
          "type": "integer"
        },
        "lost": {
          "description": "Number of samples lost by perf.",
          "type": "integer"
        },
        "npages": {
          "description": "Number of pages used for the perf ring buffer.",
          "type": "integer"
        },
        "pagesize": {
          "description": "Pages size used for the perf ring buffer.",
          "type": "integer"
        },
        "unknown": {
          "description": "Number of unknown samples.",
          "type": "integer"
        }
      }
    },
    "NameManager": {
      "description": "Internal state about DNS names in relation to policy subsystem",
      "type": "object",
      "properties": {
        "DNSPollNames": {
          "description": "Names to poll for DNS Poller",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "FQDNPolicySelectors": {
          "description": "Mapping of FQDNSelectors to corresponding regular expressions",
          "type": "array",
          "items": {
            "$ref": "#/definitions/SelectorEntry"
          }
        }
      }
    },
    "NamedPorts": {
      "description": "List of named Layer 4 port and protocol pairs which will be used in Network\nPolicy specs.\n\n+deepequal-gen=true\n+k8s:deepcopy-gen=true",
      "type": "array",
      "items": {
        "$ref": "#/definitions/Port"
      }
    },
    "NodeAddressing": {
      "description": "Addressing information of a node for all address families\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "ipv4": {
          "$ref": "#/definitions/NodeAddressingElement"
        },
        "ipv6": {
          "$ref": "#/definitions/NodeAddressingElement"
        }
      }
    },
    "NodeAddressingElement": {
      "description": "Addressing information",
      "type": "object",
      "properties": {
        "address-type": {
          "description": "Node address type, one of HostName, ExternalIP or InternalIP",
          "type": "string"
        },
        "alloc-range": {
          "description": "Address pool to be used for local endpoints",
          "type": "string"
        },
        "enabled": {
          "description": "True if address family is enabled",
          "type": "boolean"
        },
        "ip": {
          "description": "IP address of node",
          "type": "string"
        }
      }
    },
    "NodeElement": {
      "description": "Known node in the cluster\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "health-endpoint-address": {
          "description": "Address used for probing cluster connectivity",
          "$ref": "#/definitions/NodeAddressing"
        },
        "name": {
          "description": "Name of the node including the cluster association. This is typically\n\u003cclustername\u003e/\u003chostname\u003e.\n",
          "type": "string"
        },
        "primary-address": {
          "description": "Primary address used for intra-cluster communication",
          "$ref": "#/definitions/NodeAddressing"
        },
        "secondary-addresses": {
          "description": "Alternative addresses assigned to the node",
          "type": "array",
          "items": {
            "$ref": "#/definitions/NodeAddressingElement"
          }
        }
      }
    },
    "Policy": {
      "description": "Policy definition",
      "type": "object",
      "properties": {
        "policy": {
          "description": "Policy definition as JSON.",
          "type": "string"
        },
        "revision": {
          "description": "Revision number of the policy. Incremented each time the policy is\nchanged in the agent's repository\n",
          "type": "integer"
        }
      }
    },
    "PolicyRule": {
      "description": "A policy rule including the rule labels it derives from\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "derived-from-rules": {
          "description": "The policy rule labels identifying the policy rules this rule derives from",
          "type": "array",
          "items": {
            "type": "array",
            "items": {
              "type": "string"
            }
          }
        },
        "rule": {
          "description": "The policy rule as json",
          "type": "string"
        }
      }
    },
    "PolicyTraceResult": {
      "description": "Response to a policy resolution process",
      "type": "object",
      "properties": {
        "log": {
          "type": "string"
        },
        "verdict": {
          "type": "string"
        }
      }
    },
    "Port": {
      "description": "Layer 4 port / protocol pair\n\n+deepequal-gen=true",
      "type": "object",
      "properties": {
        "name": {
          "description": "Optional layer 4 port name",
          "type": "string"
        },
        "port": {
          "description": "Layer 4 port number",
          "type": "integer",
          "format": "uint16"
        },
        "protocol": {
          "description": "Layer 4 protocol",
          "type": "string",
          "enum": [
            "TCP",
            "UDP",
            "ICMP",
            "ICMPV6",
            "ANY"
          ]
        }
      }
    },
    "Prefilter": {
      "description": "Collection of endpoints to be served",
      "type": "object",
      "properties": {
        "spec": {
          "$ref": "#/definitions/PrefilterSpec"
        },
        "status": {
          "$ref": "#/definitions/PrefilterStatus"
        }
      }
    },
    "PrefilterSpec": {
      "description": "CIDR ranges implemented in the Prefilter",
      "type": "object",
      "properties": {
        "deny": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "revision": {
          "type": "integer"
        }
      }
    },
    "PrefilterStatus": {
      "description": "CIDR ranges implemented in the Prefilter",
      "type": "object",
      "properties": {
        "realized": {
          "$ref": "#/definitions/PrefilterSpec"
        }
      }
    },
    "ProxyRedirect": {
      "description": "Configured proxy redirection state",
      "type": "object",
      "properties": {
        "name": {
          "description": "Name of the proxy redirect",
          "type": "string"
        },
        "proxy": {
          "description": "Name of the proxy this redirect points to",
          "type": "string"
        },
        "proxy-port": {
          "description": "Host port that this redirect points to",
          "type": "integer"
        }
      }
    },
    "ProxyStatistics": {
      "description": "Statistics of a set of proxy redirects for an endpoint\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "allocated-proxy-port": {
          "description": "The port the proxy is listening on",
          "type": "integer"
        },
        "location": {
          "description": "Location of where the redirect is installed",
          "type": "string",
          "enum": [
            "ingress",
            "egress"
          ]
        },
        "port": {
          "description": "The port subject to the redirect",
          "type": "integer"
        },
        "protocol": {
          "description": "Name of the L7 protocol",
          "type": "string"
        },
        "statistics": {
          "description": "Statistics of this set of proxy redirect",
          "$ref": "#/definitions/RequestResponseStatistics"
        }
      }
    },
    "ProxyStatus": {
      "description": "Status of proxy\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "ip": {
          "description": "IP address that the proxy listens on",
          "type": "string"
        },
        "port-range": {
          "description": "Port range used for proxying",
          "type": "string"
        },
        "redirects": {
          "description": "Detailed description of configured redirects",
          "type": "array",
          "items": {
            "$ref": "#/definitions/ProxyRedirect"
          }
        },
        "total-ports": {
          "description": "Total number of listening proxy ports",
          "type": "integer"
        },
        "total-redirects": {
          "description": "Total number of ports configured to redirect to proxies",
          "type": "integer"
        }
      }
    },
    "Recorder": {
      "description": "Collection of wildcard filters for pcap recorder",
      "type": "object",
      "properties": {
        "spec": {
          "$ref": "#/definitions/RecorderSpec"
        },
        "status": {
          "$ref": "#/definitions/RecorderStatus"
        }
      }
    },
    "RecorderFilter": {
      "description": "n-tuple filter to match traffic to be recorded",
      "type": "object",
      "properties": {
        "dst-port": {
          "description": "Layer 4 destination port, zero (or in future range)",
          "type": "string"
        },
        "dst-prefix": {
          "description": "Layer 3 destination CIDR",
          "type": "string"
        },
        "protocol": {
          "description": "Layer 4 protocol",
          "type": "string",
          "enum": [
            "TCP",
            "UDP",
            "ANY"
          ]
        },
        "src-port": {
          "description": "Layer 4 source port, zero (or in future range)",
          "type": "string"
        },
        "src-prefix": {
          "description": "Layer 3 source CIDR",
          "type": "string"
        }
      }
    },
    "RecorderMask": {
      "description": "Individual mask for pcap recorder",
      "type": "object",
      "properties": {
        "status": {
          "$ref": "#/definitions/RecorderMaskStatus"
        }
      }
    },
    "RecorderMaskSpec": {
      "description": "Configuration of a recorder mask",
      "type": "object",
      "properties": {
        "dst-port-mask": {
          "description": "Layer 4 destination port mask",
          "type": "string"
        },
        "dst-prefix-mask": {
          "description": "Layer 3 destination IP mask",
          "type": "string"
        },
        "priority": {
          "description": "Priority of this mask",
          "type": "integer"
        },
        "protocol-mask": {
          "description": "Layer 4 protocol mask",
          "type": "string"
        },
        "src-port-mask": {
          "description": "Layer 4 source port mask",
          "type": "string"
        },
        "src-prefix-mask": {
          "description": "Layer 3 source IP mask",
          "type": "string"
        },
        "users": {
          "description": "Number of users of this mask",
          "type": "integer"
        }
      }
    },
    "RecorderMaskStatus": {
      "description": "Configuration of a recorder mask",
      "type": "object",
      "properties": {
        "realized": {
          "$ref": "#/definitions/RecorderMaskSpec"
        }
      }
    },
    "RecorderSpec": {
      "description": "Configuration of a recorder",
      "type": "object",
      "required": [
        "id",
        "filters"
      ],
      "properties": {
        "capture-length": {
          "description": "Maximum packet length or zero for full packet length",
          "type": "integer"
        },
        "filters": {
          "description": "List of wildcard filters for given recorder",
          "type": "array",
          "items": {
            "$ref": "#/definitions/RecorderFilter"
          }
        },
        "id": {
          "description": "Unique identification",
          "type": "integer"
        }
      }
    },
    "RecorderStatus": {
      "description": "Configuration of a recorder",
      "type": "object",
      "properties": {
        "realized": {
          "$ref": "#/definitions/RecorderSpec"
        }
      }
    },
    "RemoteCluster": {
      "description": "Status of remote cluster\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "last-failure": {
          "description": "Time of last failure that occurred while attempting to reach the cluster",
          "type": "string",
          "format": "date-time"
        },
        "name": {
          "description": "Name of the cluster",
          "type": "string"
        },
        "num-failures": {
          "description": "Number of failures reaching the cluster",
          "type": "integer"
        },
        "num-identities": {
          "description": "Number of identities in the cluster",
          "type": "integer"
        },
        "num-nodes": {
          "description": "Number of nodes in the cluster",
          "type": "integer"
        },
        "num-shared-services": {
          "description": "Number of services in the cluster",
          "type": "integer"
        },
        "ready": {
          "description": "Indicates readiness of the remote cluser",
          "type": "boolean"
        },
        "status": {
          "description": "Status of the control plane",
          "type": "string"
        }
      }
    },
    "RequestResponseStatistics": {
      "description": "Statistics of a proxy redirect\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "requests": {
          "$ref": "#/definitions/MessageForwardingStatistics"
        },
        "responses": {
          "$ref": "#/definitions/MessageForwardingStatistics"
        }
      }
    },
    "SelectorCache": {
      "description": "cache of which identities match selectors in the policy repository",
      "type": "array",
      "items": {
        "$ref": "#/definitions/SelectorIdentityMapping"
      }
    },
    "SelectorEntry": {
      "description": "Mapping of FQDNSelector to corresponding regular expression",
      "type": "object",
      "properties": {
        "regexString": {
          "description": "String representation of regular expression form of FQDNSelector",
          "type": "string"
        },
        "selectorString": {
          "description": "FQDNSelector in string representation",
          "type": "string"
        }
      }
    },
    "SelectorIdentityMapping": {
      "description": "mapping of selector to identities which match it",
      "type": "object",
      "properties": {
        "identities": {
          "description": "identities mapping to this selector",
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "selector": {
          "description": "string form of selector",
          "type": "string"
        },
        "users": {
          "description": "number of users of this selector in the cache",
          "type": "integer"
        }
      }
    },
    "Service": {
      "description": "Collection of endpoints to be served",
      "type": "object",
      "properties": {
        "spec": {
          "$ref": "#/definitions/ServiceSpec"
        },
        "status": {
          "$ref": "#/definitions/ServiceStatus"
        }
      }
    },
    "ServiceSpec": {
      "description": "Configuration of a service",
      "type": "object",
      "required": [
        "frontend-address"
      ],
      "properties": {
        "backend-addresses": {
          "description": "List of backend addresses",
          "type": "array",
          "items": {
            "$ref": "#/definitions/BackendAddress"
          }
        },
        "flags": {
          "description": "Optional service configuration flags",
          "type": "object",
          "properties": {
            "healthCheckNodePort": {
              "description": "Service health check node port",
              "type": "integer",
              "format": "uint16"
            },
            "name": {
              "description": "Service name  (e.g. Kubernetes service name)",
              "type": "string"
            },
            "namespace": {
              "description": "Service namespace  (e.g. Kubernetes namespace)",
              "type": "string"
            },
            "trafficPolicy": {
              "description": "Service traffic policy",
              "type": "string",
              "enum": [
                "Cluster",
                "Local"
              ]
            },
            "type": {
              "description": "Service type",
              "type": "string",
              "enum": [
                "ClusterIP",
                "NodePort",
                "ExternalIPs",
                "HostPort",
                "LoadBalancer",
                "LocalRedirect"
              ]
            }
          }
        },
        "frontend-address": {
          "description": "Frontend address",
          "$ref": "#/definitions/FrontendAddress"
        },
        "id": {
          "description": "Unique identification",
          "type": "integer"
        }
      }
    },
    "ServiceSpecFlags": {
      "description": "Optional service configuration flags",
      "type": "object",
      "properties": {
        "healthCheckNodePort": {
          "description": "Service health check node port",
          "type": "integer",
          "format": "uint16"
        },
        "name": {
          "description": "Service name  (e.g. Kubernetes service name)",
          "type": "string"
        },
        "namespace": {
          "description": "Service namespace  (e.g. Kubernetes namespace)",
          "type": "string"
        },
        "trafficPolicy": {
          "description": "Service traffic policy",
          "type": "string",
          "enum": [
            "Cluster",
            "Local"
          ]
        },
        "type": {
          "description": "Service type",
          "type": "string",
          "enum": [
            "ClusterIP",
            "NodePort",
            "ExternalIPs",
            "HostPort",
            "LoadBalancer",
            "LocalRedirect"
          ]
        }
      }
    },
    "ServiceStatus": {
      "description": "Configuration of a service",
      "type": "object",
      "properties": {
        "realized": {
          "$ref": "#/definitions/ServiceSpec"
        }
      }
    },
    "Status": {
      "description": "Status of an individual component",
      "type": "object",
      "properties": {
        "msg": {
          "description": "Human readable status/error/warning message",
          "type": "string"
        },
        "state": {
          "description": "State the component is in",
          "type": "string",
          "enum": [
            "Ok",
            "Warning",
            "Failure",
            "Disabled"
          ]
        }
      }
    },
    "StatusResponse": {
      "description": "Health and status information of daemon\n\n+k8s:deepcopy-gen=true",
      "type": "object",
      "properties": {
        "bandwidth-manager": {
          "description": "Status of bandwidth manager",
          "$ref": "#/definitions/BandwidthManager"
        },
        "bpf-maps": {
          "description": "Status of BPF maps",
          "$ref": "#/definitions/BPFMapStatus"
        },
        "cilium": {
          "description": "Status of Cilium daemon",
          "$ref": "#/definitions/Status"
        },
        "client-id": {
          "description": "When supported by the API, this client ID should be used by the\nclient when making another request to the server.\nSee for example \"/cluster/nodes\".\n",
          "type": "integer"
        },
        "clock-source": {
          "description": "Status of clock source",
          "$ref": "#/definitions/ClockSource"
        },
        "cluster": {
          "description": "Status of cluster",
          "$ref": "#/definitions/ClusterStatus"
        },
        "cluster-mesh": {
          "description": "Status of ClusterMesh",
          "$ref": "#/definitions/ClusterMeshStatus"
        },
        "container-runtime": {
          "description": "Status of local container runtime",
          "$ref": "#/definitions/Status"
        },
        "controllers": {
          "description": "Status of all endpoint controllers",
          "$ref": "#/definitions/ControllerStatuses"
        },
        "encryption": {
          "description": "Status of transparent encryption",
          "$ref": "#/definitions/EncryptionStatus"
        },
        "host-firewall": {
          "description": "Status of the host firewall",
          "$ref": "#/definitions/HostFirewall"
        },
        "host-routing": {
          "description": "Status of host routing",
          "$ref": "#/definitions/HostRouting"
        },
        "hubble": {
          "description": "Status of Hubble server",
          "$ref": "#/definitions/HubbleStatus"
        },
        "ipam": {
          "description": "Status of IP address management",
          "$ref": "#/definitions/IPAMStatus"
        },
        "kube-proxy-replacement": {
          "description": "Status of kube-proxy replacement",
          "$ref": "#/definitions/KubeProxyReplacement"
        },
        "kubernetes": {
          "description": "Status of Kubernetes integration",
          "$ref": "#/definitions/K8sStatus"
        },
        "kvstore": {
          "description": "Status of key/value datastore",
          "$ref": "#/definitions/Status"
        },
        "masquerading": {
          "description": "Status of masquerading",
          "$ref": "#/definitions/Masquerading"
        },
        "nodeMonitor": {
          "description": "Status of the node monitor",
          "$ref": "#/definitions/MonitorStatus"
        },
        "proxy": {
          "description": "Status of proxy",
          "$ref": "#/definitions/ProxyStatus"
        },
        "stale": {
          "description": "List of stale information in the status",
          "type": "object",
          "additionalProperties": {
            "description": "Timestamp when the probe was started",
            "type": "string",
            "format": "date-time"
          }
        }
      }
    },
    "TraceFrom": {
      "type": "object",
      "properties": {
        "labels": {
          "$ref": "#/definitions/Labels"
        }
      }
    },
    "TraceSelector": {
      "description": "Context describing a pair of source and destination identity",
      "type": "object",
      "properties": {
        "from": {
          "$ref": "#/definitions/TraceFrom"
        },
        "to": {
          "$ref": "#/definitions/TraceTo"
        },
        "verbose": {
          "description": "Enable verbose tracing.\n",
          "type": "boolean"
        }
      }
    },
    "TraceTo": {
      "type": "object",
      "properties": {
        "dports": {
          "description": "List of Layer 4 port and protocol pairs which will be used in communication\nfrom the source identity to the destination identity.\n",
          "type": "array",
          "items": {
            "$ref": "#/definitions/Port"
          }
        },
        "labels": {
          "$ref": "#/definitions/Labels"
        }
      }
    },
    "WireguardInterface": {
      "description": "Status of a Wireguard interface\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "listen-port": {
          "description": "Port on which the Wireguard endpoint is exposed",
          "type": "integer"
        },
        "name": {
          "description": "Name of the interface",
          "type": "string"
        },
        "peer-count": {
          "description": "Number of peers configured on this interface",
          "type": "integer"
        },
        "peers": {
          "description": "Optional list of wireguard peers",
          "type": "array",
          "items": {
            "$ref": "#/definitions/WireguardPeer"
          }
        },
        "public-key": {
          "description": "Public key of this interface",
          "type": "string"
        }
      }
    },
    "WireguardPeer": {
      "description": "Status of a Wireguard peer\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "allowed-ips": {
          "description": "List of IPs which may be routed through this peer",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "endpoint": {
          "description": "Endpoint on which we are connected to this peer",
          "type": "string"
        },
        "last-handshake-time": {
          "description": "Timestamp of the last handshake with this peer",
          "type": "string",
          "format": "date-time"
        },
        "public-key": {
          "description": "Public key of this peer",
          "type": "string"
        },
        "transfer-rx": {
          "description": "Number of received bytes",
          "type": "integer"
        },
        "transfer-tx": {
          "description": "Number of sent bytes",
          "type": "integer"
        }
      }
    },
    "WireguardStatus": {
      "description": "Status of the Wireguard agent\n\n+k8s:deepcopy-gen=true",
      "properties": {
        "interfaces": {
          "description": "Wireguard interfaces managed by this Cilium instance",
          "type": "array",
          "items": {
            "$ref": "#/definitions/WireguardInterface"
          }
        }
      }
    }
  },
  "parameters": {
    "cidr": {
      "type": "string",
      "description": "A CIDR range of IPs",
      "name": "cidr",
      "in": "query"
    },
    "endpoint-change-request": {
      "name": "endpoint",
      "in": "body",
      "required": true,
      "schema": {
        "$ref": "#/definitions/EndpointChangeRequest"
      }
    },
    "endpoint-id": {
      "type": "string",
      "description": "String describing an endpoint with the format `+"`"+``+"`"+`[prefix:]id`+"`"+``+"`"+`. If no prefix\nis specified, a prefix of `+"`"+``+"`"+`cilium-local:`+"`"+``+"`"+` is assumed. Not all endpoints\nwill be addressable by all endpoint ID prefixes with the exception of the\nlocal Cilium UUID which is assigned to all endpoints.\n\nSupported endpoint id prefixes:\n  - cilium-local: Local Cilium endpoint UUID, e.g. cilium-local:3389595\n  - cilium-global: Global Cilium endpoint UUID, e.g. cilium-global:cluster1:nodeX:452343\n  - container-id: Container runtime ID, e.g. container-id:22222\n  - container-name: Container name, e.g. container-name:foobar\n  - pod-name: pod name for this container if K8s is enabled, e.g. pod-name:default:foobar\n  - docker-endpoint: Docker libnetwork endpoint ID, e.g. docker-endpoint:4444\n",
      "name": "id",
      "in": "path",
      "required": true
    },
    "identity-id": {
      "type": "string",
      "description": "Cluster wide unique identifier of a security identity.\n",
      "name": "id",
      "in": "path",
      "required": true
    },
    "ipam-expiration": {
      "type": "boolean",
      "name": "expiration",
      "in": "header"
    },
    "ipam-family": {
      "enum": [
        "ipv4",
        "ipv6"
      ],
      "type": "string",
      "name": "family",
      "in": "query"
    },
    "ipam-ip": {
      "type": "string",
      "description": "IP address",
      "name": "ip",
      "in": "path",
      "required": true
    },
    "ipam-owner": {
      "type": "string",
      "name": "owner",
      "in": "query"
    },
    "ipam-release-arg": {
      "type": "string",
      "description": "IP address or owner name",
      "name": "ip",
      "in": "path",
      "required": true
    },
    "labels": {
      "description": "List of labels\n",
      "name": "labels",
      "in": "body",
      "schema": {
        "$ref": "#/definitions/Labels"
      }
    },
    "map-name": {
      "type": "string",
      "description": "Name of map",
      "name": "name",
      "in": "path",
      "required": true
    },
    "matchpattern": {
      "type": "string",
      "description": "A toFQDNs compatible matchPattern expression",
      "name": "matchpattern",
      "in": "query"
    },
    "pod-name": {
      "type": "string",
      "description": "K8s pod name\n",
      "name": "pod",
      "in": "path",
      "required": true
    },
    "policy-rules": {
      "description": "Policy rules",
      "name": "policy",
      "in": "body",
      "required": true,
      "schema": {
        "type": "string"
      }
    },
    "prefilter-spec": {
      "description": "List of CIDR ranges for filter table",
      "name": "prefilter-spec",
      "in": "body",
      "required": true,
      "schema": {
        "$ref": "#/definitions/PrefilterSpec"
      }
    },
    "recorder-config": {
      "description": "Recorder configuration",
      "name": "config",
      "in": "body",
      "required": true,
      "schema": {
        "$ref": "#/definitions/RecorderSpec"
      }
    },
    "recorder-id": {
      "type": "integer",
      "description": "ID of recorder",
      "name": "id",
      "in": "path",
      "required": true
    },
    "service-address": {
      "description": "Service address configuration",
      "name": "address",
      "in": "body",
      "schema": {
        "$ref": "#/definitions/FrontendAddress"
      }
    },
    "service-config": {
      "description": "Service configuration",
      "name": "config",
      "in": "body",
      "required": true,
      "schema": {
        "$ref": "#/definitions/ServiceSpec"
      }
    },
    "service-id": {
      "type": "integer",
      "description": "ID of service",
      "name": "id",
      "in": "path",
      "required": true
    },
    "trace-selector": {
      "description": "Context to provide policy evaluation on",
      "name": "trace-selector",
      "in": "body",
      "schema": {
        "$ref": "#/definitions/TraceSelector"
      }
    }
  },
  "x-schemes": [
    "unix"
  ]
}`))}