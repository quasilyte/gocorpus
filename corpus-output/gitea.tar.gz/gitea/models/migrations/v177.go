package migrations;import("fmt";"xorm.io/xorm");func deleteOrphanedIssueLabels(x *xorm.Engine)error{type IssueLabel struct{ID int64;IssueID int64;LabelID int64};sess:=x.NewSession();defer sess.Close();if err:=sess.Begin();err!=nil{return err};if err:=sess.Sync2(new(IssueLabel));err!=nil{return fmt.Errorf("Sync2: %v",err)};if _,err:=sess.Exec(`DELETE FROM issue_label WHERE issue_label.id IN (
		SELECT ill.id FROM (
			SELECT il.id
			FROM issue_label AS il
				LEFT JOIN label ON il.label_id = label.id
			WHERE
				label.id IS NULL
		) AS ill)`);err!=nil{return err};return sess.Commit()}