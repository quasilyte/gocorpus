package scalar_test;import("bufio";"fmt";"log";"strings";"gonum.org/v1/gonum/floats/scalar";"gonum.org/v1/gonum/stat");func ExampleParseWithNA(){const data=`6
missing
4
`;var vals,weights []float64;sc:=bufio.NewScanner(strings.NewReader(data));for sc.Scan(){v,w,err:=scalar.ParseWithNA(sc.Text(),"missing");if err!=nil{log.Fatal(err)};vals=append(vals,v);weights=append(weights,w)};err:=sc.Err();if err!=nil{log.Fatal(err)};fmt.Println(stat.Mean(vals,weights))}