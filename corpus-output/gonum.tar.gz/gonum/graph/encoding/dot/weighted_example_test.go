package dot_test;import("fmt";"log";"math";"strconv";"gonum.org/v1/gonum/graph";"gonum.org/v1/gonum/graph/encoding";"gonum.org/v1/gonum/graph/encoding/dot";"gonum.org/v1/gonum/graph/simple");type dotGraph struct{*simple.WeightedUndirectedGraph};func newDotGraph()*dotGraph{return &dotGraph{WeightedUndirectedGraph:simple.NewWeightedUndirectedGraph(0,0)}};func(g *dotGraph)NewEdge(from,to graph.Node)graph.Edge{e:=g.WeightedUndirectedGraph.NewWeightedEdge(from,to,math.NaN()).(simple.WeightedEdge);return &weightedEdge{WeightedEdge:e}};func(g *dotGraph)NewNode()graph.Node{return &node{Node:g.WeightedUndirectedGraph.NewNode()}};func(g *dotGraph)SetEdge(e graph.Edge){g.WeightedUndirectedGraph.SetWeightedEdge(e.(*weightedEdge))};type weightedEdge struct{simple.WeightedEdge};func(e *weightedEdge)SetAttribute(attr encoding.Attribute)error{if attr.Key!="weight"{return fmt.Errorf("unable to unmarshal node DOT attribute with key %q",attr.Key)};var err error;e.W,err=strconv.ParseFloat(attr.Value,64);return err};type node struct{graph.Node;dotID string};func(n *node)SetDOTID(id string){n.dotID=id};func(n *node)String()string{return n.dotID};const ug=`
graph {
	a
	b
	c
	a--b ["weight"=0.5]
	a--c ["weight"=1]
}
`;func ExampleUnmarshal_weighted(){dst:=newDotGraph();err:=dot.Unmarshal([]byte(ug),dst);if err!=nil{log.Fatal(err)};for _,e:=range graph.EdgesOf(dst.Edges()){fmt.Printf("%+v\n",e.(*weightedEdge).WeightedEdge)}}