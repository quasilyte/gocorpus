package rdf_test;import("fmt";"strings";"gonum.org/v1/gonum/graph/formats/rdf");func ExampleLean(){for i,statements:=range []string{0:`
_:author1 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:gonum .
_:author3 <ex:contributesTo> _:gonum .
`,1:`
_:author1 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:gonum .
_:author3 <ex:contributesTo> _:gonum .
_:gonum <ex:dependsOn> _:go .
`,2:`
_:author1 <ex:contributesTo> _:go .
_:author1 <ex:notContributesTo> _:gonum .
_:author2 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:gonum .
_:author3 <ex:contributesTo> _:gonum .
_:gonum <ex:dependsOn> _:go .
`,3:`
_:author1 <ex:is> "Alice" .
_:author1 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:gonum .
_:author3 <ex:contributesTo> _:gonum .
_:gonum <ex:dependsOn> _:go .
`,4:`
_:author1 <ex:contributesTo> _:go .
_:author1 <ex:notContributesTo> _:gonum .
_:author2 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:gonum .
_:author3 <ex:contributesTo> _:gonum .
_:author3 <ex:notContributesTo> _:go .
_:gonum <ex:dependsOn> _:go .
`,5:`
_:author1 <ex:is> "Alice" .
_:author2 <ex:is> "Bob" .
_:author1 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:gonum .
_:author3 <ex:contributesTo> _:gonum .
_:gonum <ex:dependsOn> _:go .
`,6:`
_:author1 <ex:is> "Alice" .
_:author2 <ex:is> "Bob" .
_:author3 <ex:is> "Charlie" .
_:author1 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:go .
_:author2 <ex:contributesTo> _:gonum .
_:author3 <ex:contributesTo> _:gonum .
_:gonum <ex:dependsOn> _:go .
`}{dec:=rdf.NewDecoder(strings.NewReader(statements));var s []*rdf.Statement;for{l,err:=dec.Unmarshal();if err!=nil{break};s=append(s,l)};lean,err:=rdf.Lean(s);if err!=nil{fmt.Println(err)};_,err=rdf.URDNA2015(lean,lean);if err!=nil{fmt.Println(err);continue};fmt.Printf("%d:\n",i);for _,s:=range lean{fmt.Println(s)};fmt.Println()}}