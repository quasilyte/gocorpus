package rdf_test;import("crypto/md5";"fmt";"log";"os";"sort";"strings";"text/tabwriter";"gonum.org/v1/gonum/graph/formats/rdf");func ExampleIsoCanonicalHashes_isomorphisms(){for _,statements:=range []string{`
<https://example.com/1> <https://example.com/2> <https://example.com/3> .
<https://example.com/3> <https://example.com/4> <https://example.com/5> .
`,`
_:a <ex:q> <ex:p> .
_:b <ex:q> <ex:p> .
_:c <ex:p> _:a .
_:d <ex:p> _:b .
_:c <ex:r> _:d .
`,`
_:a1 <ex:q> <ex:p> .
_:b1 <ex:q> <ex:p> .
_:c1 <ex:p> _:a1 .
_:d1 <ex:p> _:b1 .
_:c1 <ex:r> _:d1 .
`,`
# G
<ex:p> <ex:q> _:a .
<ex:p> <ex:q> _:b .
<ex:s> <ex:p> _:a .
<ex:s> <ex:r> _:c .
_:c <ex:p> _:b .

# H
<ex:p> <ex:q> _:d .
<ex:p> <ex:q> _:e .
_:f <ex:p> _:d .
_:f <ex:r> _:g .
_:g <ex:p> _:e .
`,`
_:greet <l:is> "hola"@es .
`}{dec:=rdf.NewDecoder(strings.NewReader(statements));var s []*rdf.Statement;for{l,err:=dec.Unmarshal();if err!=nil{break};s=append(s,l)};hashes,_:=rdf.IsoCanonicalHashes(s,false,true,md5.New(),make([]byte,16));var blanks []string;for k:=range hashes{if strings.HasPrefix(k,"_:"){blanks=append(blanks,k)}};sort.Strings(blanks);if len(blanks)==0{fmt.Println("No blank nodes.")}else{w:=tabwriter.NewWriter(os.Stdout,0,4,1,' ',0);fmt.Fprintln(w,"Node\tHash");for _,k:=range blanks{fmt.Fprintf(w,"%s\t%032x\n",k,hashes[k])};w.Flush()};fmt.Println()}};func ExampleIsoCanonicalHashes_isomorphicParts(){for _,statements:=range []string{`
# Part 1
_:a <ex:q> <ex:p> .
_:b <ex:q> <ex:p> .
_:c <ex:p> _:a .
_:d <ex:p> _:b .
_:c <ex:r> _:d .

# Part 2
_:a1 <ex:q> <ex:p> .
_:b1 <ex:q> <ex:p> .
_:c1 <ex:p> _:a1 .
_:d1 <ex:p> _:b1 .
_:c1 <ex:r> _:d1 .
`}{dec:=rdf.NewDecoder(strings.NewReader(statements));var s []*rdf.Statement;for{l,err:=dec.Unmarshal();if err!=nil{break};s=append(s,l)};hashes,_:=rdf.IsoCanonicalHashes(s,true,false,md5.New(),make([]byte,16));var blanks []string;for k:=range hashes{if strings.HasPrefix(k,"_:"){blanks=append(blanks,k)}};sort.Strings(blanks);if len(blanks)==0{fmt.Println("No blank nodes.")}else{w:=tabwriter.NewWriter(os.Stdout,0,4,1,' ',0);fmt.Fprintln(w,"Node\tHash");for _,k:=range blanks{fmt.Fprintf(w,"%s\t%032x\n",k,hashes[k])};w.Flush()};fmt.Println()}};func ExampleC14n(){for _,statements:=range []string{`
_:a <ex:q> <ex:p> .
_:b <ex:q> <ex:p> .
_:c <ex:p> _:a .
_:d <ex:p> _:b .
_:c <ex:r> _:d .
`,`
_:c1 <ex:p> _:a1 .
_:b1 <ex:q> <ex:p> .
_:d1 <ex:p> _:b1 .
_:a1 <ex:q> <ex:p> .
_:c1 <ex:r> _:d1 .
`}{dec:=rdf.NewDecoder(strings.NewReader(statements));var s []*rdf.Statement;for{l,err:=dec.Unmarshal();if err!=nil{break};s=append(s,l)};_,terms:=rdf.IsoCanonicalHashes(s,false,true,md5.New(),make([]byte,16));relabeled,err:=rdf.C14n(nil,s,terms);if err!=nil{log.Fatal(err)};for _,s:=range relabeled{fmt.Println(s)};fmt.Println()}}