package rdf_test;import("fmt";"log";"os";"strings";"text/tabwriter";"gonum.org/v1/gonum/graph";"gonum.org/v1/gonum/graph/encoding";"gonum.org/v1/gonum/graph/encoding/dot";"gonum.org/v1/gonum/graph/formats/rdf";"gonum.org/v1/gonum/graph/multi");type dotNode struct{rdf.Term};func(n dotNode)DOTID()string{return n.Term.Value};type dotLine struct{*rdf.Statement};func(l dotLine)From()graph.Node{return dotNode{l.Subject}};func(l dotLine)To()graph.Node{return dotNode{l.Object}};func(l dotLine)Attributes()[]encoding.Attribute{return []encoding.Attribute{{Key:"label",Value:l.Predicate.Value}}};func Example_graph(){const statements=`
_:alice <http://xmlns.com/foaf/0.1/knows> _:bob .
_:alice <http://xmlns.com/foaf/0.1/givenName> "Alice" .
_:alice <http://xmlns.com/foaf/0.1/familyName> "Smith" .
_:bob <http://xmlns.com/foaf/0.1/knows> _:alice .
_:bob <http://xmlns.com/foaf/0.1/givenName> "Bob" .
_:bob <http://xmlns.com/foaf/0.1/familyName> "Smith" .
`;g:=multi.NewDirectedGraph();dec:=rdf.NewDecoder(strings.NewReader(statements));for{l,err:=dec.Unmarshal();if err!=nil{break};g.SetLine(dotLine{l})};b,err:=dot.MarshalMulti(g,"smiths","","\t");if err!=nil{log.Fatal(err)};fmt.Printf("%s\n\n",b);w:=tabwriter.NewWriter(os.Stdout,0,4,1,' ',0);fmt.Fprintln(w,"Term\tID");for t,id:=range dec.Terms(){fmt.Fprintf(w,"%s\t%d\n",t,id)};w.Flush()}