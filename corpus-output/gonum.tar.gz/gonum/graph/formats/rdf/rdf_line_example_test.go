package rdf_test;import("fmt";"log";"strings";"gonum.org/v1/gonum/graph";"gonum.org/v1/gonum/graph/encoding";"gonum.org/v1/gonum/graph/encoding/dot";"gonum.org/v1/gonum/graph/formats/rdf";"gonum.org/v1/gonum/graph/multi");type foodNode struct{rdf.Term};func(n foodNode)DOTID()string{text,_,kind,err:=n.Term.Parts();if err!=nil{return fmt.Sprintf("error:%s",n.Term.Value)};switch kind{case rdf.Blank:return n.Term.Value;case rdf.IRI:return text;case rdf.Literal:return fmt.Sprintf("%q",text);default:return fmt.Sprintf("invalid:%s",n.Term.Value)}};func(n foodNode)Attributes()[]encoding.Attribute{_,qual,_,err:=n.Term.Parts();if err!=nil{return []encoding.Attribute{{Key:"error",Value:err.Error()}}};if qual==""{return nil};parts:=strings.Split(qual,":");return []encoding.Attribute{{Key:parts[0],Value:parts[1]}}};type foodLine struct{*rdf.Statement};func(l foodLine)From()graph.Node{return foodNode{l.Subject}};func(l foodLine)To()graph.Node{return foodNode{l.Object}};func(l foodLine)ReversedLine()graph.Line{if l.Predicate.Value=="<tax:is>"{return l};s:=*l.Statement;s.Subject,s.Object=s.Object,s.Subject;switch s.Predicate.Value{case "<eco:eats>":s.Predicate.Value="<eco:eaten-by>";case "<eco:eaten-by>":s.Predicate.Value="<eco:eats>";case "<tax:is-a>":s.Predicate.Value="<tax:includes>";case "<tax:includes>":s.Predicate.Value="<tax:is-a>";default:panic("invalid predicate")};s.Predicate.UID*=-1;return foodLine{&s}};func(l foodLine)Attributes()[]encoding.Attribute{text,_,_,err:=l.Predicate.Parts();if err!=nil{return []encoding.Attribute{{Key:"error",Value:err.Error()}}};parts:=strings.Split(text,":");return []encoding.Attribute{{Key:parts[0],Value:parts[1]}}};func expand(dst,src *multi.DirectedGraph){it:=src.Edges();for it.Next(){lit:=it.Edge().(multi.Edge);for lit.Next(){l:=lit.Line();r:=l.ReversedLine();dst.SetLine(l);if l==r{continue};dst.SetLine(r)}}};func ExampleStatement_ReversedLine(){const statements=`
_:wolf <tax:is-a> _:animal .
_:wolf <tax:is> "Wolf"^^<tax:common> .
_:wolf <tax:is> "Canis lupus"^^<tax:binomial> .
_:wolf <eco:eats> _:sheep .
_:sheep <tax:is-a> _:animal .
_:sheep <tax:is> "Sheep"^^<tax:common> .
_:sheep <tax:is> "Ovis aries"^^<tax:binomial> .
_:sheep <eco:eats> _:grass .
_:grass <tax:is-a> _:plant .
_:grass <tax:is> "Grass"^^<tax:common> .
_:grass <tax:is> "Lolium perenne"^^<tax:binomial> .
_:grass <tax:is> "Festuca rubra"^^<tax:binomial> .
_:grass <tax:is> "Poa pratensis"^^<tax:binomial> .
`;g:=multi.NewDirectedGraph();dec:=rdf.NewDecoder(strings.NewReader(statements));for{l,err:=dec.Unmarshal();if err!=nil{break};g.SetLine(foodLine{l})};h:=multi.NewDirectedGraph();expand(h,g);b,err:=dot.MarshalMulti(h,"food web","","\t");if err!=nil{log.Fatal(err)};fmt.Printf("%s\n\n",b)}