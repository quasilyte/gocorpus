package cookiejar_test;import "fmt";func ExampleNew(){fmt.Println(`After 1st request:
  Flavor: Chocolate Chip
After 2nd request:
  Flavor: Oatmeal Raisin`)}