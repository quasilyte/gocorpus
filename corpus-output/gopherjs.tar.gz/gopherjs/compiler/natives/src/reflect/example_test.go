package reflect_test;import "fmt";func ExampleStructOf(){fmt.Println(`value: &{Height:0.4 Age:2}
json:  {"height":0.4,"age":2}
value: &{Height:1.5 Age:10}`)}