package rls;import("encoding/json";"fmt";"strings";"testing";"time";_"google.golang.org/grpc/balancer/grpclb";_"google.golang.org/grpc/internal/resolver/passthrough");func testEqual(a,b *lbConfig)bool{return a.lookupService==b.lookupService&&a.lookupServiceTimeout==b.lookupServiceTimeout&&a.maxAge==b.maxAge&&a.staleAge==b.staleAge&&a.cacheSizeBytes==b.cacheSizeBytes&&a.defaultTarget==b.defaultTarget&&a.childPolicyName==b.childPolicyName&&a.childPolicyTargetField==b.childPolicyTargetField&&childPolicyConfigEqual(a.childPolicyConfig,b.childPolicyConfig)};func(s)TestParseConfig(t *testing.T){childPolicyTargetFieldVal,_:=json.Marshal(dummyChildPolicyTarget);tests:=[]struct{desc string;input []byte;wantCfg *lbConfig}{{desc:"with transformations 1",input:[]byte(`{
				"top-level-unknown-field": "unknown-value",
				"routeLookupConfig": {
					"unknown-field": "unknown-value",
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": ":///target",
					"maxAge" : "500s",
					"staleAge": "600s",
					"cacheSizeBytes": 100000000,
					"defaultTarget": "passthrough:///default"
				},
				"childPolicy": [
					{"cds_experimental": {"Cluster": "my-fav-cluster"}},
					{"unknown-policy": {"unknown-field": "unknown-value"}},
					{"grpclb": {"childPolicy": [{"pickfirst": {}}]}}
				],
				"childPolicyConfigTargetFieldName": "service_name"
			}`),wantCfg:&lbConfig{lookupService:":///target",lookupServiceTimeout:10*time.Second,maxAge:5*time.Minute,staleAge:time.Duration(0),cacheSizeBytes:maxCacheSize,defaultTarget:"passthrough:///default",childPolicyName:"grpclb",childPolicyTargetField:"service_name",childPolicyConfig:map[string]json.RawMessage{"childPolicy":json.RawMessage(`[{"pickfirst": {}}]`),"service_name":json.RawMessage(childPolicyTargetFieldVal)}}},{desc:"without transformations",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "target",
					"lookupServiceTimeout" : "100s",
					"maxAge": "60s",
					"staleAge" : "50s",
					"cacheSizeBytes": 1000,
					"defaultTarget": "passthrough:///default"
				},
				"childPolicy": [{"grpclb": {"childPolicy": [{"pickfirst": {}}]}}],
				"childPolicyConfigTargetFieldName": "service_name"
			}`),wantCfg:&lbConfig{lookupService:"target",lookupServiceTimeout:100*time.Second,maxAge:60*time.Second,staleAge:50*time.Second,cacheSizeBytes:1000,defaultTarget:"passthrough:///default",childPolicyName:"grpclb",childPolicyTargetField:"service_name",childPolicyConfig:map[string]json.RawMessage{"childPolicy":json.RawMessage(`[{"pickfirst": {}}]`),"service_name":json.RawMessage(childPolicyTargetFieldVal)}}}};builder:=rlsBB{};for _,test:=range tests{t.Run(test.desc,func(t *testing.T){lbCfg,err:=builder.ParseConfig(test.input);if err!=nil||!testEqual(lbCfg.(*lbConfig),test.wantCfg){t.Errorf("ParseConfig(%s) = {%+v, %v}, want {%+v, nil}",string(test.input),lbCfg,err,test.wantCfg)}})}};func(s)TestParseConfigErrors(t *testing.T){tests:=[]struct{desc string;input []byte;wantErr string}{{desc:"empty input",input:nil,wantErr:"rls: json unmarshal failed for service config"},{desc:"bad json",input:[]byte(`bad bad json`),wantErr:"rls: json unmarshal failed for service config"},{desc:"bad grpcKeyBuilder",input:[]byte(`{
					"routeLookupConfig": {
						"grpcKeybuilders": [{
							"names": [{"service": "service", "method": "method"}],
							"headers": [{"key": "k1", "requiredMatch": true, "names": ["v1"]}]
						}]
					}
				}`),wantErr:"rls: GrpcKeyBuilder in RouteLookupConfig has required_match field set"},{desc:"empty lookup service",input:[]byte(`{
					"routeLookupConfig": {
						"grpcKeybuilders": [{
							"names": [{"service": "service", "method": "method"}],
							"headers": [{"key": "k1", "names": ["v1"]}]
						}]
					}
				}`),wantErr:"rls: empty lookup_service in route lookup config"},{desc:"unregistered scheme in lookup service URI",input:[]byte(`{
					"routeLookupConfig": {
						"grpcKeybuilders": [{
							"names": [{"service": "service", "method": "method"}],
							"headers": [{"key": "k1", "names": ["v1"]}]
						}],
						"lookupService": "badScheme:///target"
					}
				}`),wantErr:"rls: unregistered scheme in lookup_service"},{desc:"invalid lookup service timeout",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "315576000001s"
				}
			}`),wantErr:"google.protobuf.Duration value out of range"},{desc:"invalid max age",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"maxAge" : "315576000001s"
				}
			}`),wantErr:"google.protobuf.Duration value out of range"},{desc:"invalid stale age",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"maxAge" : "10s",
					"staleAge" : "315576000001s"
				}
			}`),wantErr:"google.protobuf.Duration value out of range"},{desc:"invalid max age stale age combo",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"staleAge" : "10s"
				}
			}`),wantErr:"rls: stale_age is set, but max_age is not in route lookup config"},{desc:"cache_size_bytes field is not set",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"maxAge": "30s",
					"staleAge" : "25s",
					"defaultTarget": "passthrough:///default"
				},
				"childPolicyConfigTargetFieldName": "service_name"
			}`),wantErr:"rls: cache_size_bytes must be set to a non-zero value"},{desc:"no child policy",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"maxAge": "30s",
					"staleAge" : "25s",
					"cacheSizeBytes": 1000,
					"defaultTarget": "passthrough:///default"
				},
				"childPolicyConfigTargetFieldName": "service_name"
			}`),wantErr:"rls: invalid childPolicy config: no supported policies found"},{desc:"no known child policy",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"maxAge": "30s",
					"staleAge" : "25s",
					"cacheSizeBytes": 1000,
					"defaultTarget": "passthrough:///default"
				},
				"childPolicy": [
					{"cds_experimental": {"Cluster": "my-fav-cluster"}},
					{"unknown-policy": {"unknown-field": "unknown-value"}}
				],
				"childPolicyConfigTargetFieldName": "service_name"
			}`),wantErr:"rls: invalid childPolicy config: no supported policies found"},{desc:"invalid child policy config - more than one entry in map",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"maxAge": "30s",
					"staleAge" : "25s",
					"cacheSizeBytes": 1000,
					"defaultTarget": "passthrough:///default"
				},
				"childPolicy": [
					{
						"cds_experimental": {"Cluster": "my-fav-cluster"},
						"unknown-policy": {"unknown-field": "unknown-value"}
					}
				],
				"childPolicyConfigTargetFieldName": "service_name"
			}`),wantErr:"does not contain exactly 1 policy/config pair"},{desc:"no childPolicyConfigTargetFieldName",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"maxAge": "30s",
					"staleAge" : "25s",
					"cacheSizeBytes": 1000,
					"defaultTarget": "passthrough:///default"
				},
				"childPolicy": [
					{"cds_experimental": {"Cluster": "my-fav-cluster"}},
					{"unknown-policy": {"unknown-field": "unknown-value"}},
					{"grpclb": {}}
				]
			}`),wantErr:"rls: childPolicyConfigTargetFieldName field is not set in service config"},{desc:"child policy config validation failure",input:[]byte(`{
				"routeLookupConfig": {
					"grpcKeybuilders": [{
						"names": [{"service": "service", "method": "method"}],
						"headers": [{"key": "k1", "names": ["v1"]}]
					}],
					"lookupService": "passthrough:///target",
					"lookupServiceTimeout" : "10s",
					"maxAge": "30s",
					"staleAge" : "25s",
					"cacheSizeBytes": 1000,
					"defaultTarget": "passthrough:///default"
				},
				"childPolicy": [
					{"cds_experimental": {"Cluster": "my-fav-cluster"}},
					{"unknown-policy": {"unknown-field": "unknown-value"}},
					{"grpclb": {"childPolicy": "not-an-array"}}
				],
				"childPolicyConfigTargetFieldName": "service_name"
			}`),wantErr:"rls: childPolicy config validation failed"}};builder:=rlsBB{};for _,test:=range tests{t.Run(test.desc,func(t *testing.T){lbCfg,err:=builder.ParseConfig(test.input);if lbCfg!=nil||!strings.Contains(fmt.Sprint(err),test.wantErr){t.Errorf("ParseConfig(%s) = {%+v, %v}, want {nil, %s}",string(test.input),lbCfg,err,test.wantErr)}})}}