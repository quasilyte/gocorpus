package e2e;import("errors";"fmt";"google.golang.org/grpc/balancer";rlspb"google.golang.org/grpc/internal/proto/grpc_lookup_v1";internalserviceconfig"google.golang.org/grpc/internal/serviceconfig";"google.golang.org/grpc/serviceconfig";"google.golang.org/protobuf/encoding/protojson");type RLSConfig struct{RouteLookupConfig *rlspb.RouteLookupConfig;ChildPolicy *internalserviceconfig.BalancerConfig;ChildPolicyConfigTargetFieldName string};func(c *RLSConfig)ServiceConfigJSON()(string,error){m:=protojson.MarshalOptions{Multiline:true,Indent:"  ",UseProtoNames:true};routeLookupCfg,err:=m.Marshal(c.RouteLookupConfig);if err!=nil{return "",err};childPolicy,err:=c.ChildPolicy.MarshalJSON();if err!=nil{return "",err};return fmt.Sprintf(`
{
  "loadBalancingConfig": [
    {
      "rls_experimental": {
        "routeLookupConfig": %s,
        "childPolicy": %s,
        "childPolicyConfigTargetFieldName": %q
      }
    }
  ]
}`,string(routeLookupCfg),string(childPolicy),c.ChildPolicyConfigTargetFieldName),nil};func(c *RLSConfig)LoadBalancingConfig()(serviceconfig.LoadBalancingConfig,error){m:=protojson.MarshalOptions{Multiline:true,Indent:"  ",UseProtoNames:true};routeLookupCfg,err:=m.Marshal(c.RouteLookupConfig);if err!=nil{return nil,err};childPolicy,err:=c.ChildPolicy.MarshalJSON();if err!=nil{return nil,err};lbConfigJSON:=fmt.Sprintf(`
{
  "routeLookupConfig": %s,
  "childPolicy": %s,
  "childPolicyConfigTargetFieldName": %q
}`,string(routeLookupCfg),string(childPolicy),c.ChildPolicyConfigTargetFieldName);builder:=balancer.Get("rls_experimental");if builder==nil{return nil,errors.New("balancer builder not found for RLS LB policy")};parser:=builder.(balancer.ConfigParser);return parser.ParseConfig([]byte(lbConfigJSON))}