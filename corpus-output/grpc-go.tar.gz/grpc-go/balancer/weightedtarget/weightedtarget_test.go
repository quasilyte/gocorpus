package weightedtarget;import("encoding/json";"fmt";"testing";"time";"github.com/google/go-cmp/cmp";"google.golang.org/grpc/attributes";"google.golang.org/grpc/balancer";"google.golang.org/grpc/balancer/roundrobin";"google.golang.org/grpc/connectivity";"google.golang.org/grpc/internal/balancer/stub";"google.golang.org/grpc/internal/balancergroup";"google.golang.org/grpc/internal/grpctest";"google.golang.org/grpc/internal/hierarchy";"google.golang.org/grpc/internal/testutils";"google.golang.org/grpc/resolver";"google.golang.org/grpc/serviceconfig");type s struct{grpctest.Tester};func Test(t *testing.T){grpctest.RunSubTests(t,s{})};type testConfigBalancerBuilder struct{balancer.Builder};func newTestConfigBalancerBuilder()*testConfigBalancerBuilder{return &testConfigBalancerBuilder{Builder:balancer.Get(roundrobin.Name)}};func(t *testConfigBalancerBuilder)Build(cc balancer.ClientConn,opts balancer.BuildOptions)balancer.Balancer{rr:=t.Builder.Build(cc,opts);return &testConfigBalancer{Balancer:rr}};const testConfigBalancerName="test_config_balancer";func(t *testConfigBalancerBuilder)Name()string{return testConfigBalancerName};type stringBalancerConfig struct{serviceconfig.LoadBalancingConfig;configStr string};func(t *testConfigBalancerBuilder)ParseConfig(c json.RawMessage)(serviceconfig.LoadBalancingConfig,error){var cfg string;if err:=json.Unmarshal(c,&cfg);err!=nil{return nil,fmt.Errorf("failed to unmarshal config in %q: %v",testConfigBalancerName,err)};return stringBalancerConfig{configStr:cfg},nil};type testConfigBalancer struct{balancer.Balancer};type configKey struct{};func setConfigKey(addr resolver.Address,config string)resolver.Address{addr.Attributes=addr.Attributes.WithValue(configKey{},config);return addr};func getConfigKey(attr *attributes.Attributes)(string,bool){v:=attr.Value(configKey{});name,ok:=v.(string);return name,ok};func(b *testConfigBalancer)UpdateClientConnState(s balancer.ClientConnState)error{c,ok:=s.BalancerConfig.(stringBalancerConfig);if !ok{return fmt.Errorf("unexpected balancer config with type %T",s.BalancerConfig)};addrsWithAttr:=make([]resolver.Address,len(s.ResolverState.Addresses));for i,addr:=range s.ResolverState.Addresses{addrsWithAttr[i]=setConfigKey(addr,c.configStr)};s.BalancerConfig=nil;s.ResolverState.Addresses=addrsWithAttr;return b.Balancer.UpdateClientConnState(s)};func(b *testConfigBalancer)Close(){b.Balancer.Close()};var(wtbBuilder balancer.Builder;wtbParser balancer.ConfigParser;testBackendAddrStrs []string);const testBackendAddrsCount=12;func init(){balancer.Register(newTestConfigBalancerBuilder());for i:=0;i<testBackendAddrsCount;i++{testBackendAddrStrs=append(testBackendAddrStrs,fmt.Sprintf("%d.%d.%d.%d:%d",i,i,i,i,i))};wtbBuilder=balancer.Get(Name);wtbParser=wtbBuilder.(balancer.ConfigParser);balancergroup.DefaultSubBalancerCloseTimeout=time.Millisecond;NewRandomWRR=testutils.NewTestWRR};func(s)TestWeightedTarget(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config1,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight":1,
      "childPolicy": [{"round_robin": ""}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1],Attributes:nil};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"})}},BalancerConfig:config1});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};verifyAddressInNewSubConn(t,cc,addr1);sc1:=<-cc.NewSubConnCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Ready});p:=<-cc.NewPickerCh;for i:=0;i<5;i++{gotSCSt,_:=p.Pick(balancer.PickInfo{});if !cmp.Equal(gotSCSt.SubConn,sc1,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("picker.Pick, got %v, want SubConn=%v",gotSCSt,sc1)}};config2,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_2": {
       "weight":1,
       "childPolicy": [{"test_config_balancer": "cluster_2"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr2:=resolver.Address{Addr:testBackendAddrStrs[2],Attributes:nil};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr2,[]string{"cluster_2"})}},BalancerConfig:config2});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};verifyAddressInNewSubConn(t,cc,setConfigKey(addr2,"cluster_2"));scRemoved:=<-cc.RemoveSubConnCh;if !cmp.Equal(scRemoved,sc1,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("RemoveSubConn, want %v, got %v",sc1,scRemoved)};wtb.UpdateSubConnState(scRemoved,balancer.SubConnState{ConnectivityState:connectivity.Shutdown});sc2:=<-cc.NewSubConnCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Ready});p=<-cc.NewPickerCh;for i:=0;i<5;i++{gotSCSt,_:=p.Pick(balancer.PickInfo{});if !cmp.Equal(gotSCSt.SubConn,sc2,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("picker.Pick, got %v, want SubConn=%v",gotSCSt,sc2)}};config3,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_2": {
      "weight":1,
      "childPolicy": [{"round_robin": ""}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr3:=resolver.Address{Addr:testBackendAddrStrs[3],Attributes:nil};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr3,[]string{"cluster_2"})}},BalancerConfig:config3});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};verifyAddressInNewSubConn(t,cc,addr3);scRemoved=<-cc.RemoveSubConnCh;if !cmp.Equal(scRemoved,sc2,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("RemoveSubConn, want %v, got %v",sc1,scRemoved)};wtb.UpdateSubConnState(scRemoved,balancer.SubConnState{ConnectivityState:connectivity.Shutdown});sc3:=<-cc.NewSubConnCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Ready});p=<-cc.NewPickerCh;for i:=0;i<5;i++{gotSCSt,_:=p.Pick(balancer.PickInfo{});if !cmp.Equal(gotSCSt.SubConn,sc3,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("picker.Pick, got %v, want SubConn=%v",gotSCSt,sc3)}}};func subConnFromPicker(p balancer.Picker)func()balancer.SubConn{return func()balancer.SubConn{scst,_:=p.Pick(balancer.PickInfo{});return scst.SubConn}};func(s)TestWeightedTarget_OneSubBalancer_AddRemoveBackend(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight":1,
      "childPolicy": [{"round_robin": ""}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};verifyAddressInNewSubConn(t,cc,addr1);sc1:=<-cc.NewSubConnCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Ready});p:=<-cc.NewPickerCh;for i:=0;i<5;i++{gotSCSt,_:=p.Pick(balancer.PickInfo{});if !cmp.Equal(gotSCSt.SubConn,sc1,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("picker.Pick, got %v, want SubConn=%v",gotSCSt,sc1)}};addr2:=resolver.Address{Addr:testBackendAddrStrs[2]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_1"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};verifyAddressInNewSubConn(t,cc,addr2);sc2:=<-cc.NewSubConnCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Ready});p=<-cc.NewPickerCh;want:=[]balancer.SubConn{sc1,sc2};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr2,[]string{"cluster_1"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scRemoved:=<-cc.RemoveSubConnCh;if !cmp.Equal(scRemoved,sc1,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("RemoveSubConn, want %v, got %v",sc1,scRemoved)};wtb.UpdateSubConnState(scRemoved,balancer.SubConnState{ConnectivityState:connectivity.Shutdown});p=<-cc.NewPickerCh;for i:=0;i<5;i++{gotSC,_:=p.Pick(balancer.PickInfo{});if !cmp.Equal(gotSC.SubConn,sc2,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("picker.Pick, got %v, want SubConn=%v",gotSC,sc2)}}};func(s)TestWeightedTarget_TwoSubBalancers_OneBackend(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight":1,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_2": {
      "weight":1,
      "childPolicy": [{"test_config_balancer": "cluster_2"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1]};addr2:=resolver.Address{Addr:testBackendAddrStrs[2]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_2"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scs:=waitForNewSubConns(t,cc,2);verifySubConnAddrs(t,scs,map[string][]resolver.Address{"cluster_1":{addr1},"cluster_2":{addr2}});sc1:=scs["cluster_1"][0].sc;sc2:=scs["cluster_2"][0].sc;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Ready});p:=<-cc.NewPickerCh;want:=[]balancer.SubConn{sc1,sc2};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)}};func(s)TestWeightedTarget_TwoSubBalancers_MoreBackends(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight":1,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_2": {
      "weight":1,
      "childPolicy": [{"test_config_balancer": "cluster_2"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1]};addr2:=resolver.Address{Addr:testBackendAddrStrs[2]};addr3:=resolver.Address{Addr:testBackendAddrStrs[3]};addr4:=resolver.Address{Addr:testBackendAddrStrs[4]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_1"}),hierarchy.Set(addr3,[]string{"cluster_2"}),hierarchy.Set(addr4,[]string{"cluster_2"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scs:=waitForNewSubConns(t,cc,4);verifySubConnAddrs(t,scs,map[string][]resolver.Address{"cluster_1":{addr1,addr2},"cluster_2":{addr3,addr4}});sc1:=scs["cluster_1"][0].sc;sc2:=scs["cluster_1"][1].sc;sc3:=scs["cluster_2"][0].sc;sc4:=scs["cluster_2"][1].sc;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc4,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc4,balancer.SubConnState{ConnectivityState:connectivity.Ready});p:=<-cc.NewPickerCh;want:=[]balancer.SubConn{sc1,sc2,sc3,sc4};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)};wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.TransientFailure});p=<-cc.NewPickerCh;want=[]balancer.SubConn{sc1,sc1,sc3,sc4};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_1"}),hierarchy.Set(addr4,[]string{"cluster_2"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scRemoved:=<-cc.RemoveSubConnCh;if !cmp.Equal(scRemoved,sc3,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("RemoveSubConn, want %v, got %v",sc3,scRemoved)};wtb.UpdateSubConnState(scRemoved,balancer.SubConnState{ConnectivityState:connectivity.Shutdown});p=<-cc.NewPickerCh;want=[]balancer.SubConn{sc1,sc4};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)};wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.TransientFailure});p=<-cc.NewPickerCh;want=[]balancer.SubConn{sc4};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)};wtb.UpdateSubConnState(sc4,balancer.SubConnState{ConnectivityState:connectivity.Connecting});p=<-cc.NewPickerCh;for i:=0;i<5;i++{if _,err:=p.Pick(balancer.PickInfo{});err!=balancer.ErrNoSubConnAvailable{t.Fatalf("want pick error %v, got %v",balancer.ErrNoSubConnAvailable,err)}};wtb.UpdateSubConnState(sc4,balancer.SubConnState{ConnectivityState:connectivity.TransientFailure});p=<-cc.NewPickerCh;for i:=0;i<5;i++{if _,err:=p.Pick(balancer.PickInfo{});err!=balancer.ErrTransientFailure{t.Fatalf("want pick error %v, got %v",balancer.ErrTransientFailure,err)}}};func(s)TestWeightedTarget_TwoSubBalancers_DifferentWeight_MoreBackends(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight": 2,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_2": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_2"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1]};addr2:=resolver.Address{Addr:testBackendAddrStrs[2]};addr3:=resolver.Address{Addr:testBackendAddrStrs[3]};addr4:=resolver.Address{Addr:testBackendAddrStrs[4]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_1"}),hierarchy.Set(addr3,[]string{"cluster_2"}),hierarchy.Set(addr4,[]string{"cluster_2"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scs:=waitForNewSubConns(t,cc,4);verifySubConnAddrs(t,scs,map[string][]resolver.Address{"cluster_1":{addr1,addr2},"cluster_2":{addr3,addr4}});sc1:=scs["cluster_1"][0].sc;sc2:=scs["cluster_1"][1].sc;sc3:=scs["cluster_2"][0].sc;sc4:=scs["cluster_2"][1].sc;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc4,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc4,balancer.SubConnState{ConnectivityState:connectivity.Ready});p:=<-cc.NewPickerCh;want:=[]balancer.SubConn{sc1,sc1,sc2,sc2,sc3,sc4};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)}};func(s)TestWeightedTarget_ThreeSubBalancers_RemoveBalancer(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_2": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_2"}]
    },
    "cluster_3": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_3"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1]};addr2:=resolver.Address{Addr:testBackendAddrStrs[2]};addr3:=resolver.Address{Addr:testBackendAddrStrs[3]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_2"}),hierarchy.Set(addr3,[]string{"cluster_3"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scs:=waitForNewSubConns(t,cc,3);verifySubConnAddrs(t,scs,map[string][]resolver.Address{"cluster_1":{addr1},"cluster_2":{addr2},"cluster_3":{addr3}});sc1:=scs["cluster_1"][0].sc;sc2:=scs["cluster_2"][0].sc;sc3:=scs["cluster_3"][0].sc;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Ready});p:=<-cc.NewPickerCh;want:=[]balancer.SubConn{sc1,sc2,sc3};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)};config,err=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_3": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_3"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr3,[]string{"cluster_3"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};p=<-cc.NewPickerCh;scRemoved:=<-cc.RemoveSubConnCh;if !cmp.Equal(scRemoved,sc2,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("RemoveSubConn, want %v, got %v",sc2,scRemoved)};want=[]balancer.SubConn{sc1,sc3};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)};wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.TransientFailure});<-cc.NewPickerCh;config,err=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_3": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_3"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr3,[]string{"cluster_3"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};p=<-cc.NewPickerCh;scRemoved=<-cc.RemoveSubConnCh;if !cmp.Equal(scRemoved,sc1,cmp.AllowUnexported(testutils.TestSubConn{})){t.Fatalf("RemoveSubConn, want %v, got %v",sc1,scRemoved)};for i:=0;i<5;i++{if _,err:=p.Pick(balancer.PickInfo{});err!=balancer.ErrTransientFailure{t.Fatalf("want pick error %v, got %v",balancer.ErrTransientFailure,err)}}};func(s)TestWeightedTarget_TwoSubBalancers_ChangeWeight_MoreBackends(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight": 2,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_2": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_2"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1]};addr2:=resolver.Address{Addr:testBackendAddrStrs[2]};addr3:=resolver.Address{Addr:testBackendAddrStrs[3]};addr4:=resolver.Address{Addr:testBackendAddrStrs[4]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_1"}),hierarchy.Set(addr3,[]string{"cluster_2"}),hierarchy.Set(addr4,[]string{"cluster_2"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scs:=waitForNewSubConns(t,cc,4);verifySubConnAddrs(t,scs,map[string][]resolver.Address{"cluster_1":{addr1,addr2},"cluster_2":{addr3,addr4}});sc1:=scs["cluster_1"][0].sc;sc2:=scs["cluster_1"][1].sc;sc3:=scs["cluster_2"][0].sc;sc4:=scs["cluster_2"][1].sc;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc3,balancer.SubConnState{ConnectivityState:connectivity.Ready});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc4,balancer.SubConnState{ConnectivityState:connectivity.Connecting});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc4,balancer.SubConnState{ConnectivityState:connectivity.Ready});p:=<-cc.NewPickerCh;want:=[]balancer.SubConn{sc1,sc1,sc2,sc2,sc3,sc4};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)};config,err=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight": 3,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_2": {
      "weight": 1,
      "childPolicy": [{"test_config_balancer": "cluster_2"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_1"}),hierarchy.Set(addr3,[]string{"cluster_2"}),hierarchy.Set(addr4,[]string{"cluster_2"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};p=<-cc.NewPickerCh;want=[]balancer.SubConn{sc1,sc1,sc1,sc2,sc2,sc2,sc3,sc4};if err:=testutils.IsRoundRobin(want,subConnFromPicker(p));err!=nil{t.Fatalf("want %v, got %v",want,err)}};func(s)TestWeightedTarget_InitOneSubBalancerTransientFailure(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight":1,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_2": {
      "weight":1,
      "childPolicy": [{"test_config_balancer": "cluster_2"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1]};addr2:=resolver.Address{Addr:testBackendAddrStrs[2]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_2"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scs:=waitForNewSubConns(t,cc,2);verifySubConnAddrs(t,scs,map[string][]resolver.Address{"cluster_1":{addr1},"cluster_2":{addr2}});sc1:=scs["cluster_1"][0].sc;_=scs["cluster_2"][0].sc;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.TransientFailure});p:=<-cc.NewPickerCh;for i:=0;i<5;i++{r,err:=p.Pick(balancer.PickInfo{});if err!=balancer.ErrNoSubConnAvailable{t.Fatalf("want pick to fail with %v, got result %v, err %v",balancer.ErrNoSubConnAvailable,r,err)}}};func(s)TestBalancerGroup_SubBalancerTurnsConnectingFromTransientFailure(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight":1,
      "childPolicy": [{"test_config_balancer": "cluster_1"}]
    },
    "cluster_2": {
      "weight":1,
      "childPolicy": [{"test_config_balancer": "cluster_2"}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addr1:=resolver.Address{Addr:testBackendAddrStrs[1]};addr2:=resolver.Address{Addr:testBackendAddrStrs[2]};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addr1,[]string{"cluster_1"}),hierarchy.Set(addr2,[]string{"cluster_2"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};scs:=waitForNewSubConns(t,cc,2);verifySubConnAddrs(t,scs,map[string][]resolver.Address{"cluster_1":{addr1},"cluster_2":{addr2}});sc1:=scs["cluster_1"][0].sc;sc2:=scs["cluster_2"][0].sc;wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.TransientFailure});<-cc.NewPickerCh;wtb.UpdateSubConnState(sc2,balancer.SubConnState{ConnectivityState:connectivity.TransientFailure});p:=<-cc.NewPickerCh;for i:=0;i<5;i++{r,err:=p.Pick(balancer.PickInfo{});if err!=balancer.ErrTransientFailure{t.Fatalf("want pick to fail with %v, got result %v, err %v",balancer.ErrTransientFailure,r,err)}};wtb.UpdateSubConnState(sc1,balancer.SubConnState{ConnectivityState:connectivity.Connecting});select{case <-time.After(100*time.Millisecond):;case <-cc.NewPickerCh:t.Fatal("received new picker from the LB policy when expecting none")};for i:=0;i<5;i++{r,err:=p.Pick(balancer.PickInfo{});if err!=balancer.ErrTransientFailure{t.Fatalf("want pick to fail with %v, got result %v, err %v",balancer.ErrTransientFailure,r,err)}}};func verifyAddressInNewSubConn(t *testing.T,cc *testutils.TestClientConn,addr resolver.Address){t.Helper();gotAddr:=<-cc.NewSubConnAddrsCh;wantAddr:=[]resolver.Address{hierarchy.Set(addr,[]string{})};if diff:=cmp.Diff(gotAddr,wantAddr,cmp.AllowUnexported(attributes.Attributes{}));diff!=""{t.Fatalf("got unexpected new subconn addrs: %v",diff)}};type subConnWithAddr struct{sc balancer.SubConn;addr resolver.Address};func waitForNewSubConns(t *testing.T,cc *testutils.TestClientConn,num int)map[string][]subConnWithAddr{t.Helper();scs:=make(map[string][]subConnWithAddr);for i:=0;i<num;i++{addrs:=<-cc.NewSubConnAddrsCh;if len(addrs)!=1{t.Fatalf("received subConns with %d addresses, want 1",len(addrs))};cfg,ok:=getConfigKey(addrs[0].Attributes);if !ok{t.Fatalf("received subConn address %v contains no attribute for balancer config",addrs[0])};sc:=<-cc.NewSubConnCh;scWithAddr:=subConnWithAddr{sc:sc,addr:addrs[0]};scs[cfg]=append(scs[cfg],scWithAddr)};return scs};func verifySubConnAddrs(t *testing.T,scs map[string][]subConnWithAddr,wantSubConnAddrs map[string][]resolver.Address){t.Helper();if len(scs)!=len(wantSubConnAddrs){t.Fatalf("got new subConns %+v, want %v",scs,wantSubConnAddrs)};for cfg,scsWithAddr:=range scs{if len(scsWithAddr)!=len(wantSubConnAddrs[cfg]){t.Fatalf("got new subConns %+v, want %v",scs,wantSubConnAddrs)};wantAddrs:=wantSubConnAddrs[cfg];for i,scWithAddr:=range scsWithAddr{if diff:=cmp.Diff(wantAddrs[i].Addr,scWithAddr.addr.Addr);diff!=""{t.Fatalf("got unexpected new subconn addrs: %v",diff)}}}};const initIdleBalancerName="test-init-Idle-balancer";var errTestInitIdle=fmt.Errorf("init Idle balancer error 0");func init(){stub.Register(initIdleBalancerName,stub.BalancerFuncs{UpdateClientConnState:func(bd *stub.BalancerData,opts balancer.ClientConnState)error{bd.ClientConn.NewSubConn(opts.ResolverState.Addresses,balancer.NewSubConnOptions{});return nil},UpdateSubConnState:func(bd *stub.BalancerData,sc balancer.SubConn,state balancer.SubConnState){err:=fmt.Errorf("wrong picker error");if state.ConnectivityState==connectivity.Idle{err=errTestInitIdle};bd.ClientConn.UpdateState(balancer.State{ConnectivityState:state.ConnectivityState,Picker:&testutils.TestConstPicker{Err:err}})}})};func(s)TestInitialIdle(t *testing.T){cc:=testutils.NewTestClientConn(t);wtb:=wtbBuilder.Build(cc,balancer.BuildOptions{});defer wtb.Close();config,err:=wtbParser.ParseConfig([]byte(`
{
  "targets": {
    "cluster_1": {
      "weight":1,
      "childPolicy": [{"test-init-Idle-balancer": ""}]
    }
  }
}`));if err!=nil{t.Fatalf("failed to parse balancer config: %v",err)};addrs:=[]resolver.Address{{Addr:testBackendAddrStrs[0],Attributes:nil}};if err:=wtb.UpdateClientConnState(balancer.ClientConnState{ResolverState:resolver.State{Addresses:[]resolver.Address{hierarchy.Set(addrs[0],[]string{"cds:cluster_1"})}},BalancerConfig:config});err!=nil{t.Fatalf("failed to update ClientConn state: %v",err)};for range addrs{sc:=<-cc.NewSubConnCh;wtb.UpdateSubConnState(sc,balancer.SubConnState{ConnectivityState:connectivity.Idle})};if state:=<-cc.NewStateCh;state!=connectivity.Idle{t.Fatalf("Received aggregated state: %v, want Idle",state)}}