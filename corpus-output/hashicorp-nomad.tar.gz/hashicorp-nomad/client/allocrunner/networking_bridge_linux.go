package allocrunner;import("context";"fmt";"github.com/coreos/go-iptables/iptables";hclog"github.com/hashicorp/go-hclog";"github.com/hashicorp/nomad/nomad/structs";"github.com/hashicorp/nomad/plugins/drivers");const(defaultNomadBridgeName="nomad";bridgeNetworkAllocIfPrefix="eth";defaultNomadAllocSubnet="172.26.64.0/20";cniAdminChainName="NOMAD-ADMIN");type bridgeNetworkConfigurator struct{cni *cniNetworkConfigurator;allocSubnet string;bridgeName string;logger hclog.Logger};func newBridgeNetworkConfigurator(log hclog.Logger,bridgeName,ipRange,cniPath string,ignorePortMappingHostIP bool)(*bridgeNetworkConfigurator,error){b:=&bridgeNetworkConfigurator{bridgeName:bridgeName,allocSubnet:ipRange,logger:log};if b.bridgeName==""{b.bridgeName=defaultNomadBridgeName};if b.allocSubnet==""{b.allocSubnet=defaultNomadAllocSubnet};c,err:=newCNINetworkConfiguratorWithConf(log,cniPath,bridgeNetworkAllocIfPrefix,ignorePortMappingHostIP,buildNomadBridgeNetConfig(b.bridgeName,b.allocSubnet));if err!=nil{return nil,err};b.cni=c;return b,nil};func(b *bridgeNetworkConfigurator)ensureForwardingRules()error{ipt,err:=iptables.New();if err!=nil{return err};if err=ensureChain(ipt,"filter",cniAdminChainName);err!=nil{return err};if err:=appendChainRule(ipt,cniAdminChainName,b.generateAdminChainRule());err!=nil{return err};return nil};func ensureChain(ipt *iptables.IPTables,table,chain string)error{chains,err:=ipt.ListChains(table);if err!=nil{return fmt.Errorf("failed to list iptables chains: %v",err)};for _,ch:=range chains{if ch==chain{return nil}};err=ipt.NewChain(table,chain);if e,ok:=err.(*iptables.Error);ok&&e.ExitStatus()==1{return nil};return err};func appendChainRule(ipt *iptables.IPTables,chain string,rule []string)error{exists,err:=ipt.Exists("filter",chain,rule...);if !exists&&err==nil{err=ipt.Append("filter",chain,rule...)};return err};func(b *bridgeNetworkConfigurator)generateAdminChainRule()[]string{return []string{"-o",b.bridgeName,"-d",b.allocSubnet,"-j","ACCEPT"}};func(b *bridgeNetworkConfigurator)Setup(ctx context.Context,alloc *structs.Allocation,spec *drivers.NetworkIsolationSpec)(*structs.AllocNetworkStatus,error){if err:=b.ensureForwardingRules();err!=nil{return nil,fmt.Errorf("failed to initialize table forwarding rules: %v",err)};return b.cni.Setup(ctx,alloc,spec)};func(b *bridgeNetworkConfigurator)Teardown(ctx context.Context,alloc *structs.Allocation,spec *drivers.NetworkIsolationSpec)error{return b.cni.Teardown(ctx,alloc,spec)};func buildNomadBridgeNetConfig(bridgeName,subnet string)[]byte{return []byte(fmt.Sprintf(nomadCNIConfigTemplate,bridgeName,subnet,cniAdminChainName))};const nomadCNIConfigTemplate=`{
	"cniVersion": "0.4.0",
	"name": "nomad",
	"plugins": [
		{
			"type": "bridge",
			"bridge": "%s",
			"ipMasq": true,
			"isGateway": true,
			"forceAddress": true,
			"ipam": {
				"type": "host-local",
				"ranges": [
					[
						{
							"subnet": "%s"
						}
					]
				],
				"routes": [
					{ "dst": "0.0.0.0/0" }
				]
			}
		},
		{
			"type": "firewall",
			"backend": "iptables",
			"iptablesAdminChainName": "%s"
		},
		{
			"type": "portmap",
			"capabilities": {"portMappings": true},
			"snat": true
		}
	]
}
`