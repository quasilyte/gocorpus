package command;import("fmt";"strings";"github.com/hashicorp/terraform/internal/backend";"github.com/hashicorp/terraform/internal/command/arguments";"github.com/hashicorp/terraform/internal/command/views";"github.com/hashicorp/terraform/internal/plans/planfile";"github.com/hashicorp/terraform/internal/tfdiags");type ApplyCommand struct{Meta;Destroy bool};func(c *ApplyCommand)Run(rawArgs []string)int{var diags tfdiags.Diagnostics;common,rawArgs:=arguments.ParseView(rawArgs);c.View.Configure(common);c.Meta.color=!common.NoColor;c.Meta.Color=c.Meta.color;var args *arguments.Apply;switch{case c.Destroy:args,diags=arguments.ParseApplyDestroy(rawArgs);default:args,diags=arguments.ParseApply(rawArgs)};view:=views.NewApply(args.ViewType,c.Destroy,c.View);if diags.HasErrors(){view.Diagnostics(diags);view.HelpPrompt();return 1};var err error;if c.pluginPath,err=c.loadPluginPath();err!=nil{diags=diags.Append(err);view.Diagnostics(diags);return 1};planFile,diags:=c.LoadPlanFile(args.PlanPath);if diags.HasErrors(){view.Diagnostics(diags);return 1};if planFile!=nil&&!args.Vars.Empty(){diags=diags.Append(tfdiags.Sourceless(tfdiags.Error,"Can't set variables when applying a saved plan","The -var and -var-file options cannot be used when applying a saved plan file, because a saved plan includes the variable values that were set when it was created."));view.Diagnostics(diags);return 1};c.Meta.input=args.InputEnabled;c.Meta.parallelism=args.Operation.Parallelism;be,beDiags:=c.PrepareBackend(planFile,args.State);diags=diags.Append(beDiags);if diags.HasErrors(){view.Diagnostics(diags);return 1};opReq,opDiags:=c.OperationRequest(be,view,planFile,args.Operation,args.AutoApprove);diags=diags.Append(opDiags);diags=diags.Append(c.GatherVariables(opReq,args.Vars));view.Diagnostics(diags);if diags.HasErrors(){return 1};diags=nil;op,err:=c.RunOperation(be,opReq);if err!=nil{diags=diags.Append(err);view.Diagnostics(diags);return 1};if op.Result!=backend.OperationSuccess{return op.Result.ExitStatus()};if rb,isRemoteBackend:=be.(BackendWithRemoteTerraformVersion);!isRemoteBackend||rb.IsLocalOperations(){view.ResourceCount(args.State.StateOutPath);if !c.Destroy&&op.State!=nil{view.Outputs(op.State.RootModule().OutputValues)}};view.Diagnostics(diags);if diags.HasErrors(){return 1};return 0};func(c *ApplyCommand)LoadPlanFile(path string)(*planfile.Reader,tfdiags.Diagnostics){var planFile *planfile.Reader;var diags tfdiags.Diagnostics;if path!=""{var err error;planFile,err=c.PlanFile(path);if err!=nil{diags=diags.Append(tfdiags.Sourceless(tfdiags.Error,fmt.Sprintf("Failed to load %q as a plan file",path),fmt.Sprintf("Error: %s",err)));return nil,diags};if planFile==nil{diags=diags.Append(tfdiags.Sourceless(tfdiags.Error,fmt.Sprintf("Failed to load %q as a plan file",path),"The specified path is a directory, not a plan file. You can use the global -chdir flag to use this directory as the configuration root."));return nil,diags};if c.Destroy{diags=diags.Append(tfdiags.Sourceless(tfdiags.Error,"Destroy can't be called with a plan file",fmt.Sprintf("If this plan was created using plan -destroy, apply it using:\n  terraform apply %q",path)));return nil,diags}};return planFile,diags};func(c *ApplyCommand)PrepareBackend(planFile *planfile.Reader,args *arguments.State)(backend.Enhanced,tfdiags.Diagnostics){var diags tfdiags.Diagnostics;c.Meta.applyStateArguments(args);var be backend.Enhanced;var beDiags tfdiags.Diagnostics;if planFile==nil{backendConfig,configDiags:=c.loadBackendConfig(".");diags=diags.Append(configDiags);if configDiags.HasErrors(){return nil,diags};be,beDiags=c.Backend(&BackendOpts{Config:backendConfig})}else{plan,err:=planFile.ReadPlan();if err!=nil{diags=diags.Append(tfdiags.Sourceless(tfdiags.Error,"Failed to read plan from plan file",fmt.Sprintf("Cannot read the plan from the given plan file: %s.",err)));return nil,diags};if plan.Backend.Config==nil{diags=diags.Append(tfdiags.Sourceless(tfdiags.Error,"Failed to read plan from plan file","The given plan file does not have a valid backend configuration. This is a bug in the Terraform command that generated this plan file."));return nil,diags};be,beDiags=c.BackendForPlan(plan.Backend)};diags=diags.Append(beDiags);if beDiags.HasErrors(){return nil,diags};return be,diags};func(c *ApplyCommand)OperationRequest(be backend.Enhanced,view views.Apply,planFile *planfile.Reader,args *arguments.Operation,autoApprove bool)(*backend.Operation,tfdiags.Diagnostics){var diags tfdiags.Diagnostics;diags=diags.Append(c.providerDevOverrideRuntimeWarnings());opReq:=c.Operation(be);opReq.AutoApprove=autoApprove;opReq.ConfigDir=".";opReq.PlanMode=args.PlanMode;opReq.Hooks=view.Hooks();opReq.PlanFile=planFile;opReq.PlanRefresh=args.Refresh;opReq.Targets=args.Targets;opReq.ForceReplace=args.ForceReplace;opReq.Type=backend.OperationTypeApply;opReq.View=view.Operation();var err error;opReq.ConfigLoader,err=c.initConfigLoader();if err!=nil{diags=diags.Append(fmt.Errorf("Failed to initialize config loader: %s",err));return nil,diags};return opReq,diags};func(c *ApplyCommand)GatherVariables(opReq *backend.Operation,args *arguments.Vars)tfdiags.Diagnostics{var diags tfdiags.Diagnostics;varArgs:=args.All();items:=make([]rawFlag,len(varArgs));for i:=range varArgs{items[i].Name=varArgs[i].Name;items[i].Value=varArgs[i].Value};c.Meta.variableArgs=rawFlags{items:&items};opReq.Variables,diags=c.collectVariableValues();return diags};func(c *ApplyCommand)Help()string{if c.Destroy{return c.helpDestroy()};return c.helpApply()};func(c *ApplyCommand)Synopsis()string{if c.Destroy{return "Destroy previously-created infrastructure"};return "Create or update infrastructure"};func(c *ApplyCommand)helpApply()string{helpText:=`
Usage: terraform [global options] apply [options] [PLAN]

  Creates or updates infrastructure according to Terraform configuration
  files in the current directory.

  By default, Terraform will generate a new plan and present it for your
  approval before taking any action. You can optionally provide a plan
  file created by a previous call to "terraform plan", in which case
  Terraform will take the actions described in that plan without any
  confirmation prompt.

Options:

  -auto-approve          Skip interactive approval of plan before applying.

  -backup=path           Path to backup the existing state file before
                         modifying. Defaults to the "-state-out" path with
                         ".backup" extension. Set to "-" to disable backup.

  -compact-warnings      If Terraform produces any warnings that are not
                         accompanied by errors, show them in a more compact
                         form that includes only the summary messages.

  -lock=false            Don't hold a state lock during the operation. This is
                         dangerous if others might concurrently run commands
                         against the same workspace.

  -lock-timeout=0s       Duration to retry a state lock.

  -input=true            Ask for input for variables if not directly set.

  -no-color              If specified, output won't contain any color.

  -parallelism=n         Limit the number of parallel resource operations.
                         Defaults to 10.

  -state=path            Path to read and save state (unless state-out
                         is specified). Defaults to "terraform.tfstate".

  -state-out=path        Path to write state to that is different than
                         "-state". This can be used to preserve the old
                         state.

  If you don't provide a saved plan file then this command will also accept
  all of the plan-customization options accepted by the terraform plan command.
  For more information on those options, run:
      terraform plan -help
`;return strings.TrimSpace(helpText)};func(c *ApplyCommand)helpDestroy()string{helpText:=`
Usage: terraform [global options] destroy [options]

  Destroy Terraform-managed infrastructure.

  This command is a convenience alias for:
      terraform apply -destroy

  This command also accepts many of the plan-customization options accepted by
  the terraform plan command. For more information on those options, run:
      terraform plan -help
`;return strings.TrimSpace(helpText)}