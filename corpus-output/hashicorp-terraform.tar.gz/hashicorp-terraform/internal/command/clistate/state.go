package clistate;import("context";"fmt";"sync";"time";"github.com/hashicorp/terraform/internal/command/views";"github.com/hashicorp/terraform/internal/helper/slowmessage";"github.com/hashicorp/terraform/internal/states/statemgr";"github.com/hashicorp/terraform/internal/tfdiags");const(LockThreshold=400*time.Millisecond;LockErrorMessage=`Error message: %s

Terraform acquires a state lock to protect the state from being written
by multiple users at the same time. Please resolve the issue above and try
again. For most commands, you can disable locking with the "-lock=false"
flag, but this is not recommended.`;UnlockErrorMessage=`Error message: %s

Terraform acquires a lock when accessing your state to prevent others
running Terraform to potentially modify the state at the same time. An
error occurred while releasing this lock. This could mean that the lock
did or did not release properly. If the lock didn't release properly,
Terraform may not be able to run future commands since it'll appear as if
the lock is held.

In this scenario, please call the "force-unlock" command to unlock the
state manually. This is a very dangerous operation since if it is done
erroneously it could result in two people modifying state at the same time.
Only call this command if you're certain that the unlock above failed and
that no one else is holding a lock.`);type Locker interface{WithContext(ctx context.Context)Locker;Lock(s statemgr.Locker,reason string)tfdiags.Diagnostics;Unlock()tfdiags.Diagnostics;Timeout()time.Duration};type locker struct{mu sync.Mutex;ctx context.Context;timeout time.Duration;state statemgr.Locker;view views.StateLocker;lockID string};var _ Locker=(*locker)(nil);func NewLocker(timeout time.Duration,view views.StateLocker)Locker{return &locker{ctx:context.Background(),timeout:timeout,view:view}};func(l *locker)WithContext(ctx context.Context)Locker{if ctx==nil{panic("nil context")};return &locker{ctx:ctx,timeout:l.timeout,view:l.view}};func(l *locker)Lock(s statemgr.Locker,reason string)tfdiags.Diagnostics{var diags tfdiags.Diagnostics;l.mu.Lock();defer l.mu.Unlock();l.state=s;ctx,cancel:=context.WithTimeout(l.ctx,l.timeout);defer cancel();lockInfo:=statemgr.NewLockInfo();lockInfo.Operation=reason;err:=slowmessage.Do(LockThreshold,func()error{id,err:=statemgr.LockWithContext(ctx,s,lockInfo);l.lockID=id;return err},l.view.Locking);if err!=nil{diags=diags.Append(tfdiags.Sourceless(tfdiags.Error,"Error acquiring the state lock",fmt.Sprintf(LockErrorMessage,err)))};return diags};func(l *locker)Unlock()tfdiags.Diagnostics{var diags tfdiags.Diagnostics;l.mu.Lock();defer l.mu.Unlock();if l.lockID==""{return diags};err:=slowmessage.Do(LockThreshold,func()error{return l.state.Unlock(l.lockID)},l.view.Unlocking);if err!=nil{diags=diags.Append(tfdiags.Sourceless(tfdiags.Error,"Error releasing the state lock",fmt.Sprintf(UnlockErrorMessage,err)))};return diags};func(l *locker)Timeout()time.Duration{return l.timeout};type noopLocker struct{};func NewNoopLocker()Locker{return noopLocker{}};var _ Locker=noopLocker{};func(l noopLocker)WithContext(ctx context.Context)Locker{return l};func(l noopLocker)Lock(statemgr.Locker,string)tfdiags.Diagnostics{return nil};func(l noopLocker)Unlock()tfdiags.Diagnostics{return nil};func(l noopLocker)Timeout()time.Duration{return 0}