package command;import("fmt";"os";"runtime");var test bool=false;const DefaultDataDir=".terraform";const PluginPathFile="plugin_path";const pluginMachineName=runtime.GOOS+"_"+runtime.GOARCH;const DefaultPluginVendorDir="terraform.d/plugins/"+pluginMachineName;const DefaultStateFilename="terraform.tfstate";const DefaultVarsFilename="terraform.tfvars";const DefaultBackupExtension=".backup";const DefaultParallelism=10;const ErrUnsupportedLocalOp=`The configured backend doesn't support this operation.

The "backend" in Terraform defines how Terraform operates. The default
backend performs all operations locally on your machine. Your configuration
is configured to use a non-local backend. This backend doesn't support this
operation.
`;func ModulePath(args []string)(string,error){if len(args)>0{return "",fmt.Errorf("Too many command line arguments. Did you mean to use -chdir?")};path,err:=os.Getwd();if err!=nil{return "",fmt.Errorf("Error getting pwd: %s",err)};return path,nil}