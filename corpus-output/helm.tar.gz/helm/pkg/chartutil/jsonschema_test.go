package chartutil;import("io/ioutil";"testing";"helm.sh/helm/v3/pkg/chart");func TestValidateAgainstSingleSchema(t *testing.T){values,err:=ReadValuesFile("./testdata/test-values.yaml");if err!=nil{t.Fatalf("Error reading YAML file: %s",err)};schema,err:=ioutil.ReadFile("./testdata/test-values.schema.json");if err!=nil{t.Fatalf("Error reading YAML file: %s",err)};if err:=ValidateAgainstSingleSchema(values,schema);err!=nil{t.Errorf("Error validating Values against Schema: %s",err)}};func TestValidateAgainstSingleSchemaNegative(t *testing.T){values,err:=ReadValuesFile("./testdata/test-values-negative.yaml");if err!=nil{t.Fatalf("Error reading YAML file: %s",err)};schema,err:=ioutil.ReadFile("./testdata/test-values.schema.json");if err!=nil{t.Fatalf("Error reading YAML file: %s",err)};var errString string;if err:=ValidateAgainstSingleSchema(values,schema);err==nil{t.Fatalf("Expected an error, but got nil")};expectedErrString:=`- (root): employmentInfo is required
- age: Must be greater than or equal to 0
`;if errString!=expectedErrString{t.Errorf("Error string :\n`%s`\ndoes not match expected\n`%s`",errString,expectedErrString)}};const subchartSchema=`{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Values",
  "type": "object",
  "properties": {
    "age": {
      "description": "Age",
      "minimum": 0,
      "type": "integer"
    }
  },
  "required": [
    "age"
  ]
}
`;func TestValidateAgainstSchema(t *testing.T){subchartJSON:=[]byte(subchartSchema);subchart:=&chart.Chart{Metadata:&chart.Metadata{Name:"subchart"},Schema:subchartJSON};chrt:=&chart.Chart{Metadata:&chart.Metadata{Name:"chrt"}};chrt.AddDependency(subchart);vals:=map[string]interface{}{"name":"John","subchart":map[string]interface{}{"age":25}};if err:=ValidateAgainstSchema(chrt,vals);err!=nil{t.Errorf("Error validating Values against Schema: %s",err)}};func TestValidateAgainstSchemaNegative(t *testing.T){subchartJSON:=[]byte(subchartSchema);subchart:=&chart.Chart{Metadata:&chart.Metadata{Name:"subchart"},Schema:subchartJSON};chrt:=&chart.Chart{Metadata:&chart.Metadata{Name:"chrt"}};chrt.AddDependency(subchart);vals:=map[string]interface{}{"name":"John","subchart":map[string]interface{}{}};var errString string;if err:=ValidateAgainstSchema(chrt,vals);err==nil{t.Fatalf("Expected an error, but got nil")};expectedErrString:=`subchart:
- (root): age is required
`;if errString!=expectedErrString{t.Errorf("Error string :\n`%s`\ndoes not match expected\n`%s`",errString,expectedErrString)}}