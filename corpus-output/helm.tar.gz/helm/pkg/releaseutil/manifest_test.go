package releaseutil;import("reflect";"testing");const mockManifestFile=`

---
apiVersion: v1
kind: Pod
metadata:
  name: finding-nemo,
  annotations:
    "helm.sh/hook": test
spec:
  containers:
  - name: nemo-test
    image: fake-image
    cmd: fake-command
`;const expectedManifest=`apiVersion: v1
kind: Pod
metadata:
  name: finding-nemo,
  annotations:
    "helm.sh/hook": test
spec:
  containers:
  - name: nemo-test
    image: fake-image
    cmd: fake-command`;func TestSplitManifest(t *testing.T){manifests:=SplitManifests(mockManifestFile);if len(manifests)!=1{t.Errorf("Expected 1 manifest, got %v",len(manifests))};expected:=map[string]string{"manifest-0":expectedManifest};if !reflect.DeepEqual(manifests,expected){t.Errorf("Expected %v, got %v",expected,manifests)}}