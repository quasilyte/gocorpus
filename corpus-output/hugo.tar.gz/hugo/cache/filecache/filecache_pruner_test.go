package filecache;import("fmt";"testing";"time";"github.com/spf13/afero";qt"github.com/frankban/quicktest");func TestPrune(t *testing.T){t.Parallel();c:=qt.New(t);configStr:=`
resourceDir = "myresources"
contentDir = "content"
dataDir = "data"
i18nDir = "i18n"
layoutDir = "layouts"
assetDir = "assets"
archeTypedir = "archetypes"

[caches]
[caches.getjson]
maxAge = "200ms"
dir = "/cache/c"
[caches.getcsv]
maxAge = "200ms"
dir = "/cache/d"
[caches.assets]
maxAge = "200ms"
dir = ":resourceDir/_gen"
[caches.images]
maxAge = "200ms"
dir = ":resourceDir/_gen"
`;for _,name:=range []string{cacheKeyGetCSV,cacheKeyGetJSON,cacheKeyAssets,cacheKeyImages}{msg:=qt.Commentf("cache: %s",name);p:=newPathsSpec(t,afero.NewMemMapFs(),configStr);caches,err:=NewCaches(p);c.Assert(err,qt.IsNil);cache:=caches[name];for i:=0;i<10;i++{id:=fmt.Sprintf("i%d",i);cache.GetOrCreateBytes(id,func()([]byte,error){return []byte("abc"),nil});if i==4{time.Sleep(201*time.Millisecond)}};count,err:=caches.Prune();c.Assert(err,qt.IsNil);c.Assert(count,qt.Equals,5,msg);for i:=0;i<10;i++{id:=fmt.Sprintf("i%d",i);v:=cache.getString(id);if i<5{c.Assert(v,qt.Equals,"")}};caches,err=NewCaches(p);c.Assert(err,qt.IsNil);cache=caches[name];cache.GetOrCreateBytes("i5",func()([]byte,error){return []byte("abc"),nil});count,err=caches.Prune();c.Assert(err,qt.IsNil);c.Assert(count,qt.Equals,4);for i:=0;i<10;i++{id:=fmt.Sprintf("i%d",i);v:=cache.getString(id);if i!=5{c.Assert(v,qt.Equals,"")}}}}