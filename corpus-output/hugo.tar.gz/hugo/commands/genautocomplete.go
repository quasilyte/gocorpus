package commands;import("io";"os";"github.com/spf13/cobra";jww"github.com/spf13/jwalterweatherman");var _ cmder=(*genautocompleteCmd)(nil);type genautocompleteCmd struct{autocompleteTarget string;autocompleteType string;*baseCmd};func newGenautocompleteCmd()*genautocompleteCmd{cc:=&genautocompleteCmd{};cc.baseCmd=newBaseCmd(&cobra.Command{Use:"autocomplete",Short:"Generate shell autocompletion script for Hugo",Long:`Generates a shell autocompletion script for Hugo.

The script is written to the console (stdout).

To write to file, add the `+"`--completionfile=/path/to/file`"+` flag.

Add `+"`--type={bash, zsh, fish or powershell}`"+` flag to set alternative
shell type.

Logout and in again to reload the completion scripts,
or just source them in directly:

	$ . /etc/bash_completion or /path/to/file`,RunE:func(cmd *cobra.Command,args []string)error{var err error;var target io.Writer;if cc.autocompleteTarget==""{target=os.Stdout};switch cc.autocompleteType{case "bash":err=cmd.Root().GenBashCompletion(target);case "zsh":err=cmd.Root().GenZshCompletion(target);case "fish":err=cmd.Root().GenFishCompletion(target,true);case "powershell":err=cmd.Root().GenPowerShellCompletion(target);default:return newUserError("Unsupported completion type")};if err!=nil{return err};if cc.autocompleteTarget!=""{jww.FEEDBACK.Println(cc.autocompleteType+" completion file for Hugo saved to",cc.autocompleteTarget)};return nil}});cc.cmd.PersistentFlags().StringVarP(&cc.autocompleteTarget,"completionfile","f","","autocompletion file, defaults to stdout");cc.cmd.PersistentFlags().StringVarP(&cc.autocompleteType,"type","t","bash","autocompletion type (bash, zsh, fish, or powershell)");return cc}