package commands;import("testing";qt"github.com/frankban/quicktest");func TestHugoWithContentDirOverride(t *testing.T){c:=qt.New(t);hugoCmd:=newCommandsBuilder().addAll().build();cmd:=hugoCmd.getCommand();contentDir:="contentOverride";cfgStr:=`

baseURL = "https://example.org"
title = "Hugo Commands"

contentDir = "thisdoesnotexist"

`;dir,clean,err:=createSimpleTestSite(t,testSiteConfig{configTOML:cfgStr,contentDir:contentDir});c.Assert(err,qt.IsNil);defer clean();cmd.SetArgs([]string{"-s="+dir,"-c="+contentDir});_,err=cmd.ExecuteC();c.Assert(err,qt.IsNil)}