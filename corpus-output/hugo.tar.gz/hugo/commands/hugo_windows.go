package commands;import(_"time/tzdata";"github.com/spf13/cobra");func init(){cobra.MousetrapHelpText=`

  Hugo is a command-line tool for generating static website.

  You need to open cmd.exe and run Hugo from there.
  
  Visit https://gohugo.io/ for more information.`}