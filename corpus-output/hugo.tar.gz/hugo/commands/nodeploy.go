package commands;import("errors";"github.com/spf13/cobra");var _ cmder=(*deployCmd)(nil);type deployCmd struct{*baseBuilderCmd};func(b *commandsBuilder)newDeployCmd()*deployCmd{cc:=&deployCmd{};cmd:=&cobra.Command{Use:"deploy",Short:"Deploy your site to a Cloud provider.",Long:`Deploy your site to a Cloud provider.

See https://gohugo.io/hosting-and-deployment/hugo-deploy/ for detailed
documentation.
`,RunE:func(cmd *cobra.Command,args []string)error{return errors.New("build without HUGO_BUILD_TAGS=nodeploy to use this command")}};cc.baseBuilderCmd=b.newBuilderBasicCmd(cmd);return cc}