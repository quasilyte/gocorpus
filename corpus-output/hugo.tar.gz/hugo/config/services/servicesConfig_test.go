package services;import("testing";qt"github.com/frankban/quicktest";"github.com/gohugoio/hugo/config");func TestDecodeConfigFromTOML(t *testing.T){c:=qt.New(t);tomlConfig:=`

someOtherValue = "foo"

[services]
[services.disqus]
shortname = "DS"
[services.googleAnalytics]
id = "ga_id"
[services.instagram]
disableInlineCSS = true
[services.twitter]
disableInlineCSS = true
`;cfg,err:=config.FromConfigString(tomlConfig,"toml");c.Assert(err,qt.IsNil);config,err:=DecodeConfig(cfg);c.Assert(err,qt.IsNil);c.Assert(config,qt.Not(qt.IsNil));c.Assert(config.Disqus.Shortname,qt.Equals,"DS");c.Assert(config.GoogleAnalytics.ID,qt.Equals,"ga_id");c.Assert(config.Instagram.DisableInlineCSS,qt.Equals,true)};func TestUseSettingsFromRootIfSet(t *testing.T){c:=qt.New(t);cfg:=config.New();cfg.Set("disqusShortname","root_short");cfg.Set("googleAnalytics","ga_root");config,err:=DecodeConfig(cfg);c.Assert(err,qt.IsNil);c.Assert(config,qt.Not(qt.IsNil));c.Assert(config.Disqus.Shortname,qt.Equals,"root_short");c.Assert(config.GoogleAnalytics.ID,qt.Equals,"ga_root")}