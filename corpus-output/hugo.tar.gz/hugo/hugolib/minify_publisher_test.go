package hugolib;import("testing";"github.com/gohugoio/hugo/config");func TestMinifyPublisher(t *testing.T){t.Parallel();v:=config.New();v.Set("minify",true);v.Set("baseURL","https://example.org/");htmlTemplate:=`
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>HTML5 boilerplate – all you really need…</title>
	<link rel="stylesheet" href="css/style.css">
	<!--[if IE]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>

<body id="home">

	<h1>{{ .Title }}</h1>
	<p>{{ .Permalink }}</p>

</body>
</html>
`;b:=newTestSitesBuilder(t);b.WithViper(v).WithTemplatesAdded("layouts/index.html",htmlTemplate);b.CreateSites().Build(BuildCfg{});b.AssertFileContent("public/index.html","<!doctype html>");b.AssertFileContent("public/index.xml","<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?><rss version=\"2.0\" xmlns:atom=\"http://www.w3.org/2005/Atom\"><channel><title/><link>https://example.org/</link>");b.AssertFileContent("public/sitemap.xml","<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?><urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:xhtml=\"http://www.w3.org/1999/xhtml\"><url><loc>h")}