package hugolib;import("testing";"github.com/gohugoio/hugo/config");const robotTxtTemplate=`User-agent: Googlebot
  {{ range .Data.Pages }}
	Disallow: {{.RelPermalink}}
	{{ end }}
`;func TestRobotsTXTOutput(t *testing.T){t.Parallel();cfg:=config.New();cfg.Set("baseURL","http://auth/bub/");cfg.Set("enableRobotsTXT",true);b:=newTestSitesBuilder(t).WithViper(cfg);b.WithTemplatesAdded("layouts/robots.txt",robotTxtTemplate);b.Build(BuildCfg{});b.AssertFileContent("public/robots.txt","User-agent: Googlebot")}