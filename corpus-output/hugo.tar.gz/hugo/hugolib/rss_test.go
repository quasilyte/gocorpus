package hugolib;import("path/filepath";"strings";"testing";"github.com/gohugoio/hugo/deps");func TestRSSOutput(t *testing.T){t.Parallel();var(cfg,fs=newTestCfg();th=newTestHelper(cfg,fs,t));rssLimit:=len(weightedSources)-1;rssURI:="index.xml";cfg.Set("baseURL","http://auth/bub/");cfg.Set("title","RSSTest");cfg.Set("rssLimit",rssLimit);for _,src:=range weightedSources{writeSource(t,fs,filepath.Join("content","sect",src[0]),src[1])};buildSingleSite(t,deps.DepsCfg{Fs:fs,Cfg:cfg},BuildCfg{});th.assertFileContent(filepath.Join("public",rssURI),"<?xml","rss version","RSSTest");th.assertFileContent(filepath.Join("public","sect",rssURI),"<?xml","rss version","Sects on RSSTest");th.assertFileContent(filepath.Join("public","categories","hugo",rssURI),"<?xml","rss version","hugo on RSSTest");content:=readDestination(t,fs,filepath.Join("public",rssURI));c:=strings.Count(content,"<item>");if c!=rssLimit{t.Errorf("incorrect RSS item count: expected %d, got %d",rssLimit,c)};th.assertFileContent(filepath.Join("public",rssURI),"<?xml","description","A &lt;em&gt;custom&lt;/em&gt; summary")};func TestRSSKind(t *testing.T){t.Parallel();b:=newTestSitesBuilder(t);b.WithSimpleConfigFile().WithTemplatesAdded("index.rss.xml",`RSS Kind: {{ .Kind }}`);b.Build(BuildCfg{});b.AssertFileContent("public/index.xml","RSS Kind: home")};func TestRSSCanonifyURLs(t *testing.T){t.Parallel();b:=newTestSitesBuilder(t);b.WithSimpleConfigFile().WithTemplatesAdded("index.rss.xml",`<rss>{{ range .Pages }}<item>{{ .Content | html }}</item>{{ end }}</rss>`);b.WithContent("page.md",`---
Title: My Page
---

Figure:

{{< figure src="/images/sunset.jpg" title="Sunset" >}}



`);b.Build(BuildCfg{});b.AssertFileContent("public/index.xml","img src=&#34;http://example.com/images/sunset.jpg")}