package hugolib;import("testing");func TestEncodePage(t *testing.T){t.Parallel();templ:=`Page: |{{ index .Site.RegularPages 0 | jsonify }}|
Site: {{ site | jsonify }}
`;b:=newTestSitesBuilder(t);b.WithSimpleConfigFile().WithTemplatesAdded("index.html",templ);b.WithContent("page.md",`---
title: "Page"
date: 2019-02-28
---

Content.

`);b.Build(BuildCfg{});b.AssertFileContent("public/index.html",`"Date":"2019-02-28T00:00:00Z"`)}