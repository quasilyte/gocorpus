package livereload;import("bytes";"sync";"github.com/gorilla/websocket");type connection struct{ws *websocket.Conn;send chan []byte;closer sync.Once};func(c *connection)close(){c.closer.Do(func(){close(c.send)})};func(c *connection)reader(){for{_,message,err:=c.ws.ReadMessage();if err!=nil{break};if bytes.Contains(message,[]byte(`"command":"hello"`)){c.send<-[]byte(`{
				"command": "hello",
				"protocols": [ "http://livereload.com/protocols/official-7" ],
				"serverName": "Hugo"
			}`)}};c.ws.Close()};func(c *connection)writer(){for message:=range c.send{err:=c.ws.WriteMessage(websocket.TextMessage,message);if err!=nil{break}};c.ws.Close()}