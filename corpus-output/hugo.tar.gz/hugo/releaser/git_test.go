package releaser;import("testing";qt"github.com/frankban/quicktest");func TestGitInfos(t *testing.T){c:=qt.New(t);skipIfCI(t);infos,err:=getGitInfos("v0.20","hugo","",false);c.Assert(err,qt.IsNil);c.Assert(len(infos)>0,qt.Equals,true)};func TestIssuesRe(t *testing.T){c:=qt.New(t);body:=`
This is a commit message.

Updates #123
Fix #345
closes #543
See #456
	`;issues:=extractIssues(body);c.Assert(len(issues),qt.Equals,4);c.Assert(issues[0],qt.Equals,123);c.Assert(issues[2],qt.Equals,543);bodyNoIssues:=`
This is a commit message without issue refs.

But it has e #10 to make old regexp confused.
Streets #20.
	`;emptyIssuesList:=extractIssues(bodyNoIssues);c.Assert(len(emptyIssuesList),qt.Equals,0)};func TestGitVersionTagBefore(t *testing.T){skipIfCI(t);c:=qt.New(t);v1,err:=gitVersionTagBefore("v0.18");c.Assert(err,qt.IsNil);c.Assert(v1,qt.Equals,"v0.17")};func TestTagExists(t *testing.T){skipIfCI(t);c:=qt.New(t);b1,err:=tagExists("v0.18");c.Assert(err,qt.IsNil);c.Assert(b1,qt.Equals,true);b2,err:=tagExists("adfagdsfg");c.Assert(err,qt.IsNil);c.Assert(b2,qt.Equals,false)};func skipIfCI(t *testing.T){if isCI(){t.Skip("Skip git test on Linux to make Travis happy.")}}