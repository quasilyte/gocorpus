package cmd;import("context";"fmt";"os";"strings";"testing";"time";"github.com/minio/madmin-go";minio"github.com/minio/minio-go/v7";"github.com/minio/minio-go/v7/pkg/credentials";cr"github.com/minio/minio-go/v7/pkg/credentials";"github.com/minio/minio-go/v7/pkg/set";"github.com/minio/minio/internal/auth");const(testDefaultTimeout=30*time.Second);type TestSuiteIAM struct{TestSuiteCommon;withEtcdBackend bool;endpoint string;adm *madmin.AdminClient;client *minio.Client};func newTestSuiteIAM(c TestSuiteCommon,withEtcdBackend bool)*TestSuiteIAM{return &TestSuiteIAM{TestSuiteCommon:c,withEtcdBackend:withEtcdBackend}};func(s *TestSuiteIAM)iamSetup(c *check){var err error;s.endpoint=strings.TrimPrefix(s.endPoint,"http://");if s.secure{s.endpoint=strings.TrimPrefix(s.endPoint,"https://")};s.adm,err=madmin.New(s.endpoint,s.accessKey,s.secretKey,s.secure);if err!=nil{c.Fatalf("error creating admin client: %v",err)};s.adm.SetCustomTransport(s.TestSuiteCommon.client.Transport);s.client,err=minio.New(s.endpoint,&minio.Options{Creds:credentials.NewStaticV4(s.accessKey,s.secretKey,""),Secure:s.secure,Transport:s.TestSuiteCommon.client.Transport});if err!=nil{c.Fatalf("error creating minio client: %v",err)}};const(EnvTestEtcdBackend="ETCD_SERVER");func(s *TestSuiteIAM)setUpEtcd(c *check,etcdServer string){ctx,cancel:=context.WithTimeout(context.Background(),testDefaultTimeout);defer cancel();configCmds:=[]string{"etcd","endpoints="+etcdServer,"path_prefix="+mustGetUUID()};_,err:=s.adm.SetConfigKV(ctx,strings.Join(configCmds," "));if err!=nil{c.Fatalf("unable to setup Etcd for tests: %v",err)};s.RestartIAMSuite(c)};func(s *TestSuiteIAM)SetUpSuite(c *check){etcdServer:=os.Getenv(EnvTestEtcdBackend);if s.withEtcdBackend&&etcdServer==""{c.Skip("Skipping etcd backend IAM test as no etcd server is configured.")};s.TestSuiteCommon.SetUpSuite(c);s.iamSetup(c);if s.withEtcdBackend{s.setUpEtcd(c,etcdServer)}};func(s *TestSuiteIAM)RestartIAMSuite(c *check){s.TestSuiteCommon.RestartTestServer(c);s.iamSetup(c)};func(s *TestSuiteIAM)getAdminClient(c *check,accessKey,secretKey,sessionToken string)*madmin.AdminClient{madmClnt,err:=madmin.NewWithOptions(s.endpoint,&madmin.Options{Creds:credentials.NewStaticV4(accessKey,secretKey,sessionToken),Secure:s.secure});if err!=nil{c.Fatalf("error creating user admin client: %s",err)};madmClnt.SetCustomTransport(s.TestSuiteCommon.client.Transport);return madmClnt};func(s *TestSuiteIAM)getUserClient(c *check,accessKey,secretKey,sessionToken string)*minio.Client{client,err:=minio.New(s.endpoint,&minio.Options{Creds:credentials.NewStaticV4(accessKey,secretKey,sessionToken),Secure:s.secure,Transport:s.TestSuiteCommon.client.Transport});if err!=nil{c.Fatalf("error creating user minio client: %s",err)};return client};func TestIAMInternalIDPServerSuite(t *testing.T){baseTestCases:=[]TestSuiteCommon{{serverType:"FS",signer:signerV4},{serverType:"FS",signer:signerV4,secure:true},{serverType:"Erasure",signer:signerV4},{serverType:"ErasureSet",signer:signerV4}};testCases:=[]*TestSuiteIAM{};for _,bt:=range baseTestCases{testCases=append(testCases,newTestSuiteIAM(bt,false),newTestSuiteIAM(bt,true))};for i,testCase:=range testCases{etcdStr:="";if testCase.withEtcdBackend{etcdStr=" (with etcd backend)"};t.Run(fmt.Sprintf("Test: %d, ServerType: %s%s",i+1,testCase.serverType,etcdStr),func(t *testing.T){suite:=testCase;c:=&check{t,testCase.serverType};suite.SetUpSuite(c);suite.TestUserCreate(c);suite.TestPolicyCreate(c);suite.TestCannedPolicies(c);suite.TestGroupAddRemove(c);suite.TestServiceAccountOpsByAdmin(c);suite.TestServiceAccountOpsByUser(c);suite.TestAddServiceAccountPerms(c);suite.TearDownSuite(c)})}};func(s *TestSuiteIAM)TestUserCreate(c *check){ctx,cancel:=context.WithTimeout(context.Background(),testDefaultTimeout);defer cancel();accessKey,secretKey:=mustGenerateCredentials(c);err:=s.adm.SetUser(ctx,accessKey,secretKey,madmin.AccountEnabled);if err!=nil{c.Fatalf("Unable to set user: %v",err)};usersMap,err:=s.adm.ListUsers(ctx);if err!=nil{c.Fatalf("error listing: %v",err)};v,ok:=usersMap[accessKey];if !ok{c.Fatalf("user not listed: %s",accessKey)};c.Assert(v.Status,madmin.AccountEnabled);err=s.adm.SetPolicy(ctx,"readwrite",accessKey,false);if err!=nil{c.Fatalf("unable to set policy: %v",err)};client:=s.getUserClient(c,accessKey,secretKey,"");err=client.MakeBucket(ctx,getRandomBucketName(),minio.MakeBucketOptions{});if err!=nil{c.Fatalf("user could not create bucket: %v",err)};err=s.adm.SetUserStatus(ctx,accessKey,madmin.AccountDisabled);if err!=nil{c.Fatalf("could not set user account to disabled")};usersMap,err=s.adm.ListUsers(ctx);if err!=nil{c.Fatalf("error listing: %v",err)};v,ok=usersMap[accessKey];if !ok{c.Fatalf("user was not listed after disabling: %s",accessKey)};c.Assert(v.Status,madmin.AccountDisabled);err=client.MakeBucket(ctx,getRandomBucketName(),minio.MakeBucketOptions{});if err==nil{c.Fatalf("user account was not disabled!")};err=s.adm.RemoveUser(ctx,accessKey);if err!=nil{c.Fatalf("user could not be deleted: %v",err)};usersMap,err=s.adm.ListUsers(ctx);if err!=nil{c.Fatalf("error listing: %v",err)};_,ok=usersMap[accessKey];if ok{c.Fatalf("user not deleted: %s",accessKey)};err=client.MakeBucket(ctx,getRandomBucketName(),minio.MakeBucketOptions{});if err==nil{c.Fatalf("user account was not deleted!")}};func(s *TestSuiteIAM)TestAddServiceAccountPerms(c *check){ctx,cancel:=context.WithTimeout(context.Background(),testDefaultTimeout);defer cancel();policy1:="deny-svc";policy2:="allow-svc";policyBytes:=[]byte(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Deny",
   "Action": [
    "admin:CreateServiceAccount"
   ]
  }
 ]
}`);newPolicyBytes:=[]byte(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Allow",
   "Action": [
    "s3:ListBucket"
   ],
   "Resource": [
    "arn:aws:s3:::testbucket/*"
   ]
  }
 ]
}`);err:=s.adm.AddCannedPolicy(ctx,policy1,policyBytes);if err!=nil{c.Fatalf("policy add error: %v",err)};err=s.adm.AddCannedPolicy(ctx,policy2,newPolicyBytes);if err!=nil{c.Fatalf("policy add error: %v",err)};invalidPolicyBytes:=policyBytes[:len(policyBytes)-1];err=s.adm.AddCannedPolicy(ctx,policy1+"invalid",invalidPolicyBytes);if err==nil{c.Fatalf("invalid policy creation success")};accessKey,secretKey:=mustGenerateCredentials(c);err=s.adm.SetUser(ctx,accessKey,secretKey,madmin.AccountEnabled);if err!=nil{c.Fatalf("Unable to set user: %v",err)};uClient:=s.getUserClient(c,accessKey,secretKey,"");c.mustNotListObjects(ctx,uClient,"testbucket");err=s.adm.SetPolicy(ctx,policy1,accessKey,false);if err!=nil{c.Fatalf("Unable to set policy: %v",err)};admClnt:=s.getAdminClient(c,accessKey,secretKey,"");c.mustNotCreateSvcAccount(ctx,accessKey,admClnt);ps,err:=s.adm.ListCannedPolicies(ctx);if err!=nil{c.Fatalf("policy list err: %v",err)};_,ok:=ps[policy1];if !ok{c.Fatalf("policy was missing!")};err=s.adm.SetPolicy(ctx,policy2,accessKey,false);if err!=nil{c.Fatalf("Unable to set policy: %v",err)};c.mustCreateSvcAccount(ctx,accessKey,admClnt);_,ok=ps[policy2];if !ok{c.Fatalf("policy was missing!")};err=s.adm.RemoveUser(ctx,accessKey);if err!=nil{c.Fatalf("user could not be deleted: %v",err)};err=s.adm.RemoveCannedPolicy(ctx,policy1);if err!=nil{c.Fatalf("policy del err: %v",err)};err=s.adm.RemoveCannedPolicy(ctx,policy2);if err!=nil{c.Fatalf("policy del err: %v",err)}};func(s *TestSuiteIAM)TestPolicyCreate(c *check){ctx,cancel:=context.WithTimeout(context.Background(),testDefaultTimeout);defer cancel();bucket:=getRandomBucketName();err:=s.client.MakeBucket(ctx,bucket,minio.MakeBucketOptions{});if err!=nil{c.Fatalf("bucket creat error: %v",err)};policy:="mypolicy";policyBytes:=[]byte(fmt.Sprintf(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Allow",
   "Action": [
    "s3:PutObject",
    "s3:GetObject",
    "s3:ListBucket"
   ],
   "Resource": [
    "arn:aws:s3:::%s/*"
   ]
  }
 ]
}`,bucket));err=s.adm.AddCannedPolicy(ctx,policy,policyBytes);if err!=nil{c.Fatalf("policy add error: %v",err)};invalidPolicyBytes:=policyBytes[:len(policyBytes)-1];err=s.adm.AddCannedPolicy(ctx,policy+"invalid",invalidPolicyBytes);if err==nil{c.Fatalf("invalid policy creation success")};accessKey,secretKey:=mustGenerateCredentials(c);err=s.adm.SetUser(ctx,accessKey,secretKey,madmin.AccountEnabled);if err!=nil{c.Fatalf("Unable to set user: %v",err)};uClient:=s.getUserClient(c,accessKey,secretKey,"");c.mustNotListObjects(ctx,uClient,bucket);err=s.adm.SetPolicy(ctx,policy,accessKey,false);if err!=nil{c.Fatalf("Unable to set policy: %v",err)};c.mustListObjects(ctx,uClient,bucket);err=uClient.RemoveBucket(ctx,bucket);if err==nil{c.Fatalf("bucket was deleted!")};ps,err:=s.adm.ListCannedPolicies(ctx);if err!=nil{c.Fatalf("policy list err: %v",err)};_,ok:=ps[policy];if !ok{c.Fatalf("policy was missing!")};err=s.adm.RemoveCannedPolicy(ctx,policy);if err==nil{c.Fatalf("policy could be unexpectedly deleted!")};err=s.adm.RemoveUser(ctx,accessKey);if err!=nil{c.Fatalf("user could not be deleted: %v",err)};err=s.adm.RemoveCannedPolicy(ctx,policy);if err!=nil{c.Fatalf("policy del err: %v",err)}};func(s *TestSuiteIAM)TestCannedPolicies(c *check){ctx,cancel:=context.WithTimeout(context.Background(),testDefaultTimeout);defer cancel();policies,err:=s.adm.ListCannedPolicies(ctx);if err!=nil{c.Fatalf("unable to list policies: %v",err)};defaultPolicies:=[]string{"readwrite","readonly","writeonly","diagnostics","consoleAdmin"};for _,v:=range defaultPolicies{if _,ok:=policies[v];!ok{c.Fatalf("Failed to find %s in policies list",v)}};bucket:=getRandomBucketName();err=s.client.MakeBucket(ctx,bucket,minio.MakeBucketOptions{});if err!=nil{c.Fatalf("bucket creat error: %v",err)};policyBytes:=[]byte(fmt.Sprintf(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Allow",
   "Action": [
    "s3:PutObject",
    "s3:GetObject",
    "s3:ListBucket"
   ],
   "Resource": [
    "arn:aws:s3:::%s/*"
   ]
  }
 ]
}`,bucket));err=s.adm.AddCannedPolicy(ctx,"readwrite",policyBytes);if err!=nil{c.Fatalf("policy add error: %v",err)};info,err:=s.adm.InfoCannedPolicy(ctx,"readwrite");if err!=nil{c.Fatalf("policy info err: %v",err)};infoStr:=string(info);if !strings.Contains(infoStr,`"s3:PutObject"`)||!strings.Contains(infoStr,":"+bucket+"/"){c.Fatalf("policy contains unexpected content!")}};func(s *TestSuiteIAM)TestGroupAddRemove(c *check){ctx,cancel:=context.WithTimeout(context.Background(),testDefaultTimeout);defer cancel();bucket:=getRandomBucketName();err:=s.client.MakeBucket(ctx,bucket,minio.MakeBucketOptions{});if err!=nil{c.Fatalf("bucket creat error: %v",err)};policy:="mypolicy";policyBytes:=[]byte(fmt.Sprintf(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Allow",
   "Action": [
    "s3:PutObject",
    "s3:GetObject",
    "s3:ListBucket"
   ],
   "Resource": [
    "arn:aws:s3:::%s/*"
   ]
  }
 ]
}`,bucket));err=s.adm.AddCannedPolicy(ctx,policy,policyBytes);if err!=nil{c.Fatalf("policy add error: %v",err)};accessKey,secretKey:=mustGenerateCredentials(c);err=s.adm.SetUser(ctx,accessKey,secretKey,madmin.AccountEnabled);if err!=nil{c.Fatalf("Unable to set user: %v",err)};group:="mygroup";err=s.adm.UpdateGroupMembers(ctx,madmin.GroupAddRemove{Group:group,Members:[]string{accessKey}});if err!=nil{c.Fatalf("Unable to add user to group: %v",err)};uClient:=s.getUserClient(c,accessKey,secretKey,"");c.mustNotListObjects(ctx,uClient,bucket);err=s.adm.SetPolicy(ctx,policy,group,true);if err!=nil{c.Fatalf("Unable to set policy: %v",err)};c.mustListObjects(ctx,uClient,bucket);err=uClient.RemoveBucket(ctx,bucket);if err==nil{c.Fatalf("bucket was deleted!")};groups,err:=s.adm.ListGroups(ctx);if err!=nil{c.Fatalf("group list err: %v",err)};if !set.CreateStringSet(groups...).Contains(group){c.Fatalf("created group not present!")};groupInfo,err:=s.adm.GetGroupDescription(ctx,group);if err!=nil{c.Fatalf("group desc err: %v",err)};c.Assert(groupInfo.Name,group);c.Assert(set.CreateStringSet(groupInfo.Members...),set.CreateStringSet(accessKey));c.Assert(groupInfo.Policy,policy);c.Assert(groupInfo.Status,string(madmin.GroupEnabled));err=s.adm.SetGroupStatus(ctx,group,madmin.GroupDisabled);if err!=nil{c.Fatalf("group set status err: %v",err)};groupInfo,err=s.adm.GetGroupDescription(ctx,group);if err!=nil{c.Fatalf("group desc err: %v",err)};c.Assert(groupInfo.Status,string(madmin.GroupDisabled));c.mustNotListObjects(ctx,uClient,bucket);err=s.adm.SetGroupStatus(ctx,group,madmin.GroupEnabled);if err!=nil{c.Fatalf("group set status err: %v",err)};groupInfo,err=s.adm.GetGroupDescription(ctx,group);if err!=nil{c.Fatalf("group desc err: %v",err)};c.Assert(groupInfo.Status,string(madmin.GroupEnabled));c.mustListObjects(ctx,uClient,bucket);err=s.adm.UpdateGroupMembers(ctx,madmin.GroupAddRemove{Group:group,IsRemove:true});if err==nil{c.Fatalf("group was removed!")};groupInfo,err=s.adm.GetGroupDescription(ctx,group);if err!=nil{c.Fatalf("group desc err: %v",err)};c.Assert(groupInfo.Name,group);err=s.adm.UpdateGroupMembers(ctx,madmin.GroupAddRemove{Group:group,Members:[]string{accessKey},IsRemove:true});if err!=nil{c.Fatalf("group update err: %v",err)};c.mustNotListObjects(ctx,uClient,bucket);groupInfo,err=s.adm.GetGroupDescription(ctx,group);if err!=nil{c.Fatalf("group desc err: %v",err)};c.Assert(groupInfo.Name,group);c.Assert(len(groupInfo.Members),0);err=s.adm.UpdateGroupMembers(ctx,madmin.GroupAddRemove{Group:group,IsRemove:true});if err!=nil{c.Fatalf("group update err: %v",err)};groups,err=s.adm.ListGroups(ctx);if err!=nil{c.Fatalf("group list err: %v",err)};if set.CreateStringSet(groups...).Contains(group){c.Fatalf("created group still present!")};groupInfo,err=s.adm.GetGroupDescription(ctx,group);if err==nil{c.Fatalf("group appears to exist")}};func(s *TestSuiteIAM)TestServiceAccountOpsByUser(c *check){ctx,cancel:=context.WithTimeout(context.Background(),testDefaultTimeout);defer cancel();bucket:=getRandomBucketName();err:=s.client.MakeBucket(ctx,bucket,minio.MakeBucketOptions{});if err!=nil{c.Fatalf("bucket creat error: %v",err)};policy:="mypolicy";policyBytes:=[]byte(fmt.Sprintf(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Allow",
   "Action": [
    "s3:PutObject",
    "s3:GetObject",
    "s3:ListBucket"
   ],
   "Resource": [
    "arn:aws:s3:::%s/*"
   ]
  }
 ]
}`,bucket));err=s.adm.AddCannedPolicy(ctx,policy,policyBytes);if err!=nil{c.Fatalf("policy add error: %v",err)};accessKey,secretKey:=mustGenerateCredentials(c);err=s.adm.SetUser(ctx,accessKey,secretKey,madmin.AccountEnabled);if err!=nil{c.Fatalf("Unable to set user: %v",err)};err=s.adm.SetPolicy(ctx,policy,accessKey,false);if err!=nil{c.Fatalf("Unable to set policy: %v",err)};userAdmClient,err:=madmin.NewWithOptions(s.endpoint,&madmin.Options{Creds:cr.NewStaticV4(accessKey,secretKey,""),Secure:s.secure});if err!=nil{c.Fatalf("Err creating user admin client: %v",err)};userAdmClient.SetCustomTransport(s.TestSuiteCommon.client.Transport);cr:=c.mustCreateSvcAccount(ctx,accessKey,userAdmClient);c.assertSvcAccAppearsInListing(ctx,userAdmClient,accessKey,cr.AccessKey);c.assertSvcAccInfoQueryable(ctx,userAdmClient,accessKey,cr.AccessKey,false);c.assertSvcAccS3Access(ctx,s,cr,bucket);c.assertSvcAccSessionPolicyUpdate(ctx,s,userAdmClient,accessKey,bucket);c.assertSvcAccSecretKeyAndStatusUpdate(ctx,s,userAdmClient,accessKey,bucket);c.assertSvcAccDeletion(ctx,s,userAdmClient,accessKey,bucket)};func(s *TestSuiteIAM)TestServiceAccountOpsByAdmin(c *check){ctx,cancel:=context.WithTimeout(context.Background(),testDefaultTimeout);defer cancel();bucket:=getRandomBucketName();err:=s.client.MakeBucket(ctx,bucket,minio.MakeBucketOptions{});if err!=nil{c.Fatalf("bucket creat error: %v",err)};policy:="mypolicy";policyBytes:=[]byte(fmt.Sprintf(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Allow",
   "Action": [
    "s3:PutObject",
    "s3:GetObject",
    "s3:ListBucket"
   ],
   "Resource": [
    "arn:aws:s3:::%s/*"
   ]
  }
 ]
}`,bucket));err=s.adm.AddCannedPolicy(ctx,policy,policyBytes);if err!=nil{c.Fatalf("policy add error: %v",err)};accessKey,secretKey:=mustGenerateCredentials(c);err=s.adm.SetUser(ctx,accessKey,secretKey,madmin.AccountEnabled);if err!=nil{c.Fatalf("Unable to set user: %v",err)};err=s.adm.SetPolicy(ctx,policy,accessKey,false);if err!=nil{c.Fatalf("Unable to set policy: %v",err)};cr:=c.mustCreateSvcAccount(ctx,accessKey,s.adm);c.assertSvcAccAppearsInListing(ctx,s.adm,accessKey,cr.AccessKey);c.assertSvcAccInfoQueryable(ctx,s.adm,accessKey,cr.AccessKey,false);c.assertSvcAccS3Access(ctx,s,cr,bucket);c.assertSvcAccSessionPolicyUpdate(ctx,s,s.adm,accessKey,bucket);c.assertSvcAccSecretKeyAndStatusUpdate(ctx,s,s.adm,accessKey,bucket);c.assertSvcAccDeletion(ctx,s,s.adm,accessKey,bucket)};func(c *check)mustCreateIAMUser(ctx context.Context,admClnt *madmin.AdminClient)madmin.Credentials{randUser:=mustGetUUID();randPass:=mustGetUUID();err:=admClnt.AddUser(ctx,randUser,randPass);if err!=nil{c.Fatalf("should be able to create a user: %v",err)};return madmin.Credentials{AccessKey:randUser,SecretKey:randPass}};func(c *check)mustGetIAMUserInfo(ctx context.Context,admClnt *madmin.AdminClient,accessKey string)madmin.UserInfo{ui,err:=admClnt.GetUserInfo(ctx,accessKey);if err!=nil{c.Fatalf("should be able to get user info: %v",err)};return ui};func(c *check)mustNotCreateIAMUser(ctx context.Context,admClnt *madmin.AdminClient){randUser:=mustGetUUID();randPass:=mustGetUUID();err:=admClnt.AddUser(ctx,randUser,randPass);if err==nil{c.Fatalf("should not be able to create a user")}};func(c *check)mustCreateSvcAccount(ctx context.Context,tgtUser string,admClnt *madmin.AdminClient)madmin.Credentials{cr,err:=admClnt.AddServiceAccount(ctx,madmin.AddServiceAccountReq{TargetUser:tgtUser});if err!=nil{c.Fatalf("user should be able to create service accounts %s",err)};return cr};func(c *check)mustNotCreateSvcAccount(ctx context.Context,tgtUser string,admClnt *madmin.AdminClient){_,err:=admClnt.AddServiceAccount(ctx,madmin.AddServiceAccountReq{TargetUser:tgtUser});if err==nil{c.Fatalf("user was able to add service accounts unexpectedly!")}};func(c *check)mustNotListObjects(ctx context.Context,client *minio.Client,bucket string){res:=client.ListObjects(ctx,bucket,minio.ListObjectsOptions{});v,ok:=<-res;if !ok||v.Err==nil{c.Fatalf("user was able to list unexpectedly!")}};func(c *check)mustListObjects(ctx context.Context,client *minio.Client,bucket string){res:=client.ListObjects(ctx,bucket,minio.ListObjectsOptions{});v,ok:=<-res;if ok&&v.Err!=nil{msg:=fmt.Sprintf("user was unable to list: %v",v.Err);c.Fatalf(msg)}};func(c *check)assertSvcAccS3Access(ctx context.Context,s *TestSuiteIAM,cr madmin.Credentials,bucket string){svcClient:=s.getUserClient(c,cr.AccessKey,cr.SecretKey,"");c.mustListObjects(ctx,svcClient,bucket)};func(c *check)assertSvcAccAppearsInListing(ctx context.Context,madmClient *madmin.AdminClient,parentAK,svcAK string){listResp,err:=madmClient.ListServiceAccounts(ctx,parentAK);if err!=nil{c.Fatalf("unable to list svc accounts: %v",err)};if !set.CreateStringSet(listResp.Accounts...).Contains(svcAK){c.Fatalf("service account did not appear in listing!")}};func(c *check)assertSvcAccInfoQueryable(ctx context.Context,madmClient *madmin.AdminClient,parentAK,svcAK string,skipParentUserCheck bool){infoResp,err:=madmClient.InfoServiceAccount(ctx,svcAK);if err!=nil{c.Fatalf("unable to get svc acc info: %v",err)};if !skipParentUserCheck{c.Assert(infoResp.ParentUser,parentAK)};c.Assert(infoResp.AccountStatus,"on");c.Assert(infoResp.ImpliedPolicy,true)};func(c *check)assertSvcAccSessionPolicyUpdate(ctx context.Context,s *TestSuiteIAM,madmClient *madmin.AdminClient,accessKey,bucket string){svcAK,svcSK:=mustGenerateCredentials(c);policyBytes:=[]byte(fmt.Sprintf(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Allow",
   "Action": [
    "s3:PutObject",
    "s3:GetObject"
   ],
   "Resource": [
    "arn:aws:s3:::%s/*"
   ]
  }
 ]
}`,bucket));cr,err:=madmClient.AddServiceAccount(ctx,madmin.AddServiceAccountReq{Policy:policyBytes,TargetUser:accessKey,AccessKey:svcAK,SecretKey:svcSK});if err!=nil{c.Fatalf("Unable to create svc acc: %v",err)};svcClient:=s.getUserClient(c,cr.AccessKey,cr.SecretKey,"");c.mustNotListObjects(ctx,svcClient,bucket);newPolicyBytes:=[]byte(fmt.Sprintf(`{
 "Version": "2012-10-17",
 "Statement": [
  {
   "Effect": "Allow",
   "Action": [
    "s3:ListBucket"
   ],
   "Resource": [
    "arn:aws:s3:::%s/*"
   ]
  }
 ]
}`,bucket));err=madmClient.UpdateServiceAccount(ctx,svcAK,madmin.UpdateServiceAccountReq{NewPolicy:newPolicyBytes});if err!=nil{c.Fatalf("unable to update session policy for svc acc: %v",err)};c.mustListObjects(ctx,svcClient,bucket)};func(c *check)assertSvcAccSecretKeyAndStatusUpdate(ctx context.Context,s *TestSuiteIAM,madmClient *madmin.AdminClient,accessKey,bucket string){svcAK,svcSK:=mustGenerateCredentials(c);cr,err:=madmClient.AddServiceAccount(ctx,madmin.AddServiceAccountReq{TargetUser:accessKey,AccessKey:svcAK,SecretKey:svcSK});if err!=nil{c.Fatalf("Unable to create svc acc: %v",err)};svcClient:=s.getUserClient(c,cr.AccessKey,cr.SecretKey,"");c.mustListObjects(ctx,svcClient,bucket);_,svcSK2:=mustGenerateCredentials(c);err=madmClient.UpdateServiceAccount(ctx,svcAK,madmin.UpdateServiceAccountReq{NewSecretKey:svcSK2});if err!=nil{c.Fatalf("unable to update secret key for svc acc: %v",err)};c.mustNotListObjects(ctx,svcClient,bucket);svcClient2:=s.getUserClient(c,cr.AccessKey,svcSK2,"");c.mustListObjects(ctx,svcClient2,bucket);err=madmClient.UpdateServiceAccount(ctx,svcAK,madmin.UpdateServiceAccountReq{NewStatus:"off"});if err!=nil{c.Fatalf("unable to update secret key for svc acc: %v",err)};c.mustNotListObjects(ctx,svcClient2,bucket)};func(c *check)assertSvcAccDeletion(ctx context.Context,s *TestSuiteIAM,madmClient *madmin.AdminClient,accessKey,bucket string){svcAK,svcSK:=mustGenerateCredentials(c);cr,err:=madmClient.AddServiceAccount(ctx,madmin.AddServiceAccountReq{TargetUser:accessKey,AccessKey:svcAK,SecretKey:svcSK});if err!=nil{c.Fatalf("Unable to create svc acc: %v",err)};svcClient:=s.getUserClient(c,cr.AccessKey,cr.SecretKey,"");c.mustListObjects(ctx,svcClient,bucket);err=madmClient.DeleteServiceAccount(ctx,svcAK);if err!=nil{c.Fatalf("unable to delete svc acc: %v",err)};c.mustNotListObjects(ctx,svcClient,bucket)};func mustGenerateCredentials(c *check)(string,string){ak,sk,err:=auth.GenerateCredentials();if err!=nil{c.Fatalf("unable to generate credentials: %v",err)};return ak,sk}