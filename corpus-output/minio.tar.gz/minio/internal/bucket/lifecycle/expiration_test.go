package lifecycle;import("encoding/xml";"fmt";"testing");func TestInvalidExpiration(t *testing.T){testCases:=[]struct{inputXML string;expectedErr error}{{inputXML:` <Expiration>
                                    <Days>0</Days>
                                    </Expiration>`,expectedErr:errLifecycleInvalidDays},{inputXML:` <Expiration>
                                    <Date>invalid date</Date>
                                    </Expiration>`,expectedErr:errLifecycleInvalidDate},{inputXML:`<Expiration>
		                    <Date>2019-04-20T00:01:00Z</Date>
		                    </Expiration>`,expectedErr:errLifecycleDateNotMidnight}};for i,tc:=range testCases{t.Run(fmt.Sprintf("Test %d",i+1),func(t *testing.T){var expiration Expiration;err:=xml.Unmarshal([]byte(tc.inputXML),&expiration);if err!=tc.expectedErr{t.Fatalf("%d: Expected %v but got %v",i+1,tc.expectedErr,err)}})};validationTestCases:=[]struct{inputXML string;expectedErr error}{{inputXML:`<Expiration>
                                    <Date>2019-04-20T00:00:00Z</Date>
                                    </Expiration>`,expectedErr:nil},{inputXML:`<Expiration>
                                    <Days>3</Days>
                                    </Expiration>`,expectedErr:nil},{inputXML:`<Expiration>
                                    </Expiration>`,expectedErr:errXMLNotWellFormed},{inputXML:`<Expiration>
                                    <Days>3</Days>
                                    <Date>2019-04-20T00:00:00Z</Date>
                                    </Expiration>`,expectedErr:errLifecycleInvalidExpiration},{inputXML:`<Expiration>
                                    <Days>3</Days>
			            <ExpiredObjectDeleteMarker>false</ExpiredObjectDeleteMarker>
                                    </Expiration>`,expectedErr:errLifecycleInvalidDeleteMarker}};for i,tc:=range validationTestCases{t.Run(fmt.Sprintf("Test %d",i+1),func(t *testing.T){var expiration Expiration;err:=xml.Unmarshal([]byte(tc.inputXML),&expiration);if err!=nil{t.Fatalf("%d: %v",i+1,err)};err=expiration.Validate();if err!=tc.expectedErr{t.Fatalf("%d: got: %v, expected: %v",i+1,err,tc.expectedErr)}})}}