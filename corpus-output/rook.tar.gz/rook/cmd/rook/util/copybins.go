package util;import("fmt";"github.com/rook/rook/cmd/rook/rook";"github.com/rook/rook/pkg/daemon/util";"github.com/spf13/cobra");var CopyBinsCmd=&cobra.Command{Use:"copy-binaries",Short:"Copy 'rook' binary from a container to a given directory.",Long:`Copy 'rook' binary from a container to a given directory.
As an example, 'cmd-reporter run' may often need to be run from a container
other than the container containing the 'rook' binary. Use this command to copy
the 'rook' binary from the container containing the 'rook'
binary to a Kubernetes EmptyDir volume mounted at the given directory in a pod's
init container. From the pod's main container, mount the volume which now
contains the 'rook' binary, and call 'rook cmd-reporter run' from
'rook' in order to run the desired command from a non-Rook container.`,Args:cobra.NoArgs,RunE:runCopyBins};func init(){CopyBinsCmd.Flags().StringVar(&copyToDir,"copy-to-dir","","The directory into which 'rook' binary will be copied.");if err:=CopyBinsCmd.MarkFlagRequired("copy-to-dir");err!=nil{panic(err)}};func runCopyBins(cCmd *cobra.Command,cArgs []string)error{if err:=util.CopyBinaries(copyToDir);err!=nil{rook.TerminateFatal(fmt.Errorf("could not copy binary to %s. %+v",copyToDir,err))};return nil}