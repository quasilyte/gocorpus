package v1;import("encoding/json";"testing";"github.com/stretchr/testify/assert";"k8s.io/apimachinery/pkg/util/yaml");func TestPriorityClassNamesSpec(t *testing.T){specYaml:=[]byte(`
all: all-class
mgr: mgr-class
mon: mon-class
osd: osd-class
`);rawJSON,err:=yaml.ToJSON(specYaml);assert.Nil(t,err);var priorityClassNames PriorityClassNamesSpec;err=json.Unmarshal(rawJSON,&priorityClassNames);assert.Nil(t,err);expected:=PriorityClassNamesSpec{"all":"all-class","mgr":"mgr-class","mon":"mon-class","osd":"osd-class"};assert.Equal(t,expected,priorityClassNames)};func TestPriorityClassNamesDefaultToAll(t *testing.T){priorityClassNames:=PriorityClassNamesSpec{"all":"all-class","mon":"mon-class"};assert.Equal(t,"all-class",priorityClassNames.All())}