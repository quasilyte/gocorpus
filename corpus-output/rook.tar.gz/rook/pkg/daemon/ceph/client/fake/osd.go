package fake;import("fmt";"strconv";"strings");func OsdLsOutput(numOSDs int)string{stringIDs:=make([]string,0,numOSDs);for id:=0;id<numOSDs;id++{stringIDs=append(stringIDs,strconv.Itoa(id))};return fmt.Sprintf("[%s]",strings.Join(stringIDs,","))};func OsdTreeOutput(numNodes,numOSDsPerNode int)string{rootFormat:=`		{
			"id": -1,
			"name": "default",
			"type": "root",
			"type_id": 11,
			"children": [%s]
		}`;nodeFormat:=`		{
			"id": %d,
			"name": "%s",
			"type": "host",
			"type_id": 1,
			"pool_weights": {},
			"children": [%s]
		}`;osdFormat:=`		{
			"id": %d,
			"device_class": "hdd",
			"name": "osd.%d",
			"type": "osd",
			"type_id": 0,
			"crush_weight": 0.009796142578125,
			"depth": 2,
			"pool_weights": {},
			"exists": 1,
			"status": "up",
			"reweight": 1,
			"primary_affinity": 1
		}`;wrapperFormat:=`{
	"nodes": [
%s
	],
	"stray": []
}`;nodesJSON:=[]string{};osdsJSON:=[]string{};nodes:=[]string{};for n:=0;n<numNodes;n++{osds:=[]string{};nodeName:=fmt.Sprintf("node%d",n);nodeID:=-3-n;nodes=append(nodes,strconv.Itoa(nodeID));for i:=0;i<numOSDsPerNode;i++{osdID:=n+3*i;osds=append(osds,strconv.Itoa(osdID));osdsJSON=append(osdsJSON,fmt.Sprintf(osdFormat,osdID,osdID))};nodesJSON=append(nodesJSON,fmt.Sprintf(nodeFormat,nodeID,nodeName,strings.Join(osds,",")))};rootJSON:=fmt.Sprintf(rootFormat,strings.Join(nodes,","));fullJSON:=append(append([]string{rootJSON},nodesJSON...),osdsJSON...);rendered:=fmt.Sprintf(wrapperFormat,strings.Join(fullJSON,",\n"));return rendered};func OsdOkToStopOutput(queriedID int,returnOsdIds []int,useCephPacificPlusOutput bool)string{okTemplate:=`{"ok_to_stop":true,"osds":[%s],"num_ok_pgs":132,"num_not_ok_pgs":0,"ok_become_degraded":["1.0","1.2","1.3"]}`;notOkTemplate:=`{"ok_to_stop":false,"osds":[%d],"num_ok_pgs":161,"num_not_ok_pgs":50,"bad_become_inactive":["1.0","1.3","1.a"],"ok_become_degraded":["1.2","1.4","1.5"]}`;if !useCephPacificPlusOutput{return ""};if len(returnOsdIds)==0{return fmt.Sprintf(notOkTemplate,queriedID)};osdIdsStr:=make([]string,len(returnOsdIds));for i:=0;i<len(returnOsdIds);i++{osdIdsStr[i]=strconv.Itoa(returnOsdIds[i])};return fmt.Sprintf(okTemplate,strings.Join(osdIdsStr,","))};func OSDDeviceClassOutput(osdId string)string{if osdId==""{return "ERR: fake error from ceph cli"};okTemplate:=`[{"osd":%s,"device_class":"hdd"}]`;return fmt.Sprintf(okTemplate,osdId)}