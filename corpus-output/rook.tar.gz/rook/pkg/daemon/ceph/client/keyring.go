package client;import("encoding/base64";"fmt";"io/ioutil";"os";"path/filepath";"github.com/pkg/errors";"github.com/rook/rook/pkg/clusterd");const(AdminKeyringTemplate=`
[client.admin]
	key = %s
	caps mds = "allow *"
	caps mon = "allow *"
	caps osd = "allow *"
	caps mgr = "allow *"
`;UserKeyringTemplate=`
[%s]
	key = %s
`);func CephKeyring(cred CephCred)string{if cred.Username==AdminUsername{return fmt.Sprintf(AdminKeyringTemplate,cred.Secret)};return fmt.Sprintf(UserKeyringTemplate,cred.Username,cred.Secret)};func WriteKeyring(keyringPath,authKey string,generateContents func(string)string)error{contents:=generateContents(authKey);return writeKeyring(contents,keyringPath)};func CreateKeyring(context *clusterd.Context,clusterInfo *ClusterInfo,username,keyringPath string,access []string,generateContents func(string)string)error{_,err:=os.Stat(keyringPath);if err==nil{logger.Debugf("keyring already exists at %s",keyringPath);return nil}else if !os.IsNotExist(err){return errors.Wrapf(err,"failed to stat %s",keyringPath)};key,err:=AuthGetOrCreateKey(context,clusterInfo,username,access);if err!=nil{return errors.Wrapf(err,"failed to get or create auth key for %s",username)};return WriteKeyring(keyringPath,key,generateContents)};func writeKeyring(keyring,keyringPath string)error{if err:=os.MkdirAll(filepath.Dir(keyringPath),0700);err!=nil{return errors.Wrapf(err,"failed to create keyring directory for %s",keyringPath)};if err:=ioutil.WriteFile(keyringPath,[]byte(keyring),0600);err!=nil{return errors.Wrapf(err,"failed to write monitor keyring to %s",keyringPath)};return nil};func IsKeyringBase64Encoded(keyring string)bool{_,err:=base64.StdEncoding.DecodeString(keyring);if err!=nil{logger.Errorf("key is not base64 encoded. %v",err);return false};return true}