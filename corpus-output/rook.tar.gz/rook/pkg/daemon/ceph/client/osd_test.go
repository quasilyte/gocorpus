package client;import("fmt";"testing";"github.com/pkg/errors";"github.com/rook/rook/pkg/clusterd";"github.com/rook/rook/pkg/daemon/ceph/client/fake";"github.com/rook/rook/pkg/operator/ceph/version";exectest"github.com/rook/rook/pkg/util/exec/test";"github.com/stretchr/testify/assert");var(fakeOsdTree=`{
		"nodes": [
		  {
			"id": -3,
			"name": "minikube",
			"type": "host",
			"type_id": 1,
			"pool_weights": {},
			"children": [
			  2,
			  1,
			  0
			]
		  },
		  {
			"id": -2,
			"name": "minikube-2",
			"type": "host",
			"type_id": 1,
			"pool_weights": {},
			"children": [
			  3,
			  4,
			  5
			]
		  }
		]
	  }`;fakeOSdList=`[0,1,2]`);func TestHostTree(t *testing.T){executor:=&exectest.MockExecutor{};emptyTreeResult:=false;executor.MockExecuteCommandWithOutput=func(command string,args ...string)(string,error){logger.Infof("Command: %s %v",command,args);switch{case args[0]=="osd"&&args[1]=="tree":if emptyTreeResult{return `not a json`,nil};return fakeOsdTree,nil};return "",errors.Errorf("unexpected ceph command %q",args)};tree,err:=HostTree(&clusterd.Context{Executor:executor},AdminTestClusterInfo("mycluster"));assert.NoError(t,err);assert.Equal(t,2,len(tree.Nodes));assert.Equal(t,"minikube",tree.Nodes[0].Name);assert.Equal(t,3,len(tree.Nodes[0].Children));emptyTreeResult=true;tree,err=HostTree(&clusterd.Context{Executor:executor},AdminTestClusterInfo("mycluster"));assert.Error(t,err);assert.Equal(t,0,len(tree.Nodes))};func TestOsdListNum(t *testing.T){executor:=&exectest.MockExecutor{};emptyOsdListNumResult:=false;executor.MockExecuteCommandWithOutput=func(command string,args ...string)(string,error){logger.Infof("Command: %s %v",command,args);switch{case args[0]=="osd"&&args[1]=="ls":if emptyOsdListNumResult{return `not a json`,nil};return fakeOSdList,nil};return "",errors.Errorf("unexpected ceph command %q",args)};list,err:=OsdListNum(&clusterd.Context{Executor:executor},AdminTestClusterInfo("mycluster"));assert.NoError(t,err);assert.Equal(t,3,len(list));emptyOsdListNumResult=true;list,err=OsdListNum(&clusterd.Context{Executor:executor},AdminTestClusterInfo("mycluster"));assert.Error(t,err);assert.Equal(t,0,len(list))};func TestOSDDeviceClasses(t *testing.T){executor:=&exectest.MockExecutor{};executor.MockExecuteCommandWithOutput=func(command string,args ...string)(string,error){logger.Infof("Command: %s %v",command,args);switch{case args[0]=="osd"&&args[1]=="crush"&&args[2]=="get-device-class"&&len(args)>3:return fake.OSDDeviceClassOutput(args[3]),nil;default:return fake.OSDDeviceClassOutput(""),nil}};context:=&clusterd.Context{Executor:executor};clusterInfo:=AdminTestClusterInfo("mycluster");t.Run("device classes returned",func(t *testing.T){deviceClasses,err:=OSDDeviceClasses(context,clusterInfo,[]string{"0"});assert.NoError(t,err);assert.Equal(t,deviceClasses[0].DeviceClass,"hdd")});t.Run("error happened when no id provided",func(t *testing.T){_,err:=OSDDeviceClasses(context,clusterInfo,[]string{});assert.Error(t,err)})};func TestOSDOkToStop(t *testing.T){returnString:="";returnOkResult:=true;seenArgs:=[]string{};executor:=&exectest.MockExecutor{};executor.MockExecuteCommandWithOutput=func(command string,args ...string)(string,error){logger.Infof("Command: %s %v",command,args);switch{case args[0]=="osd"&&args[1]=="ok-to-stop":seenArgs=args;if returnOkResult{return returnString,nil};return returnString,errors.Errorf("Error EBUSY: unsafe to stop osd(s) at this time (50 PGs are or would become offline)")};panic(fmt.Sprintf("unexpected ceph command %q",args))};context:=&clusterd.Context{Executor:executor};clusterInfo:=AdminTestClusterInfo("mycluster");doSetup:=func(){seenArgs=[]string{}};t.Run("pacific output ok to stop",func(t *testing.T){doSetup();clusterInfo.CephVersion=version.Pacific;returnString=fake.OsdOkToStopOutput(1,[]int{1,2},true);returnOkResult=true;osds,err:=OSDOkToStop(context,clusterInfo,1,2);assert.NoError(t,err);assert.ElementsMatch(t,osds,[]int{1,2});assert.Equal(t,"1",seenArgs[2]);assert.Equal(t,"--max=2",seenArgs[3])});t.Run("pacific output not ok to stop",func(t *testing.T){doSetup();clusterInfo.CephVersion=version.Pacific;returnString=fake.OsdOkToStopOutput(3,[]int{},true);returnOkResult=false;_,err:=OSDOkToStop(context,clusterInfo,3,5);assert.Error(t,err);assert.Equal(t,"3",seenArgs[2]);assert.Equal(t,"--max=5",seenArgs[3])});t.Run("pacific handles maxReturned=0",func(t *testing.T){doSetup();clusterInfo.CephVersion=version.Pacific;returnString=fake.OsdOkToStopOutput(4,[]int{4,8},true);returnOkResult=true;osds,err:=OSDOkToStop(context,clusterInfo,4,0);assert.NoError(t,err);assert.ElementsMatch(t,osds,[]int{4,8});assert.Equal(t,"4",seenArgs[2]);assert.Equal(t,"--max=0",seenArgs[3])});t.Run("octopus output not ok to stop",func(t *testing.T){doSetup();clusterInfo.CephVersion=version.Octopus;returnString=fake.OsdOkToStopOutput(3,[]int{},false);returnOkResult=false;_,err:=OSDOkToStop(context,clusterInfo,3,5);assert.Error(t,err);assert.Equal(t,"3",seenArgs[2]);assert.NotContains(t,seenArgs[3],"--max")});t.Run("octopus output ok to stop",func(t *testing.T){doSetup();clusterInfo.CephVersion=version.Octopus;returnString=fake.OsdOkToStopOutput(50,[]int{50},false);returnOkResult=true;osds,err:=OSDOkToStop(context,clusterInfo,50,2);assert.NoError(t,err);assert.ElementsMatch(t,osds,[]int{50});assert.Equal(t,"50",seenArgs[2]);assert.NotContains(t,seenArgs[3],"--max")})}