package osd;import("encoding/json";"github.com/rook/rook/pkg/util/sys");const(bootstrapOSDKeyringTemplate=`
[client.bootstrap-osd]
	key = %s
	caps mon = "allow profile bootstrap-osd"
`);type Device struct{Name string`json:"name"`;NodeID string`json:"nodeId"`;Dir bool`json:"bool"`};type DesiredDevice struct{Name string;OSDsPerDevice int;MetadataDevice string;DatabaseSizeMB int;DeviceClass string;InitialWeight string;IsFilter bool;IsDevicePathFilter bool};type DeviceOsdMapping struct{Entries map[string]*DeviceOsdIDEntry};type DeviceOsdIDEntry struct{Data int;Metadata []int;Config DesiredDevice;PersistentDevicePaths []string;DeviceInfo *sys.LocalDisk};func(m *DeviceOsdMapping)String()string{b,_:=json.Marshal(m);return string(b)}