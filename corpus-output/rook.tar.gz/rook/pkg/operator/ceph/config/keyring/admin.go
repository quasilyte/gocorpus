package keyring;import("fmt";cephclient"github.com/rook/rook/pkg/daemon/ceph/client");const(adminKeyringResourceName="rook-ceph-admin";crashCollectorKeyringResourceName="rook-ceph-crash-collector";adminKeyringTemplate=`
[client.admin]
	key = %s
	caps mds = "allow *"
	caps mon = "allow *"
	caps osd = "allow *"
	caps mgr = "allow *"
`);type AdminStore struct{secretStore *SecretStore};func(s *SecretStore)Admin()*AdminStore{return &AdminStore{secretStore:s}};func(a *AdminStore)CreateOrUpdate(c *cephclient.ClusterInfo)error{keyring:=fmt.Sprintf(adminKeyringTemplate,c.CephCred.Secret);return a.secretStore.CreateOrUpdate(adminKeyringResourceName,keyring)}