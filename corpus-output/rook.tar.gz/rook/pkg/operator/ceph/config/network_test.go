package config;import("context";"fmt";"testing";networkv1"github.com/k8snetworkplumbingwg/network-attachment-definition-client/pkg/apis/k8s.cni.cncf.io/v1";fakenetclient"github.com/k8snetworkplumbingwg/network-attachment-definition-client/pkg/client/clientset/versioned/fake";"github.com/rook/rook/pkg/clusterd";"github.com/rook/rook/pkg/operator/k8sutil";testop"github.com/rook/rook/pkg/operator/test";"github.com/stretchr/testify/assert";metav1"k8s.io/apimachinery/pkg/apis/meta/v1");func TestGenerateNetworkSettings(t *testing.T){t.Run("no network definition exists",func(*testing.T){ns:="rook-ceph";clientset:=testop.New(t,1);ctx:=&clusterd.Context{Clientset:clientset,NetworkClient:fakenetclient.NewSimpleClientset().K8sCniCncfIoV1()};netSelector:=map[string]string{"public":"public-network-attach-def"};_,err:=generateNetworkSettings(ctx,ns,netSelector);assert.Error(t,err)});t.Run("only cluster network",func(*testing.T){netSelector:=map[string]string{"cluster":"cluster-network-attach-def"};networks:=[]networkv1.NetworkAttachmentDefinition{getClusterNetwork()};expectedNetworks:=[]Option{{Who:"global",Option:"cluster_network",Value:"172.18.0.0/16"}};ctxt:=context.TODO();ns:="rook-ceph";clientset:=testop.New(t,1);ctx:=&clusterd.Context{Clientset:clientset,NetworkClient:fakenetclient.NewSimpleClientset().K8sCniCncfIoV1()};for i:=range networks{_,err:=ctx.NetworkClient.NetworkAttachmentDefinitions(ns).Create(ctxt,&networks[i],metav1.CreateOptions{});assert.NoError(t,err)};cephNetwork,err:=generateNetworkSettings(ctx,ns,netSelector);assert.NoError(t,err);assert.ElementsMatch(t,cephNetwork,expectedNetworks,fmt.Sprintf("networks: %+v",cephNetwork))});t.Run("only public network",func(*testing.T){ctxt:=context.TODO();ns:="rook-ceph";clientset:=testop.New(t,1);ctx:=&clusterd.Context{Clientset:clientset,NetworkClient:fakenetclient.NewSimpleClientset().K8sCniCncfIoV1()};netSelector:=map[string]string{"public":"public-network-attach-def"};networks:=[]networkv1.NetworkAttachmentDefinition{getPublicNetwork()};expectedNetworks:=[]Option{{Who:"global",Option:"public_network",Value:"192.168.0.0/24"}};for i:=range networks{_,err:=ctx.NetworkClient.NetworkAttachmentDefinitions(ns).Create(ctxt,&networks[i],metav1.CreateOptions{});assert.NoError(t,err)};cephNetwork,err:=generateNetworkSettings(ctx,ns,netSelector);assert.NoError(t,err);assert.ElementsMatch(t,cephNetwork,expectedNetworks,fmt.Sprintf("networks: %+v",cephNetwork))});t.Run("public and cluster network",func(*testing.T){ctxt:=context.TODO();ns:="rook-ceph";clientset:=testop.New(t,1);ctx:=&clusterd.Context{Clientset:clientset,NetworkClient:fakenetclient.NewSimpleClientset().K8sCniCncfIoV1()};netSelector:=map[string]string{"public":"public-network-attach-def","cluster":"cluster-network-attach-def"};networks:=[]networkv1.NetworkAttachmentDefinition{getPublicNetwork(),getClusterNetwork()};expectedNetworks:=[]Option{{Who:"global",Option:"public_network",Value:"192.168.0.0/24"},{Who:"global",Option:"cluster_network",Value:"172.18.0.0/16"}};for i:=range networks{_,err:=ctx.NetworkClient.NetworkAttachmentDefinitions(ns).Create(ctxt,&networks[i],metav1.CreateOptions{});assert.NoError(t,err)};cephNetwork,err:=generateNetworkSettings(ctx,ns,netSelector);assert.NoError(t,err);assert.ElementsMatch(t,cephNetwork,expectedNetworks,fmt.Sprintf("networks: %+v",cephNetwork))})};func getPublicNetwork()networkv1.NetworkAttachmentDefinition{return networkv1.NetworkAttachmentDefinition{ObjectMeta:metav1.ObjectMeta{Name:"public-network-attach-def"},Spec:networkv1.NetworkAttachmentDefinitionSpec{Config:`{
				"cniVersion": "0.3.0",
				"type": "macvlan",
				"master": "eth2",
				"mode": "bridge",
				"ipam": {
				  "type": "host-local",
				  "subnet": "192.168.0.0/24",
				  "gateway": "172.18.8.1"
				}
			  }`}}};func getClusterNetwork()networkv1.NetworkAttachmentDefinition{return networkv1.NetworkAttachmentDefinition{ObjectMeta:metav1.ObjectMeta{Name:"cluster-network-attach-def"},Spec:networkv1.NetworkAttachmentDefinitionSpec{Config:`{
				"cniVersion": "0.3.0",
				"type": "macvlan",
				"master": "eth2",
				"mode": "bridge",
				"ipam": {
				  "type": "host-local",
				  "subnet": "172.18.0.0/16",
				  "gateway": "172.18.0.1"
				}
			  }`}}};func TestGetNetworkRange(t *testing.T){t.Run("simple host-local IPAM test",func(t *testing.T){ns:="rook-ceph";nad:=&networkv1.NetworkAttachmentDefinition{ObjectMeta:metav1.ObjectMeta{Name:"public-network-attach-def",Namespace:ns},Spec:networkv1.NetworkAttachmentDefinitionSpec{Config:`{
				"cniVersion": "0.3.0",
				"type": "macvlan",
				"master": "eth2",
				"mode": "bridge",
				"ipam": {
				  "type": "host-local",
				  "subnet": "",
				  "gateway": "172.18.8.1"
				}
			  }`}};netConfig,err:=k8sutil.GetNetworkAttachmentConfig(*nad);assert.NoError(t,err);networkRange:=getNetworkRange(netConfig);assert.Empty(t,networkRange);netConfig.Ipam.Type="host-local";netConfig.Ipam.Subnet="192.168.0.0/24";networkRange=getNetworkRange(netConfig);assert.Equal(t,"192.168.0.0/24",networkRange)});t.Run("advanced host-local IPAM test",func(t *testing.T){ns:="rook-ceph";nad:=&networkv1.NetworkAttachmentDefinition{ObjectMeta:metav1.ObjectMeta{Name:"public-network-attach-def",Namespace:ns},Spec:networkv1.NetworkAttachmentDefinitionSpec{Config:`{
	"ipam": {
		"type": "host-local",
		"ranges": [
			[
				{
					"subnet": "10.10.0.0/16",
					"rangeStart": "10.10.1.20",
					"rangeEnd": "10.10.3.50",
					"gateway": "10.10.0.254"
				},
				{
					"subnet": "172.16.5.0/24"
				}
			],
			[
				{
					"subnet": "3ffe:ffff:0:01ff::/64",
					"rangeStart": "3ffe:ffff:0:01ff::0010",
					"rangeEnd": "3ffe:ffff:0:01ff::0020"
				}
			]
		],
		"routes": [
			{ "dst": "0.0.0.0/0" },
			{ "dst": "192.168.0.0/16", "gw": "10.10.5.1" },
			{ "dst": "3ffe:ffff:0:01ff::1/64" }
		],
		"dataDir": "/run/my-orchestrator/container-ipam-state"
	}
}`}};netConfig,err:=k8sutil.GetNetworkAttachmentConfig(*nad);assert.NoError(t,err);networkRange:=getNetworkRange(netConfig);assert.Equal(t,"10.10.0.0/16,172.16.5.0/24,3ffe:ffff:0:01ff::/64",networkRange)});t.Run("advanced static IPAM test",func(t *testing.T){ns:="rook-ceph";nad:=&networkv1.NetworkAttachmentDefinition{ObjectMeta:metav1.ObjectMeta{Name:"public-network-attach-def",Namespace:ns},Spec:networkv1.NetworkAttachmentDefinitionSpec{Config:`{
	"ipam": {
		"type": "static",
		"addresses": [
			{
				"address": "10.10.0.1/24",
				"gateway": "10.10.0.254"
			},
			{
				"address": "3ffe:ffff:0:01ff::1/64",
				"gateway": "3ffe:ffff:0::1"
			}
		],
		"routes": [
			{ "dst": "0.0.0.0/0" },
			{ "dst": "192.168.0.0/16", "gw": "10.10.5.1" },
			{ "dst": "3ffe:ffff:0:01ff::1/64" }
		],
		"dns": {
			"nameservers" : ["8.8.8.8"],
			"domain": "example.com",
			"search": [ "example.com" ]
		}
	}
}`}};netConfig,err:=k8sutil.GetNetworkAttachmentConfig(*nad);assert.NoError(t,err);networkRange:=getNetworkRange(netConfig);assert.Equal(t,"10.10.0.1/24,3ffe:ffff:0:01ff::1/64",networkRange)});t.Run("advanced whereabouts IPAM test",func(t *testing.T){ns:="rook-ceph";nad:=&networkv1.NetworkAttachmentDefinition{ObjectMeta:metav1.ObjectMeta{Name:"public-network-attach-def",Namespace:ns},Spec:networkv1.NetworkAttachmentDefinitionSpec{Config:`{
      "cniVersion": "0.3.0",
      "name": "whereaboutsexample",
      "type": "macvlan",
      "master": "eth0",
      "mode": "bridge",
      "ipam": {
        "type": "whereabouts",
        "range": "192.168.2.225/28",
        "exclude": [
           "192.168.2.229/30",
           "192.168.2.236/32"
        ]
      }
}`}};netConfig,err:=k8sutil.GetNetworkAttachmentConfig(*nad);assert.NoError(t,err);networkRange:=getNetworkRange(netConfig);assert.Equal(t,"192.168.2.225/28",networkRange)})};func TestGetMultusNamespace(t *testing.T){namespace,nad:=GetMultusNamespace("multus-ns/public-nad");assert.Equal(t,"multus-ns",namespace);assert.Equal(t,"public-nad",nad);namespace,nad=GetMultusNamespace("public-nad");assert.Empty(t,namespace);assert.Equal(t,"public-nad",nad)}