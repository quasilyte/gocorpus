package csi;import("testing";"github.com/stretchr/testify/assert");var(testMinVersion=CephCSIVersion{3,3,0};testReleaseV330=CephCSIVersion{3,3,0};testReleaseV340=CephCSIVersion{3,4,0};testVersionUnsupported=CephCSIVersion{4,0,0});func TestIsAtLeast(t *testing.T){var version=CephCSIVersion{1,40,10};ret:=testMinVersion.isAtLeast(&version);assert.Equal(t,true,ret);ret=testMinVersion.isAtLeast(&testMinVersion);assert.Equal(t,true,ret);ret=testReleaseV330.isAtLeast(&testReleaseV330);assert.Equal(t,true,ret);ret=testReleaseV340.isAtLeast(&testReleaseV330);assert.Equal(t,true,ret)};func TestSupported(t *testing.T){AllowUnsupported=false;ret:=testMinVersion.Supported();assert.Equal(t,true,ret);ret=testVersionUnsupported.Supported();assert.Equal(t,false,ret);ret=testReleaseV330.Supported();assert.Equal(t,true,ret);ret=testReleaseV340.Supported();assert.Equal(t,true,ret)};func Test_extractCephCSIVersion(t *testing.T){expectedVersion:=CephCSIVersion{3,0,0};csiString:=[]byte(`Cephcsi Version: v3.0.0
		Git Commit: e58d537a07ca0184f67d33db85bf6b4911624b44
		Go Version: go1.12.15
		Compiler: gc
		Platform: linux/amd64
		`);version,err:=extractCephCSIVersion(string(csiString));assert.Equal(t,&expectedVersion,version);assert.Nil(t,err);csiString=[]byte(`Cephcsi Version: rubish
	Git Commit: e58d537a07ca0184f67d33db85bf6b4911624b44
	Go Version: go1.12.15
	Compiler: gc
	Platform: linux/amd64
	`);version,err=extractCephCSIVersion(string(csiString));assert.Nil(t,version);assert.Contains(t,err.Error(),"failed to parse version from")}