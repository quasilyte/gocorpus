package file;import("context";"os";"testing";"github.com/coreos/pkg/capnslog";cephv1"github.com/rook/rook/pkg/apis/ceph.rook.io/v1";rookclient"github.com/rook/rook/pkg/client/clientset/versioned/fake";"github.com/rook/rook/pkg/client/clientset/versioned/scheme";"github.com/rook/rook/pkg/clusterd";"github.com/rook/rook/pkg/daemon/ceph/client";"github.com/rook/rook/pkg/operator/ceph/version";"github.com/rook/rook/pkg/operator/k8sutil";"github.com/rook/rook/pkg/operator/test";exectest"github.com/rook/rook/pkg/util/exec/test";"github.com/stretchr/testify/assert";v1"k8s.io/api/core/v1";metav1"k8s.io/apimachinery/pkg/apis/meta/v1";"k8s.io/apimachinery/pkg/runtime";"k8s.io/apimachinery/pkg/types";"sigs.k8s.io/controller-runtime/pkg/client/fake";"sigs.k8s.io/controller-runtime/pkg/reconcile");const(fsGet=`{
		"mdsmap":{
		   "epoch":49,
		   "flags":50,
		   "ever_allowed_features":32,
		   "explicitly_allowed_features":32,
		   "created":"2020-03-17 13:17:43.743717",
		   "modified":"2020-03-17 15:22:51.020576",
		   "tableserver":0,
		   "root":0,
		   "session_timeout":60,
		   "session_autoclose":300,
		   "min_compat_client":"-1 (unspecified)",
		   "max_file_size":1099511627776,
		   "last_failure":0,
		   "last_failure_osd_epoch":0,
		   "compat":{
			  "compat":{

			  },
			  "ro_compat":{

			  },
			  "incompat":{
				 "feature_1":"base v0.20",
				 "feature_2":"client writeable ranges",
				 "feature_3":"default file layouts on dirs",
				 "feature_4":"dir inode in separate object",
				 "feature_5":"mds uses versioned encoding",
				 "feature_6":"dirfrag is stored in omap",
				 "feature_8":"no anchor table",
				 "feature_9":"file layout v2",
				 "feature_10":"snaprealm v2"
			  }
		   },
		   "max_mds":1,
		   "in":[
			  0
		   ],
		   "up":{
			  "mds_0":4463
		   },
		   "failed":[

		   ],
		   "damaged":[

		   ],
		   "stopped":[

		   ],
		   "info":{
			  "gid_4463":{
				 "gid":4463,
				 "name":"myfs-a",
				 "rank":0,
				 "incarnation":5,
				 "state":"up:active",
				 "state_seq":3,
				 "addr":"172.17.0.12:6801/175789278",
				 "addrs":{
					"addrvec":[
					   {
						  "type":"v2",
						  "addr":"172.17.0.12:6800",
						  "nonce":175789278
					   },
					   {
						  "type":"v1",
						  "addr":"172.17.0.12:6801",
						  "nonce":175789278
					   }
					]
				 },
				 "export_targets":[

				 ],
				 "features":4611087854031667199,
				 "flags":0
			  }
		   },
		   "data_pools":[
			  3
		   ],
		   "metadata_pool":2,
		   "enabled":true,
		   "fs_name":"myfs",
		   "balancer":"",
		   "standby_count_wanted":1
		},
		"id":1
	 }`;mdsCephAuthGetOrCreateKey=`{"key":"AQCvzWBeIV9lFRAAninzm+8XFxbSfTiPwoX50g=="}`;dummyVersionsRaw=`
	{
		"mon": {
			"ceph version 15.2.11 (000000000000000000000000000000) octopus (stable)": 3
		}
	}`);var(name="my-fs";namespace="rook-ceph");func TestCephFilesystemController(t *testing.T){ctx:=context.TODO();capnslog.SetGlobalLogLevel(capnslog.DEBUG);os.Setenv("ROOK_LOG_LEVEL","DEBUG");currentAndDesiredCephVersion=func(ctx context.Context,rookImage string,namespace string,jobName string,ownerInfo *k8sutil.OwnerInfo,context *clusterd.Context,cephClusterSpec *cephv1.ClusterSpec,clusterInfo *client.ClusterInfo)(*version.CephVersion,*version.CephVersion,error){return &version.Pacific,&version.Pacific,nil};fs:=&cephv1.CephFilesystem{ObjectMeta:metav1.ObjectMeta{Name:name,Namespace:namespace},Spec:cephv1.FilesystemSpec{MetadataServer:cephv1.MetadataServerSpec{ActiveCount:1}},TypeMeta:controllerTypeMeta};object:=[]runtime.Object{fs};executor:=&exectest.MockExecutor{MockExecuteCommandWithOutput:func(command string,args ...string)(string,error){if args[0]=="status"{return `{"fsid":"c47cac40-9bee-4d52-823b-ccd803ba5bfe","health":{"checks":{},"status":"HEALTH_ERR"},"pgmap":{"num_pgs":100,"pgs_by_state":[{"state_name":"active+clean","count":100}]}}`,nil};if args[0]=="versions"{return dummyVersionsRaw,nil};return "",nil}};clientset:=test.New(t,3);c:=&clusterd.Context{Executor:executor,RookClientset:rookclient.NewSimpleClientset(),Clientset:clientset};s:=scheme.Scheme;s.AddKnownTypes(cephv1.SchemeGroupVersion,&cephv1.CephObjectStore{});s.AddKnownTypes(cephv1.SchemeGroupVersion,&cephv1.CephCluster{});cl:=fake.NewClientBuilder().WithScheme(s).WithRuntimeObjects(object...).Build();r:=&ReconcileCephFilesystem{client:cl,scheme:s,context:c,fsContexts:make(map[string]*fsHealth),opManagerContext:context.TODO()};req:=reconcile.Request{NamespacedName:types.NamespacedName{Name:name,Namespace:namespace}};cephCluster:=&cephv1.CephCluster{ObjectMeta:metav1.ObjectMeta{Name:namespace,Namespace:namespace},Status:cephv1.ClusterStatus{Phase:"",CephStatus:&cephv1.CephStatus{Health:""}}};t.Run("error - no ceph cluster",func(t *testing.T){res,err:=r.Reconcile(ctx,req);assert.NoError(t,err);assert.True(t,res.Requeue)});t.Run("error - ceph cluster not ready",func(t *testing.T){object=append(object,cephCluster);cl=fake.NewClientBuilder().WithScheme(s).WithRuntimeObjects(object...).Build();r=&ReconcileCephFilesystem{client:cl,scheme:s,context:c,opManagerContext:context.TODO()};res,err:=r.Reconcile(ctx,req);assert.NoError(t,err);assert.True(t,res.Requeue);logger.Info("PHASE 2 DONE")});t.Run("success - ceph cluster ready and mds are running",func(t *testing.T){secrets:=map[string][]byte{"fsid":[]byte(name),"mon-secret":[]byte("monsecret"),"admin-secret":[]byte("adminsecret")};secret:=&v1.Secret{ObjectMeta:metav1.ObjectMeta{Name:"rook-ceph-mon",Namespace:namespace},Data:secrets,Type:k8sutil.RookType};_,err:=c.Clientset.CoreV1().Secrets(namespace).Create(ctx,secret,metav1.CreateOptions{});assert.NoError(t,err);cephCluster.Status.Phase=k8sutil.ReadyStatus;cephCluster.Status.CephStatus.Health="HEALTH_OK";cl=fake.NewClientBuilder().WithScheme(s).WithRuntimeObjects(object...).Build();executor=&exectest.MockExecutor{MockExecuteCommandWithOutput:func(command string,args ...string)(string,error){if args[0]=="status"{return `{"fsid":"c47cac40-9bee-4d52-823b-ccd803ba5bfe","health":{"checks":{},"status":"HEALTH_OK"},"pgmap":{"num_pgs":100,"pgs_by_state":[{"state_name":"active+clean","count":100}]}}`,nil};if args[0]=="fs"&&args[1]=="get"{return fsGet,nil};if args[0]=="auth"&&args[1]=="get-or-create-key"{return mdsCephAuthGetOrCreateKey,nil};if args[0]=="versions"{return dummyVersionsRaw,nil};return "",nil}};c.Executor=executor;r=&ReconcileCephFilesystem{client:cl,scheme:s,context:c,fsContexts:make(map[string]*fsHealth),opManagerContext:context.TODO()};res,err:=r.Reconcile(ctx,req);assert.NoError(t,err);assert.False(t,res.Requeue);err=r.client.Get(context.TODO(),req.NamespacedName,fs);assert.NoError(t,err);assert.Equal(t,cephv1.ConditionType("Ready"),fs.Status.Phase,fs)})}