package mirror;import("fmt";"github.com/rook/rook/pkg/operator/ceph/config";"github.com/rook/rook/pkg/operator/ceph/config/keyring";"github.com/rook/rook/pkg/operator/ceph/version";"github.com/rook/rook/pkg/operator/k8sutil");const(keyringTemplate=`
[client.fs-mirror]
	key = %s
	caps mon = "allow profile cephfs-mirror"
	caps mgr = "allow r"
	caps mds = "allow r"
	caps osd = "'allow rw tag cephfs metadata=*, allow r tag cephfs data=*'"
`;user="client.fs-mirror";userID="fs-mirror");var(PeerAdditionMinVersion=version.CephVersion{Major:16,Minor:2,Extra:5});type daemonConfig struct{ResourceName string;DataPathMap *config.DataPathMap;ownerInfo *k8sutil.OwnerInfo};func(r *ReconcileFilesystemMirror)generateKeyring(daemonConfig *daemonConfig)(string,error){access:=[]string{"mon","allow profile cephfs-mirror","mgr","allow r","mds","allow r","osd","allow rw tag cephfs metadata=*, allow r tag cephfs data=*"};s:=keyring.GetSecretStore(r.context,r.clusterInfo,daemonConfig.ownerInfo);key,err:=s.GenerateKey(user,access);if err!=nil{return "",err};keyring:=fmt.Sprintf(keyringTemplate,key);return keyring,s.CreateOrUpdate(daemonConfig.ResourceName,keyring)}