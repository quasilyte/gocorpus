package tpl;import(qtio422016"io";qt422016"github.com/valyala/quicktemplate");var(_=qtio422016.Copy;_=qt422016.AcquireByteBuffer);func StreamHeader(qw422016 *qt422016.Writer,title string,pages []NavItem){qw422016.N().S(`
<!DOCTYPE html>
<html lang="en">
<head>
    <title>vmalert`);if title!=""{qw422016.N().S(` - `);qw422016.E().S(title)};qw422016.N().S(`</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body{
          min-height: 75rem;
          padding-top: 4.5rem;
        }
        pre {
            overflow: scroll;
            max-width: 600px;
            min-height: 30px;
        }
        .group-heading {
            cursor: pointer;
            padding: 5px;
            margin-top: 5px;
            position: relative;
        }
        .group-heading .anchor {
            position:absolute;
            top:-60px;
        }
        .group-heading span {
            float: right;
            margin-left: 5px;
            margin-right: 5px;
        }
         .group-heading:hover {
            background-color: #f8f9fa!important;
        }
        .table .error-cell{
            word-break: break-word;
        }
    </style>
</head>
<body>
    `);StreamPrintNavItems(qw422016,title,pages);qw422016.N().S(`
    <main class="px-2">
`)};func WriteHeader(qq422016 qtio422016.Writer,title string,pages []NavItem){qw422016:=qt422016.AcquireWriter(qq422016);StreamHeader(qw422016,title,pages);qt422016.ReleaseWriter(qw422016)};func Header(title string,pages []NavItem)string{qb422016:=qt422016.AcquireByteBuffer();WriteHeader(qb422016,title,pages);qs422016:=string(qb422016.B);qt422016.ReleaseByteBuffer(qb422016);return qs422016}