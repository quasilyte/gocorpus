package tpl;import(qtio422016"io";qt422016"github.com/valyala/quicktemplate");var(_=qtio422016.Copy;_=qt422016.AcquireByteBuffer);type NavItem struct{Name string;Url string};func StreamPrintNavItems(qw422016 *qt422016.Writer,current string,items []NavItem){qw422016.N().S(`
<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
            `);for _,item:=range items{qw422016.N().S(`
                <li class="nav-item">
                    <a class="nav-link`);if current==item.Name{qw422016.N().S(` active`)};qw422016.N().S(`" href="`);qw422016.E().S(item.Url);qw422016.N().S(`">
                        `);qw422016.E().S(item.Name);qw422016.N().S(`
                    </a>
                </li>
            `)};qw422016.N().S(`
        </ul>
  </div>
</nav>
`)};func WritePrintNavItems(qq422016 qtio422016.Writer,current string,items []NavItem){qw422016:=qt422016.AcquireWriter(qq422016);StreamPrintNavItems(qw422016,current,items);qt422016.ReleaseWriter(qw422016)};func PrintNavItems(current string,items []NavItem)string{qb422016:=qt422016.AcquireByteBuffer();WritePrintNavItems(qb422016,current,items);qs422016:=string(qb422016.B);qt422016.ReleaseByteBuffer(qb422016);return qs422016}