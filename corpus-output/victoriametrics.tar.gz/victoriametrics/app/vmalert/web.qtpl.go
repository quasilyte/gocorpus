package main;import("sort";"time";"github.com/VictoriaMetrics/VictoriaMetrics/app/vmalert/tpl");import(qtio422016"io";qt422016"github.com/valyala/quicktemplate");var(_=qtio422016.Copy;_=qt422016.AcquireByteBuffer);func StreamWelcome(qw422016 *qt422016.Writer){qw422016.N().S(`
    `);tpl.StreamHeader(qw422016,"vmalert",navItems);qw422016.N().S(`
    <p>
        API:<br>
        `);for _,p:=range apiLinks{qw422016.N().S(`
            `);p,doc:=p[0],p[1];qw422016.N().S(`
        	<a href="`);qw422016.E().S(p);qw422016.N().S(`">`);qw422016.E().S(p);qw422016.N().S(`</a> - `);qw422016.E().S(doc);qw422016.N().S(`<br/>
        `)};qw422016.N().S(`
    </p>
    `);tpl.StreamFooter(qw422016);qw422016.N().S(`
`)};func WriteWelcome(qq422016 qtio422016.Writer){qw422016:=qt422016.AcquireWriter(qq422016);StreamWelcome(qw422016);qt422016.ReleaseWriter(qw422016)};func Welcome()string{qb422016:=qt422016.AcquireByteBuffer();WriteWelcome(qb422016);qs422016:=string(qb422016.B);qt422016.ReleaseByteBuffer(qb422016);return qs422016};func StreamListGroups(qw422016 *qt422016.Writer,groups []APIGroup){qw422016.N().S(`
    `);tpl.StreamHeader(qw422016,"Groups",navItems);qw422016.N().S(`
    `);if len(groups)>0{qw422016.N().S(`
        `);rOk:=make(map[string]int);rNotOk:=make(map[string]int);for _,g:=range groups{for _,r:=range g.AlertingRules{if r.LastError!=""{rNotOk[g.Name]++}else{rOk[g.Name]++}};for _,r:=range g.RecordingRules{if r.LastError!=""{rNotOk[g.Name]++}else{rOk[g.Name]++}}};qw422016.N().S(`
         <a class="btn btn-primary" role="button" onclick="collapseAll()">Collapse All</a>
         <a class="btn btn-primary" role="button" onclick="expandAll()">Expand All</a>
        `);for _,g:=range groups{qw422016.N().S(`
              <div class="group-heading`);if rNotOk[g.Name]>0{qw422016.N().S(` alert-danger`)};qw422016.N().S(`"  data-bs-target="rules-`);qw422016.E().S(g.ID);qw422016.N().S(`">
                <span class="anchor" id="group-`);qw422016.E().S(g.ID);qw422016.N().S(`"></span>
                <a href="#group-`);qw422016.E().S(g.ID);qw422016.N().S(`">`);qw422016.E().S(g.Name);if g.Type!="prometheus"{qw422016.N().S(` (`);qw422016.E().S(g.Type);qw422016.N().S(`)`)};qw422016.N().S(` (every `);qw422016.E().S(g.Interval);qw422016.N().S(`)</a>
                 `);if rNotOk[g.Name]>0{qw422016.N().S(`<span class="badge bg-danger" title="Number of rules with status Error">`);qw422016.N().D(rNotOk[g.Name]);qw422016.N().S(`</span> `)};qw422016.N().S(`
                <span class="badge bg-success" title="Number of rules withs status Ok">`);qw422016.N().D(rOk[g.Name]);qw422016.N().S(`</span>
                <p class="fs-6 fw-lighter">`);qw422016.E().S(g.File);qw422016.N().S(`</p>
                `);if len(g.Params)>0{qw422016.N().S(`
                    <div class="fs-6 fw-lighter">Extra params
                    `);for _,param:=range g.Params{qw422016.N().S(`
                            <span class="float-left badge bg-primary">`);qw422016.E().S(param);qw422016.N().S(`</span>
                    `)};qw422016.N().S(`
                    </div>
                `)};qw422016.N().S(`
            </div>
            <div class="collapse" id="rules-`);qw422016.E().S(g.ID);qw422016.N().S(`">
                <table class="table table-striped table-hover table-sm">
                    <thead>
                        <tr>
                            <th scope="col">Rule</th>
                            <th scope="col" title="Shows if rule's execution ended with error">Error</th>
                            <th scope="col" title="How many samples were produced by the rule">Samples</th>
                            <th scope="col" title="How many seconds ago rule was executed">Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                    `);for _,ar:=range g.AlertingRules{qw422016.N().S(`
                        <tr`);if ar.LastError!=""{qw422016.N().S(` class="alert-danger"`)};qw422016.N().S(`>
                            <td>
                                <b>alert:</b> `);qw422016.E().S(ar.Name);qw422016.N().S(` (for: `);qw422016.E().V(ar.For);qw422016.N().S(`)<br>
                                <code><pre>`);qw422016.E().S(ar.Expression);qw422016.N().S(`</pre></code><br>
                                `);if len(ar.Labels)>0{qw422016.N().S(` <b>Labels:</b>`)};qw422016.N().S(`
                                `);for k,v:=range ar.Labels{qw422016.N().S(`
                                        <span class="ms-1 badge bg-primary">`);qw422016.E().S(k);qw422016.N().S(`=`);qw422016.E().S(v);qw422016.N().S(`</span>
                                `)};qw422016.N().S(`
                            </td>
                            <td><div class="error-cell">`);qw422016.E().S(ar.LastError);qw422016.N().S(`</div></td>
                            <td>`);qw422016.N().D(ar.LastSamples);qw422016.N().S(`</td>
                            <td>`);qw422016.N().FPrec(time.Since(ar.LastExec).Seconds(),3);qw422016.N().S(`s ago</td>
                        </tr>
                    `)};qw422016.N().S(`
                    `);for _,rr:=range g.RecordingRules{qw422016.N().S(`
                        <tr>
                            <td>
                                <b>record:</b> `);qw422016.E().S(rr.Name);qw422016.N().S(`<br>
                                <code><pre>`);qw422016.E().S(rr.Expression);qw422016.N().S(`</pre></code>
                                `);if len(rr.Labels)>0{qw422016.N().S(` <b>Labels:</b>`)};qw422016.N().S(`
                                `);for k,v:=range rr.Labels{qw422016.N().S(`
                                        <span class="ms-1 badge bg-primary">`);qw422016.E().S(k);qw422016.N().S(`=`);qw422016.E().S(v);qw422016.N().S(`</span>
                                `)};qw422016.N().S(`
                            </td>
                            <td><div class="error-cell">`);qw422016.E().S(rr.LastError);qw422016.N().S(`</div></td>
                            <td>`);qw422016.N().D(rr.LastSamples);qw422016.N().S(`</td>
                            <td>`);qw422016.N().FPrec(time.Since(rr.LastExec).Seconds(),3);qw422016.N().S(`s ago</td>
                        </tr>
                    `)};qw422016.N().S(`
                 </tbody>
                </table>
            </div>
        `)};qw422016.N().S(`

    `)}else{qw422016.N().S(`
        <div>
            <p>No items...</p>
        </div>
    `)};qw422016.N().S(`

    `);tpl.StreamFooter(qw422016);qw422016.N().S(`

`)};func WriteListGroups(qq422016 qtio422016.Writer,groups []APIGroup){qw422016:=qt422016.AcquireWriter(qq422016);StreamListGroups(qw422016,groups);qt422016.ReleaseWriter(qw422016)};func ListGroups(groups []APIGroup)string{qb422016:=qt422016.AcquireByteBuffer();WriteListGroups(qb422016,groups);qs422016:=string(qb422016.B);qt422016.ReleaseByteBuffer(qb422016);return qs422016};func StreamListAlerts(qw422016 *qt422016.Writer,groupAlerts []GroupAlerts){qw422016.N().S(`
    `);tpl.StreamHeader(qw422016,"Alerts",navItems);qw422016.N().S(`
    `);if len(groupAlerts)>0{qw422016.N().S(`
         <a class="btn btn-primary" role="button" onclick="collapseAll()">Collapse All</a>
         <a class="btn btn-primary" role="button" onclick="expandAll()">Expand All</a>
         `);for _,ga:=range groupAlerts{qw422016.N().S(`
            `);g:=ga.Group;qw422016.N().S(`
            <div class="group-heading alert-danger" data-bs-target="rules-`);qw422016.E().S(g.ID);qw422016.N().S(`">
                <span class="anchor" id="group-`);qw422016.E().S(g.ID);qw422016.N().S(`"></span>
                <a href="#group-`);qw422016.E().S(g.ID);qw422016.N().S(`">`);qw422016.E().S(g.Name);if g.Type!="prometheus"{qw422016.N().S(` (`);qw422016.E().S(g.Type);qw422016.N().S(`)`)};qw422016.N().S(`</a>
                <span class="badge bg-danger" title="Number of active alerts">`);qw422016.N().D(len(ga.Alerts));qw422016.N().S(`</span>
                <br>
                <p class="fs-6 fw-lighter">`);qw422016.E().S(g.File);qw422016.N().S(`</p>
            </div>
            `);var keys []string;alertsByRule:=make(map[string][]*APIAlert);for _,alert:=range ga.Alerts{if len(alertsByRule[alert.RuleID])<1{keys=append(keys,alert.RuleID)};alertsByRule[alert.RuleID]=append(alertsByRule[alert.RuleID],alert)};sort.Strings(keys);qw422016.N().S(`
            <div class="collapse" id="rules-`);qw422016.E().S(g.ID);qw422016.N().S(`">
                `);for _,ruleID:=range keys{qw422016.N().S(`
                    `);defaultAR:=alertsByRule[ruleID][0];var labelKeys []string;for k:=range defaultAR.Labels{labelKeys=append(labelKeys,k)};sort.Strings(labelKeys);qw422016.N().S(`
                    <br>
                    <b>alert:</b> `);qw422016.E().S(defaultAR.Name);qw422016.N().S(` (`);qw422016.N().D(len(alertsByRule[ruleID]));qw422016.N().S(`)
                     | <span><a target="_blank" href="`);qw422016.E().S(defaultAR.SourceLink);qw422016.N().S(`">Source</a></span>
                    <br>
                    <b>expr:</b><code><pre>`);qw422016.E().S(defaultAR.Expression);qw422016.N().S(`</pre></code>
                    <table class="table table-striped table-hover table-sm">
                        <thead>
                            <tr>
                                <th scope="col">Labels</th>
                                <th scope="col">State</th>
                                <th scope="col">Active at</th>
                                <th scope="col">Value</th>
                                <th scope="col">Link</th>
                            </tr>
                        </thead>
                        <tbody>
                        `);for _,ar:=range alertsByRule[ruleID]{qw422016.N().S(`
                            <tr>
                                <td>
                                    `);for _,k:=range labelKeys{qw422016.N().S(`
                                        <span class="ms-1 badge bg-primary">`);qw422016.E().S(k);qw422016.N().S(`=`);qw422016.E().S(ar.Labels[k]);qw422016.N().S(`</span>
                                    `)};qw422016.N().S(`
                                </td>
                                <td>`);streambadgeState(qw422016,ar.State);qw422016.N().S(`</td>
                                <td>
                                    `);qw422016.E().S(ar.ActiveAt.Format("2006-01-02T15:04:05Z07:00"));qw422016.N().S(`
                                    `);if ar.Restored{streambadgeRestored(qw422016)};qw422016.N().S(`
                                </td>
                                <td>`);qw422016.E().S(ar.Value);qw422016.N().S(`</td>
                                <td>
                                    <a href="/`);qw422016.E().S(g.ID);qw422016.N().S(`/`);qw422016.E().S(ar.ID);qw422016.N().S(`/status">Details</a>
                                </td>
                            </tr>
                        `)};qw422016.N().S(`
                     </tbody>
                    </table>
                `)};qw422016.N().S(`
            </div>
            <br>
        `)};qw422016.N().S(`

    `)}else{qw422016.N().S(`
        <div>
            <p>No items...</p>
        </div>
    `)};qw422016.N().S(`

    `);tpl.StreamFooter(qw422016);qw422016.N().S(`

`)};func WriteListAlerts(qq422016 qtio422016.Writer,groupAlerts []GroupAlerts){qw422016:=qt422016.AcquireWriter(qq422016);StreamListAlerts(qw422016,groupAlerts);qt422016.ReleaseWriter(qw422016)};func ListAlerts(groupAlerts []GroupAlerts)string{qb422016:=qt422016.AcquireByteBuffer();WriteListAlerts(qb422016,groupAlerts);qs422016:=string(qb422016.B);qt422016.ReleaseByteBuffer(qb422016);return qs422016};func StreamAlert(qw422016 *qt422016.Writer,alert *APIAlert){qw422016.N().S(`
    `);tpl.StreamHeader(qw422016,"",navItems);qw422016.N().S(`
    `);var labelKeys []string;for k:=range alert.Labels{labelKeys=append(labelKeys,k)};sort.Strings(labelKeys);var annotationKeys []string;for k:=range alert.Annotations{annotationKeys=append(annotationKeys,k)};sort.Strings(annotationKeys);qw422016.N().S(`
    <div class="display-6 pb-3 mb-3">`);qw422016.E().S(alert.Name);qw422016.N().S(`<span class="ms-2 badge `);if alert.State=="firing"{qw422016.N().S(`bg-danger`)}else{qw422016.N().S(` bg-warning text-dark`)};qw422016.N().S(`">`);qw422016.E().S(alert.State);qw422016.N().S(`</span></div>
    <div class="container border-bottom p-2">
      <div class="row">
        <div class="col-2">
          Active at
        </div>
        <div class="col">
          `);qw422016.E().S(alert.ActiveAt.Format("2006-01-02T15:04:05Z07:00"));qw422016.N().S(`
        </div>
      </div>
      </div>
    <div class="container border-bottom p-2">
      <div class="row">
        <div class="col-2">
          Expr
        </div>
        <div class="col">
          <code><pre>`);qw422016.E().S(alert.Expression);qw422016.N().S(`</pre></code>
        </div>
      </div>
    </div>
    <div class="container border-bottom p-2">
      <div class="row">
        <div class="col-2">
          Labels
        </div>
        <div class="col">
           `);for _,k:=range labelKeys{qw422016.N().S(`
                <span class="m-1 badge bg-primary">`);qw422016.E().S(k);qw422016.N().S(`=`);qw422016.E().S(alert.Labels[k]);qw422016.N().S(`</span>
          `)};qw422016.N().S(`
        </div>
      </div>
    </div>
    <div class="container border-bottom p-2">
      <div class="row">
        <div class="col-2">
          Annotations
        </div>
        <div class="col">
           `);for _,k:=range annotationKeys{qw422016.N().S(`
                <b>`);qw422016.E().S(k);qw422016.N().S(`:</b><br>
                <p>`);qw422016.E().S(alert.Annotations[k]);qw422016.N().S(`</p>
          `)};qw422016.N().S(`
        </div>
      </div>
    </div>
    <div class="container border-bottom p-2">
      <div class="row">
        <div class="col-2">
          Group
        </div>
        <div class="col">
           <a target="_blank" href="/groups#group-`);qw422016.E().S(alert.GroupID);qw422016.N().S(`">`);qw422016.E().S(alert.GroupID);qw422016.N().S(`</a>
        </div>
      </div>
    </div>
     <div class="container border-bottom p-2">
      <div class="row">
        <div class="col-2">
          Source link
        </div>
        <div class="col">
           <a target="_blank" href="`);qw422016.E().S(alert.SourceLink);qw422016.N().S(`">Link</a>
        </div>
      </div>
    </div>
    `);tpl.StreamFooter(qw422016);qw422016.N().S(`

`)};func WriteAlert(qq422016 qtio422016.Writer,alert *APIAlert){qw422016:=qt422016.AcquireWriter(qq422016);StreamAlert(qw422016,alert);qt422016.ReleaseWriter(qw422016)};func Alert(alert *APIAlert)string{qb422016:=qt422016.AcquireByteBuffer();WriteAlert(qb422016,alert);qs422016:=string(qb422016.B);qt422016.ReleaseByteBuffer(qb422016);return qs422016};func streambadgeState(qw422016 *qt422016.Writer,state string){qw422016.N().S(`
`);badgeClass:="bg-warning text-dark";if state=="firing"{badgeClass="bg-danger"};qw422016.N().S(`
<span class="badge `);qw422016.E().S(badgeClass);qw422016.N().S(`">`);qw422016.E().S(state);qw422016.N().S(`</span>
`)};func writebadgeState(qq422016 qtio422016.Writer,state string){qw422016:=qt422016.AcquireWriter(qq422016);streambadgeState(qw422016,state);qt422016.ReleaseWriter(qw422016)};func badgeState(state string)string{qb422016:=qt422016.AcquireByteBuffer();writebadgeState(qb422016,state);qs422016:=string(qb422016.B);qt422016.ReleaseByteBuffer(qb422016);return qs422016};func streambadgeRestored(qw422016 *qt422016.Writer){qw422016.N().S(`
<span class="badge bg-warning text-dark" title="Alert state was restored after the service restart from remote storage">restored</span>
`)};func writebadgeRestored(qq422016 qtio422016.Writer){qw422016:=qt422016.AcquireWriter(qq422016);streambadgeRestored(qw422016);qt422016.ReleaseWriter(qw422016)};func badgeRestored()string{qb422016:=qt422016.AcquireByteBuffer();writebadgeRestored(qb422016);qs422016:=string(qb422016.B);qt422016.ReleaseByteBuffer(qb422016);return qs422016}