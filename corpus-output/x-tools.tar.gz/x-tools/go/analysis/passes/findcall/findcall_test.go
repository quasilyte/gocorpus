package findcall_test;import("testing";"golang.org/x/tools/go/analysis/analysistest";"golang.org/x/tools/go/analysis/passes/findcall");func init(){findcall.Analyzer.Flags.Set("name","println")};func TestFromStringLiterals(t *testing.T){for _,test:=range [...]struct{desc string;pkgpath string;files map[string]string}{{desc:"SimpleTest",pkgpath:"main",files:map[string]string{"main/main.go":`package main // want package:"found"

func main() {
	println("hello") // want "call of println"
	print("goodbye") // not a call of println
}

func println(s string) {} // want println:"found"`}}}{t.Run(test.desc,func(t *testing.T){dir,cleanup,err:=analysistest.WriteFiles(test.files);if err!=nil{t.Fatal(err)};defer cleanup();analysistest.Run(t,dir,findcall.Analyzer,test.pkgpath)})}};func TestFromFileSystem(t *testing.T){testdata:=analysistest.TestData();analysistest.RunWithSuggestedFixes(t,testdata,findcall.Analyzer,"a")}