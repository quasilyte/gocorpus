package nilness;import("fmt";"go/token";"go/types";"golang.org/x/tools/go/analysis";"golang.org/x/tools/go/analysis/passes/buildssa";"golang.org/x/tools/go/ssa");const Doc=`check for redundant or impossible nil comparisons

The nilness checker inspects the control-flow graph of each function in
a package and reports nil pointer dereferences, degenerate nil
pointers, and panics with nil values. A degenerate comparison is of the form
x==nil or x!=nil where x is statically known to be nil or non-nil. These are
often a mistake, especially in control flow related to errors. Panics with nil
values are checked because they are not detectable by

	if r := recover(); r != nil {

This check reports conditions such as:

	if f == nil { // impossible condition (f is a function)
	}

and:

	p := &v
	...
	if p != nil { // tautological condition
	}

and:

	if p == nil {
		print(*p) // nil dereference
	}

and:

	if p == nil {
		panic(p)
	}
`;var Analyzer=&analysis.Analyzer{Name:"nilness",Doc:Doc,Run:run,Requires:[]*analysis.Analyzer{buildssa.Analyzer}};func run(pass *analysis.Pass)(interface{},error){ssainput:=pass.ResultOf[buildssa.Analyzer].(*buildssa.SSA);for _,fn:=range ssainput.SrcFuncs{runFunc(pass,fn)};return nil,nil};func runFunc(pass *analysis.Pass,fn *ssa.Function){reportf:=func(category string,pos token.Pos,format string,args ...interface{}){pass.Report(analysis.Diagnostic{Pos:pos,Category:category,Message:fmt.Sprintf(format,args)})};notNil:=func(stack []fact,instr ssa.Instruction,v ssa.Value,descr string){if nilnessOf(stack,v)==isnil{reportf("nilderef",instr.Pos(),"nil dereference in "+descr)}};seen:=make([]bool,len(fn.Blocks));var visit func(b *ssa.BasicBlock,stack []fact);visit=func(b *ssa.BasicBlock,stack []fact){if seen[b.Index]{return };seen[b.Index]=true;for _,instr:=range b.Instrs{switch instr:=instr.(type){case ssa.CallInstruction:notNil(stack,instr,instr.Common().Value,instr.Common().Description());case *ssa.FieldAddr:notNil(stack,instr,instr.X,"field selection");case *ssa.IndexAddr:notNil(stack,instr,instr.X,"index operation");case *ssa.MapUpdate:notNil(stack,instr,instr.Map,"map update");case *ssa.Slice:if _,ok:=instr.X.Type().Underlying().(*types.Pointer);ok{notNil(stack,instr,instr.X,"slice operation")};case *ssa.Store:notNil(stack,instr,instr.Addr,"store");case *ssa.TypeAssert:if !instr.CommaOk{notNil(stack,instr,instr.X,"type assertion")};case *ssa.UnOp:if instr.Op==token.MUL{notNil(stack,instr,instr.X,"load")}}};for _,instr:=range b.Instrs{switch instr:=instr.(type){case *ssa.Panic:if nilnessOf(stack,instr.X)==isnil{reportf("nilpanic",instr.Pos(),"panic with nil value")};case *ssa.SliceToArrayPointer:nn:=nilnessOf(stack,instr.X);if nn==isnil&&slice2ArrayPtrLen(instr)>0{reportf("conversionpanic",instr.Pos(),"nil slice being cast to an array of len > 0 will always panic")}}};if binop,tsucc,fsucc:=eq(b);binop!=nil{xnil:=nilnessOf(stack,binop.X);ynil:=nilnessOf(stack,binop.Y);if ynil!=unknown&&xnil!=unknown&&(xnil==isnil||ynil==isnil){var adj string;if (xnil==ynil)==(binop.Op==token.EQL){adj="tautological"};reportf("cond",binop.Pos(),"%s condition: %s %s %s",adj,xnil,binop.Op,ynil);var skip *ssa.BasicBlock;if xnil==ynil{skip=fsucc};for _,d:=range b.Dominees(){if d==skip&&len(d.Preds)==1{continue};visit(d,stack)};return };if xnil==isnil||ynil==isnil{var newFacts facts;if xnil==isnil{newFacts=expandFacts(fact{binop.Y,isnil})};for _,d:=range b.Dominees(){s:=stack;if len(d.Preds)==1{if d==tsucc{s=append(s,newFacts)}};visit(d,s)};return }};for _,d:=range b.Dominees(){visit(d,stack)}};if fn.Blocks!=nil{visit(fn.Blocks[0],make([]fact,0,20))}};type fact struct{value ssa.Value;nilness nilness};func(f fact)negate()fact{return fact{f.value,-f.nilness}};type nilness int;const(isnonnil=-1;unknown nilness=0;isnil=1);var nilnessStrings=[]string{"non-nil","unknown","nil"};func(n nilness)String()string{return nilnessStrings[n+1]};func nilnessOf(stack []fact,v ssa.Value)nilness{switch v:=v.(type){case *ssa.ChangeInterface:if underlying:=nilnessOf(stack,v.X);underlying!=unknown{return underlying};case *ssa.SliceToArrayPointer:nn:=nilnessOf(stack,v.X);if slice2ArrayPtrLen(v)>0{if nn==isnil{return unknown};return isnonnil};if nn!=unknown{return nn}};switch v:=v.(type){case *ssa.Alloc,*ssa.FieldAddr,*ssa.FreeVar,*ssa.Function,*ssa.Global,*ssa.IndexAddr,*ssa.MakeChan,*ssa.MakeClosure,*ssa.MakeInterface,*ssa.MakeMap,*ssa.MakeSlice:return isnonnil;case *ssa.Const:if v.IsNil(){return isnil}};for _,f:=range stack{if f.value==v{return f.nilness}};return unknown};func slice2ArrayPtrLen(v *ssa.SliceToArrayPointer)int64{return v.Type().(*types.Pointer).Elem().Underlying().(*types.Array).Len()};func eq(b *ssa.BasicBlock)(op *ssa.BinOp,tsucc,fsucc *ssa.BasicBlock){if If,ok:=b.Instrs[len(b.Instrs)-1].(*ssa.If);ok{if binop,ok:=If.Cond.(*ssa.BinOp);ok{switch binop.Op{case token.EQL:return binop,b.Succs[0],b.Succs[1];case token.NEQ:return binop,b.Succs[1],b.Succs[0]}}};return nil,nil,nil};func expandFacts(f fact)[]fact{ff:=[]fact{f};Loop:for{switch v:=f.value.(type){case *ssa.ChangeInterface:f=fact{v.X,f.nilness};ff=append(ff,f);default:break Loop}};return ff};type facts []fact;func(ff facts)negate()facts{nn:=make([]fact,len(ff));for i,f:=range ff{nn[i]=f.negate()};return nn}