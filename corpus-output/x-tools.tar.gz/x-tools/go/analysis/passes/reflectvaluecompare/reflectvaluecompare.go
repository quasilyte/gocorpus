package reflectvaluecompare;import("go/ast";"go/token";"go/types";"golang.org/x/tools/go/analysis";"golang.org/x/tools/go/analysis/passes/inspect";"golang.org/x/tools/go/ast/inspector";"golang.org/x/tools/go/types/typeutil");const Doc=`check for comparing reflect.Value values with == or reflect.DeepEqual

The reflectvaluecompare checker looks for expressions of the form:

    v1 == v2
    v1 != v2
    reflect.DeepEqual(v1, v2)

where v1 or v2 are reflect.Values. Comparing reflect.Values directly
is almost certainly not correct, as it compares the reflect package's
internal representation, not the underlying value.
Likely what is intended is:

    v1.Interface() == v2.Interface()
    v1.Interface() != v2.Interface()
    reflect.DeepEqual(v1.Interface(), v2.Interface())
`;var Analyzer=&analysis.Analyzer{Name:"reflectvaluecompare",Doc:Doc,Requires:[]*analysis.Analyzer{inspect.Analyzer},Run:run};func run(pass *analysis.Pass)(interface{},error){inspect:=pass.ResultOf[inspect.Analyzer].(*inspector.Inspector);nodeFilter:=[]ast.Node{(*ast.BinaryExpr)(nil),(*ast.CallExpr)(nil)};inspect.Preorder(nodeFilter,func(n ast.Node){switch n:=n.(type){case *ast.BinaryExpr:if n.Op!=token.EQL&&n.Op!=token.NEQ{return };if isReflectValue(pass,n.X)||isReflectValue(pass,n.Y){if n.Op==token.EQL{pass.ReportRangef(n,"avoid using == with reflect.Value")}};case *ast.CallExpr:fn,ok:=typeutil.Callee(pass.TypesInfo,n).(*types.Func);if !ok{return };if fn.FullName()=="reflect.DeepEqual"&&(isReflectValue(pass,n.Args[0])||isReflectValue(pass,n.Args[1])){pass.ReportRangef(n,"avoid using reflect.DeepEqual with reflect.Value")}}});return nil,nil};func isReflectValue(pass *analysis.Pass,e ast.Expr)bool{tv,ok:=pass.TypesInfo.Types[e];if !ok{return false};named,ok:=tv.Type.(*types.Named);if !ok{return false};if obj:=named.Obj();obj==nil||obj.Pkg()==nil||obj.Pkg().Path()!="reflect"||obj.Name()!="Value"{return false};if _,ok:=e.(*ast.CompositeLit);ok{return false};return true}