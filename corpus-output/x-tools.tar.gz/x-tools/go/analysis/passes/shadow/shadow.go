package shadow;import("go/ast";"go/token";"go/types";"golang.org/x/tools/go/analysis";"golang.org/x/tools/go/analysis/passes/inspect";"golang.org/x/tools/go/ast/inspector");const Doc=`check for possible unintended shadowing of variables

This analyzer check for shadowed variables.
A shadowed variable is a variable declared in an inner scope
with the same name and type as a variable in an outer scope,
and where the outer variable is mentioned after the inner one
is declared.

(This definition can be refined; the module generates too many
false positives and is not yet enabled by default.)

For example:

	func BadRead(f *os.File, buf []byte) error {
		var err error
		for {
			n, err := f.Read(buf) // shadows the function variable 'err'
			if err != nil {
				break // causes return of wrong value
			}
			foo(buf)
		}
		return err
	}
`;var Analyzer=&analysis.Analyzer{Name:"shadow",Doc:Doc,Requires:[]*analysis.Analyzer{inspect.Analyzer},Run:run};var strict=false;func init(){Analyzer.Flags.BoolVar(&strict,"strict",strict,"whether to be strict about shadowing; can be noisy")};func run(pass *analysis.Pass)(interface{},error){inspect:=pass.ResultOf[inspect.Analyzer].(*inspector.Inspector);spans:=make(map[types.Object]span);for id,obj:=range pass.TypesInfo.Defs{if obj!=nil{growSpan(spans,obj,id.Pos(),id.End())}};for id,obj:=range pass.TypesInfo.Uses{growSpan(spans,obj,id.Pos(),id.End())};for node,obj:=range pass.TypesInfo.Implicits{if cc,ok:=node.(*ast.CaseClause);ok{growSpan(spans,obj,cc.Colon,cc.Colon)}};nodeFilter:=[]ast.Node{(*ast.AssignStmt)(nil),(*ast.GenDecl)(nil)};inspect.Preorder(nodeFilter,func(n ast.Node){switch n:=n.(type){case *ast.AssignStmt:checkShadowAssignment(pass,spans,n);case *ast.GenDecl:checkShadowDecl(pass,spans,n)}});return nil,nil};type span struct{min token.Pos;max token.Pos};func(s span)contains(pos token.Pos)bool{return s.min<=pos&&pos<s.max};func growSpan(spans map[types.Object]span,obj types.Object,pos,end token.Pos){if strict{return };s,ok:=spans[obj];if ok{if s.min>pos{s.min=pos};if s.max<end{s.max=end}};spans[obj]=s};func checkShadowAssignment(pass *analysis.Pass,spans map[types.Object]span,a *ast.AssignStmt){if a.Tok!=token.DEFINE{return };if idiomaticShortRedecl(pass,a){return };for _,expr:=range a.Lhs{ident,ok:=expr.(*ast.Ident);if !ok{pass.ReportRangef(expr,"invalid AST: short variable declaration of non-identifier");return };checkShadowing(pass,spans,ident)}};func idiomaticShortRedecl(pass *analysis.Pass,a *ast.AssignStmt)bool{if len(a.Rhs)!=len(a.Lhs){return false};for i,expr:=range a.Lhs{lhs,ok:=expr.(*ast.Ident);if !ok{pass.ReportRangef(expr,"invalid AST: short variable declaration of non-identifier");return true};switch rhs:=a.Rhs[i].(type){case *ast.Ident:if lhs.Name!=rhs.Name{return false};case *ast.TypeAssertExpr:if id,ok:=rhs.X.(*ast.Ident);ok{if lhs.Name!=id.Name{return false}};default:return false}};return true};func idiomaticRedecl(d *ast.ValueSpec)bool{if len(d.Names)!=len(d.Values){return false};for i,lhs:=range d.Names{rhs,ok:=d.Values[i].(*ast.Ident);if !ok||lhs.Name!=rhs.Name{return false}};return true};func checkShadowDecl(pass *analysis.Pass,spans map[types.Object]span,d *ast.GenDecl){if d.Tok!=token.VAR{return };for _,spec:=range d.Specs{valueSpec,ok:=spec.(*ast.ValueSpec);if !ok{pass.ReportRangef(spec,"invalid AST: var GenDecl not ValueSpec");return };if idiomaticRedecl(valueSpec){return };for _,ident:=range valueSpec.Names{checkShadowing(pass,spans,ident)}}};func checkShadowing(pass *analysis.Pass,spans map[types.Object]span,ident *ast.Ident){if ident.Name=="_"{return };obj:=pass.TypesInfo.Defs[ident];if obj==nil{return };_,shadowed:=obj.Parent().Parent().LookupParent(obj.Name(),obj.Pos());if shadowed==nil{return };if shadowed.Parent()==types.Universe{return };if strict{if shadowed.Pos()>ident.Pos(){return }};if types.Identical(obj.Type(),shadowed.Type()){line:=pass.Fset.Position(shadowed.Pos()).Line;pass.ReportRangef(ident,"declaration of %q shadows declaration at line %d",obj.Name(),line)}}