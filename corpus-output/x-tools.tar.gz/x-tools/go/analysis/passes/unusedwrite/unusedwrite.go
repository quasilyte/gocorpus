package unusedwrite;import("fmt";"go/types";"golang.org/x/tools/go/analysis";"golang.org/x/tools/go/analysis/passes/buildssa";"golang.org/x/tools/go/ssa");const Doc=`checks for unused writes

The analyzer reports instances of writes to struct fields and
arrays that are never read. Specifically, when a struct object
or an array is copied, its elements are copied implicitly by
the compiler, and any element write to this copy does nothing
with the original object.

For example:

	type T struct { x int }
	func f(input []T) {
		for i, v := range input {  // v is a copy
			v.x = i  // unused write to field x
		}
	}

Another example is about non-pointer receiver:

	type T struct { x int }
	func (t T) f() {  // t is a copy
		t.x = i  // unused write to field x
	}
`;var Analyzer=&analysis.Analyzer{Name:"unusedwrite",Doc:Doc,Requires:[]*analysis.Analyzer{buildssa.Analyzer},Run:run};func run(pass *analysis.Pass)(interface{},error){checkStore:=func(store *ssa.Store){switch addr:=store.Addr.(type){case *ssa.FieldAddr:if isDeadStore(store,addr.X,addr){pass.Reportf(store.Pos(),"unused write to field %s",getFieldName(addr.X.Type(),addr.Field))};case *ssa.IndexAddr:if isDeadStore(store,addr.X,addr){pass.Reportf(store.Pos(),"unused write to array index %s",addr.Index)}}};ssainput:=pass.ResultOf[buildssa.Analyzer].(*buildssa.SSA);for _,fn:=range ssainput.SrcFuncs{for _,blk:=range fn.Blocks{for _,instr:=range blk.Instrs{if store,ok:=instr.(*ssa.Store);ok{checkStore(store)}}}};return nil,nil};func isDeadStore(store *ssa.Store,obj ssa.Value,addr ssa.Instruction)bool{if !hasStructOrArrayType(obj){return false};for _,ref:=range *obj.Referrers(){if ref==store||ref==addr{continue};switch ins:=ref.(type){case ssa.CallInstruction:return false;case *ssa.FieldAddr:if ins.X==obj{if faddr,ok:=addr.(*ssa.FieldAddr);ok{if faddr.Field==ins.Field{return false}}};continue;case *ssa.IndexAddr:if ins.X==obj{return false};continue;case *ssa.Lookup:if ins.X==obj{return false};continue;case *ssa.Store:if ins.Val==obj{return false};continue;default:return false}};return true};func isStructOrArray(tp types.Type)bool{if named,ok:=tp.(*types.Named);ok{tp=named.Underlying()};switch tp.(type){case *types.Array:return true;case *types.Struct:return true};return false};func hasStructOrArrayType(v ssa.Value)bool{if instr,ok:=v.(ssa.Instruction);ok{if alloc,ok:=instr.(*ssa.Alloc);ok{if tp,ok:=alloc.Type().(*types.Pointer);ok{return isStructOrArray(tp.Elem())};return false}};return isStructOrArray(v.Type())};func getFieldName(tp types.Type,index int)string{if pt,ok:=tp.(*types.Pointer);ok{tp=pt.Elem()};if named,ok:=tp.(*types.Named);ok{tp=named.Underlying()};if stp,ok:=tp.(*types.Struct);ok{return stp.Field(index).Name()};return fmt.Sprintf("%d",index)}