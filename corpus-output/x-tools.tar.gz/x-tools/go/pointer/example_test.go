package pointer_test;import("fmt";"sort";"golang.org/x/tools/go/callgraph";"golang.org/x/tools/go/loader";"golang.org/x/tools/go/pointer";"golang.org/x/tools/go/ssa";"golang.org/x/tools/go/ssa/ssautil");func Example(){const myprog=`
package main

import "fmt"

type I interface {
	f(map[string]int)
}

type C struct{}

func (C) f(m map[string]int) {
	fmt.Println("C.f()")
}

func main() {
	var i I = C{}
	x := map[string]int{"one":1}
	i.f(x) // dynamic method call
}
`;var conf loader.Config;file,err:=conf.ParseFile("myprog.go",myprog);if err!=nil{fmt.Print(err);return };conf.CreateFromFiles("main",file);iprog,err:=conf.Load();if err!=nil{fmt.Print(err);return };prog:=ssautil.CreateProgram(iprog,0);mainPkg:=prog.Package(iprog.Created[0].Pkg);prog.Build();config:=&pointer.Config{Mains:[]*ssa.Package{mainPkg},BuildCallGraph:true};C:=mainPkg.Type("C").Type();Cfm:=prog.LookupMethod(C,mainPkg.Pkg,"f").Params[1];config.AddQuery(Cfm);result,err:=pointer.Analyze(config);if err!=nil{panic(err)};var edges []string;callgraph.GraphVisitEdges(result.CallGraph,func(edge *callgraph.Edge)error{caller:=edge.Caller.Func;if caller.Pkg==mainPkg{edges=append(edges,fmt.Sprint(caller," --> ",edge.Callee.Func))};return nil});sort.Strings(edges);for _,edge:=range edges{fmt.Println(edge)};fmt.Println();fmt.Println("m may point to:");var labels []string;for _,l:=range result.Queries[Cfm].PointsTo().Labels(){label:=fmt.Sprintf("  %s: %s",prog.Fset.Position(l.Pos()),l);labels=append(labels,label)};sort.Strings(labels);for _,label:=range labels{fmt.Println(label)}}