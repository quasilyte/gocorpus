package ssa_test;import("fmt";"go/ast";"go/importer";"go/parser";"go/token";"go/types";"log";"os";"golang.org/x/tools/go/packages";"golang.org/x/tools/go/ssa";"golang.org/x/tools/go/ssa/ssautil");const hello=`
package main

import "fmt"

const message = "Hello, World!"

func main() {
	fmt.Println(message)
}
`;func Example_buildPackage(){fset:=token.NewFileSet();f,err:=parser.ParseFile(fset,"hello.go",hello,parser.ParseComments);if err!=nil{fmt.Print(err);return };files:=[]*ast.File{f};pkg:=types.NewPackage("hello","");hello,_,err:=ssautil.BuildPackage(&types.Config{Importer:importer.Default()},fset,pkg,files,ssa.SanityCheckFunctions);if err!=nil{fmt.Print(err);return };hello.WriteTo(os.Stdout);hello.Func("init").WriteTo(os.Stdout);hello.Func("main").WriteTo(os.Stdout)};func Example_loadPackages(){cfg:=&packages.Config{Mode:packages.LoadSyntax};initial,err:=packages.Load(cfg,"fmt","net/http");if err!=nil{log.Fatal(err)};if packages.PrintErrors(initial)>0{log.Fatalf("packages contain errors")};prog,pkgs:=ssautil.Packages(initial,ssa.PrintPackages);_=prog;for _,p:=range pkgs{if p!=nil{p.Build()}}};func Example_loadWholeProgram(){cfg:=packages.Config{Mode:packages.LoadAllSyntax};initial,err:=packages.Load(&cfg,"fmt","net/http");if err!=nil{log.Fatal(err)};prog,pkgs:=ssautil.AllPackages(initial,ssa.PrintPackages);_=pkgs;prog.Build()}