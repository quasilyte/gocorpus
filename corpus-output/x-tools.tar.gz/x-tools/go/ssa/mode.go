package ssa;import("bytes";"fmt");type BuilderMode uint;const(PrintPackages BuilderMode=1<<iota;PrintFunctions;LogSource;SanityCheckFunctions;NaiveForm;BuildSerially;GlobalDebug;BareInits);const BuilderModeDoc=`Options controlling the SSA builder.
The value is a sequence of zero or more of these letters:
C	perform sanity [C]hecking of the SSA form.
D	include [D]ebug info for every function.
P	print [P]ackage inventory.
F	print [F]unction SSA code.
S	log [S]ource locations as SSA builder progresses.
L	build distinct packages seria[L]ly instead of in parallel.
N	build [N]aive SSA form: don't replace local loads/stores with registers.
I	build bare [I]nit functions: no init guards or calls to dependent inits.
`;func(m BuilderMode)String()string{var buf bytes.Buffer;if m&GlobalDebug!=0{buf.WriteByte('D')};if m&PrintPackages!=0{buf.WriteByte('P')};if m&PrintFunctions!=0{buf.WriteByte('F')};if m&LogSource!=0{buf.WriteByte('S')};if m&SanityCheckFunctions!=0{buf.WriteByte('C')};if m&NaiveForm!=0{buf.WriteByte('N')};if m&BuildSerially!=0{buf.WriteByte('L')};if m&BareInits!=0{buf.WriteByte('I')};return buf.String()};func(m *BuilderMode)Set(s string)error{var mode BuilderMode;for _,c:=range s{switch c{case 'D':mode|=GlobalDebug;case 'P':mode|=PrintPackages;case 'F':mode|=PrintFunctions;case 'S':mode|=LogSource|BuildSerially;case 'C':mode|=SanityCheckFunctions;case 'N':mode|=NaiveForm;case 'L':mode|=BuildSerially;case 'I':mode|=BareInits;default:return fmt.Errorf("unknown BuilderMode option: %q",c)}};*m=mode;return nil};func(m BuilderMode)Get()interface{}{return m}