package ssautil_test;import("bytes";"go/ast";"go/importer";"go/parser";"go/token";"go/types";"os";"strings";"testing";"golang.org/x/tools/go/packages";"golang.org/x/tools/go/ssa/ssautil";"golang.org/x/tools/internal/testenv");const hello=`package main

import "fmt"

func main() {
	fmt.Println("Hello, world")
}
`;func TestBuildPackage(t *testing.T){fset:=token.NewFileSet();f,err:=parser.ParseFile(fset,"hello.go",hello,0);if err!=nil{t.Fatal(err)};pkg:=types.NewPackage("hello","");ssapkg,_,err:=ssautil.BuildPackage(&types.Config{Importer:importer.Default()},fset,pkg,[]*ast.File{f},0);if err!=nil{t.Fatal(err)};if pkg.Name()!="main"{t.Errorf("pkg.Name() = %s, want main",pkg.Name())};if ssapkg.Func("main")==nil{ssapkg.WriteTo(os.Stderr);t.Errorf("ssapkg has no main function")}};func TestPackages(t *testing.T){testenv.NeedsGoPackages(t);cfg:=&packages.Config{Mode:packages.LoadSyntax};initial,err:=packages.Load(cfg,"bytes");if err!=nil{t.Fatal(err)};if packages.PrintErrors(initial)>0{t.Fatal("there were errors")};prog,pkgs:=ssautil.Packages(initial,0);bytesNewBuffer:=pkgs[0].Func("NewBuffer");bytesNewBuffer.Pkg.Build();out:=new(bytes.Buffer);bytesNewBuffer.WriteTo(out);location:=prog.Fset.Position(bytesNewBuffer.Pos()).String();got:=strings.Replace(out.String(),location,"$GOROOT/src/bytes/buffer.go:1",-1);want:=`
# Name: bytes.NewBuffer
# Package: bytes
# Location: $GOROOT/src/bytes/buffer.go:1
func NewBuffer(buf []byte) *Buffer:
0:                                                                entry P:0 S:0
	t0 = new Buffer (complit)                                       *Buffer
	t1 = &t0.buf [#0]                                               *[]byte
	*t1 = buf
	return t0

`[1:];if got!=want{t.Errorf("bytes.NewBuffer SSA = <<%s>>, want <<%s>>",got,want)}};func TestBuildPackage_MissingImport(t *testing.T){fset:=token.NewFileSet();f,err:=parser.ParseFile(fset,"bad.go",`package bad; import "missing"`,0);if err!=nil{t.Fatal(err)};pkg:=types.NewPackage("bad","");ssapkg,_,err:=ssautil.BuildPackage(new(types.Config),fset,pkg,[]*ast.File{f},0);if err==nil||ssapkg!=nil{t.Fatal("BuildPackage succeeded unexpectedly")}};func TestIssue28106(t *testing.T){testenv.NeedsGoPackages(t);cfg:=&packages.Config{Mode:packages.LoadSyntax};pkgs,err:=packages.Load(cfg,"runtime");if err!=nil{t.Fatal(err)};prog,_:=ssautil.Packages(pkgs,0);prog.Build()}